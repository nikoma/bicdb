//! Split out of the parent module to keep files digestible; behavior
//! unchanged — a separate `impl` block on the same type.
use super::*;

impl BicDb {
    pub(crate) fn spatial_point_scan(
        &self,
        collection: &str,
        field: &IndexField,
        lon: f64,
        lat: f64,
        radius_meters: Option<f64>,
    ) -> Result<Vec<SpatialQueryResult>> {
        let state = self.collection_state(collection)?;
        let mut results = Vec::new();
        for shard in state.read_all() {
            for entry in shard.records.values() {
                let record = entry.record.to_record()?;
                let Some(point) = spatial_record_point(&record, field)? else {
                    continue;
                };
                let distance_meters = haversine_meters(lon, lat, point[0], point[1]);
                if radius_meters.is_none_or(|meters| distance_meters <= meters) {
                    results.push(SpatialQueryResult {
                        record,
                        distance_meters,
                    });
                }
            }
        }
        Ok(results)
    }

    pub(crate) fn ensure_spatial_field_present(
        &self,
        collection: &str,
        field: &IndexField,
    ) -> Result<()> {
        let state = self.collection_state(collection)?;
        if state.record_count() == 0 {
            return Ok(());
        }
        for shard in state.read_all() {
            for entry in shard.records.values() {
                if record_spatial_geometry(&entry.record.to_record()?, field)?.is_some() {
                    return Ok(());
                }
            }
        }
        Err(BicDbError::Index(format!(
            "spatial field `{}` not found in collection `{collection}`",
            spatial_field_name(field)
        )))
    }

    pub(crate) fn ensure_spatial_point_query(
        &self,
        collection: &str,
        field: &str,
        lon: f64,
        lat: f64,
        limit: Option<usize>,
        radius_meters: Option<f64>,
    ) -> Result<()> {
        self.ensure_collection(collection)?;
        let _ = spatial_field_from_name(field)?;
        if !lon.is_finite() || !lat.is_finite() {
            return Err(BicDbError::Index(
                "spatial query requires finite lon/lat".to_string(),
            ));
        }
        if limit.is_some_and(|limit| limit == 0) {
            return Ok(());
        }
        if radius_meters.is_some_and(|meters| meters < 0.0 || !meters.is_finite()) {
            return Err(BicDbError::Index(
                "spatial radius query requires non-negative finite meters".to_string(),
            ));
        }
        Ok(())
    }

    /// FOLD a full-text index's per-posting tail into compressed posting
    /// BLOCKS (Search-core stage: block postings). Per term, atomically in
    /// one paged transaction: existing blocks + v1 tail postings (tail wins
    /// per pk) minus tombstones are re-blocked (front-coded pks, varint
    /// positions, per-block max impact) and the folded v1/v2 entries and
    /// consumed tombstones are deleted. The per-posting keyspaces remain the
    /// transactional TAIL for writes after the fold; reads merge
    /// blocks + tail - tombstones. Returns (terms folded, blocks written).
    pub fn compact_full_text_index(&self, name: &str) -> Result<(usize, usize)> {
        self.compact_full_text_index_inner(name, None)
    }

    /// Fold at most `max_terms` whole terms without synchronous full-store
    /// reclamation. Hosts release their database guard between batches; the
    /// governed checkpoint/vacuum workers reclaim retired posting versions.
    /// A single term remains atomic, so this is a term bound, not a byte or
    /// elapsed-time guarantee for an unusually large individual posting list.
    pub fn compact_full_text_index_batch(
        &self,
        name: &str,
        max_terms: usize,
    ) -> Result<(usize, usize)> {
        if max_terms == 0 {
            return Err(BicDbError::Index(
                "full-text fold batch must be nonzero".into(),
            ));
        }
        self.compact_full_text_index_inner(name, Some(max_terms))
    }

    fn compact_full_text_index_inner(
        &self,
        name: &str,
        max_terms: Option<usize>,
    ) -> Result<(usize, usize)> {
        let state = self
            .indexes
            .get(name)
            .ok_or_else(|| BicDbError::Index(format!("index `{name}` not found")))?
            .read();
        if state.definition.kind != IndexKind::FullText || !state.paged_read_through {
            return Err(BicDbError::Index(format!(
                "index `{name}` is not a read-through full-text index"
            )));
        }
        drop(state);
        let paged = self
            .paged_records
            .as_ref()
            .ok_or_else(|| BicDbError::Index(format!("index `{name}` has no page store")))?;
        let paged = Arc::clone(paged);
        if paged.index_has_numeric_posting_blocks(&paged.latest_snapshot(), name)? {
            return self.compact_numeric_full_text_index(name, &paged, max_terms);
        }

        // Terms with anything to fold: a v1 tail entry or a tombstone.
        let snapshot = paged.latest_snapshot();
        let mut terms: std::collections::BTreeSet<Vec<u8>> = std::collections::BTreeSet::new();
        for entry in paged.scan_index(&snapshot, name)? {
            let (encoded_key, _) = entry?;
            terms.insert(encoded_key);
            if max_terms.is_some_and(|limit| terms.len() >= limit) {
                break;
            }
        }
        // v2 twins are written alongside v1 since 0.9.51, so the v1 scan
        // already covers every tail term.
        if max_terms.is_none_or(|limit| terms.len() < limit) {
            for entry in paged.scan_index_tombstone_terms(&snapshot, name)? {
                let term = entry?;
                terms.insert(term);
                if max_terms.is_some_and(|limit| terms.len() >= limit) {
                    break;
                }
            }
        }

        let mut folded_terms = 0usize;
        let mut blocks_written = 0usize;
        for encoded_key in terms {
            let snapshot = paged.latest_snapshot();
            // Assemble the term's full posting set: blocks first, then the
            // tail OVERRIDES per pk, then tombstones remove.
            let mut merged: std::collections::BTreeMap<
                String,
                crate::paged_collection::BlockPosting,
            > = std::collections::BTreeMap::new();
            let mut old_blocks: Vec<String> = Vec::new();
            for block in paged.scan_posting_blocks(&snapshot, name, &encoded_key)? {
                let (last_pk, bytes) = block?;
                old_blocks.push(last_pk);
                let (postings, _) = crate::paged_collection::decode_posting_block(&bytes)?;
                for posting in postings {
                    merged.insert(posting.pk.clone(), posting);
                }
            }
            let mut tail_pairs: Vec<(String, Option<(u32, u32, Vec<u16>)>)> = Vec::new();
            for entry in paged.scan_index_exact(&snapshot, name, &encoded_key)? {
                let (pk, payload) = entry?;
                tail_pairs.push((pk, decode_fts_posting_payload(&payload)));
            }
            for (pk, decoded) in &tail_pairs {
                let Some((doc_length, doc_distinct, packed)) = decoded else {
                    // Legacy payload-less tail (pre-0.9.48 postings): folding
                    // would lose positions — skip this term entirely.
                    tail_pairs.clear();
                    merged.clear();
                    break;
                };
                merged.insert(
                    pk.clone(),
                    crate::paged_collection::BlockPosting {
                        pk: pk.clone(),
                        doc_length: *doc_length,
                        doc_distinct: *doc_distinct,
                        packed_positions: packed.clone(),
                    },
                );
            }
            if tail_pairs.is_empty() && merged.is_empty() && old_blocks.is_empty() {
                continue;
            }
            let mut tombstoned: Vec<String> = Vec::new();
            for pk in paged.scan_posting_tombstones(&snapshot, name, &encoded_key)? {
                let pk = pk?;
                merged.remove(&pk);
                tombstoned.push(pk);
            }

            // Re-block, twice: once in pk order (probes, boolean merges) and
            // once in (impact DESC, pk) order (the ranked block-max scan —
            // pk-ordered blocks interleave impact classes, so every block max
            // ties and nothing can be skipped).
            let merged: Vec<crate::paged_collection::BlockPosting> = merged.into_values().collect();
            let new_blocks =
                build_posting_blocks(&merged, FTS_BLOCK_DOC_CAP, FTS_BLOCK_BYTE_TARGET);
            let mut impact_sorted = merged;
            impact_sorted.sort_by(|left, right| {
                fts_impact_bucket(&right.packed_positions)
                    .cmp(&fts_impact_bucket(&left.packed_positions))
                    .then_with(|| left.pk.cmp(&right.pk))
            });
            let impact_blocks =
                build_posting_blocks(&impact_sorted, FTS_BLOCK_DOC_CAP, FTS_BLOCK_BYTE_TARGET);

            // Atomic swap for this term.
            let tail_pks: Vec<String> = tail_pairs.iter().map(|(pk, _)| pk.clone()).collect();
            let tail_buckets: Vec<Option<u16>> = tail_pairs
                .iter()
                .map(|(_, decoded)| {
                    decoded
                        .as_ref()
                        .map(|(_, _, packed)| fts_impact_bucket(packed))
                })
                .collect();
            let old_impact_seqs: Vec<u32> = paged
                .scan_impact_blocks(&snapshot, name, &encoded_key)?
                .map(|entry| entry.map(|(seq, _)| seq))
                .collect::<Result<Vec<_>>>()?;
            self.in_paged_transaction(|paged, xid| {
                for last_pk in &old_blocks {
                    paged.delete_posting_block(xid, name, &encoded_key, last_pk)?;
                }
                for seq in &old_impact_seqs {
                    paged.delete_impact_block(xid, name, &encoded_key, *seq)?;
                }
                for (seq, (_, block)) in impact_blocks.iter().enumerate() {
                    paged.put_impact_block(xid, name, &encoded_key, seq as u32, block)?;
                }
                for (pk, bucket) in tail_pks.iter().zip(&tail_buckets) {
                    paged.delete_index_entry(xid, name, &encoded_key, pk)?;
                    if let Some(bucket) = bucket {
                        paged.delete_index_entry_v2(xid, name, &encoded_key, *bucket, pk)?;
                    }
                }
                for pk in &tombstoned {
                    paged.delete_posting_tombstone(xid, name, &encoded_key, pk)?;
                }
                for (last_pk, block) in &new_blocks {
                    paged.put_posting_block(xid, name, &encoded_key, last_pk, block)?;
                }
                Ok(())
            })?;
            folded_terms += 1;
            blocks_written += new_blocks.len();
        }
        // Reclaim the folded per-posting entries: until vacuumed, every read
        // of a folded term pays a visibility walk over the dead tail
        // (~285 ms per 100k reclaimed entries, measured). Safe since B11a
        // (writes tolerate reclaimed chain heads) and B11b (slot directories
        // keep trailing dead slots, so generations stay monotonic and stale
        // locators can never validate against a new tenant).
        if max_terms.is_none() {
            paged.checkpoint()?;
            vacuum_paged_records_to_completion(paged.as_ref())?;
            // Vacuum retires the versions; the sweep retires the KEYS. Without
            // it every read of a folded term still walks the dead tail's B-tree
            // entries (~180 ms per 100k keys, measured).
            paged.sweep_dead_index_entries(usize::MAX)?;
        }
        Ok((folded_terms, blocks_written))
    }

    pub(crate) fn compact_numeric_full_text_index(
        &self,
        name: &str,
        paged: &Arc<crate::paged_collection::PagedRecords>,
        max_terms: Option<usize>,
    ) -> Result<(usize, usize)> {
        let snapshot = paged.latest_snapshot();
        let mut collection_statistics = paged
            .full_text_collection_statistics(&snapshot, name)?
            .ok_or_else(|| {
                BicDbError::Index(format!(
                    "numeric full-text index `{name}` has no collection statistics"
                ))
            })?;
        let mut terms = std::collections::BTreeSet::new();
        for entry in paged.scan_index(&snapshot, name)? {
            let (encoded_key, _) = entry?;
            terms.insert(encoded_key);
            if max_terms.is_some_and(|limit| terms.len() >= limit) {
                break;
            }
        }
        if max_terms.is_none_or(|limit| terms.len() < limit) {
            for entry in paged.scan_index_tombstone_terms(&snapshot, name)? {
                terms.insert(entry?);
                if max_terms.is_some_and(|limit| terms.len() >= limit) {
                    break;
                }
            }
        }

        let mut folded_terms = 0usize;
        let mut blocks_written = 0usize;
        for encoded_key in terms {
            let snapshot = paged.latest_snapshot();
            let previous_statistics =
                paged.full_text_term_statistics(&snapshot, name, &encoded_key)?;
            let mut merged = std::collections::BTreeMap::<
                u64,
                crate::paged_collection::NumericBlockPosting,
            >::new();
            let mut old_blocks = Vec::new();
            for block in paged.scan_numeric_posting_blocks(&snapshot, name, &encoded_key)? {
                let (last_document_id, bytes) = block?;
                old_blocks.push(last_document_id);
                for posting in crate::paged_collection::decode_numeric_posting_block(&bytes)? {
                    merged.insert(posting.document_id, posting);
                }
            }

            let mut tail = Vec::<(String, u16, u64)>::new();
            let mut new_mappings =
                Vec::<(u64, String, crate::fts_format::FullTextDocumentStatistics)>::new();
            let mut legacy = false;
            for entry in paged.scan_index_exact(&snapshot, name, &encoded_key)? {
                let (pk, payload) = entry?;
                let Some((doc_length, doc_distinct, packed_positions)) =
                    decode_fts_posting_payload(&payload)
                else {
                    legacy = true;
                    break;
                };
                let document_id = match paged.full_text_document_id_for_pk(&snapshot, name, &pk)? {
                    Some(document_id) => document_id,
                    None => {
                        let document_id = collection_statistics.next_document_id;
                        collection_statistics.next_document_id = collection_statistics
                            .next_document_id
                            .checked_add(1)
                            .ok_or_else(|| {
                                BicDbError::Index(
                                    "full-text document-id space exhausted".to_string(),
                                )
                            })?;
                        collection_statistics.document_count =
                            collection_statistics.document_count.saturating_add(1);
                        collection_statistics.total_document_length = collection_statistics
                            .total_document_length
                            .saturating_add(u64::from(doc_length));
                        let statistics = paged
                            .get_doc_terms(&snapshot, name, &pk)?
                            .map(|blob| crate::paged_collection::decode_doc_term_statistics(&blob))
                            .transpose()?
                            .unwrap_or(crate::fts_format::FullTextDocumentStatistics {
                                document_length: doc_length,
                                distinct_terms: doc_distinct,
                                field_lengths: [doc_length, 0, 0, 0],
                            });
                        for (total, length) in collection_statistics
                            .field_total_lengths
                            .iter_mut()
                            .zip(statistics.field_lengths)
                        {
                            *total = total.saturating_add(u64::from(length));
                        }
                        new_mappings.push((document_id, pk.clone(), statistics));
                        document_id
                    }
                };
                let bucket = fts_impact_bucket(&packed_positions);
                merged.insert(
                    document_id,
                    crate::paged_collection::NumericBlockPosting {
                        document_id,
                        doc_length,
                        doc_distinct,
                        packed_positions,
                    },
                );
                tail.push((pk, bucket, document_id));
            }
            if legacy {
                continue;
            }

            let mut tombstones = Vec::new();
            for pk in paged.scan_posting_tombstones(&snapshot, name, &encoded_key)? {
                let pk = pk?;
                if let Some(document_id) =
                    paged.full_text_document_id_for_pk(&snapshot, name, &pk)?
                {
                    merged.remove(&document_id);
                }
                tombstones.push(pk);
            }

            let postings: Vec<_> = merged.into_values().collect();
            let posting_blocks =
                build_numeric_posting_blocks(&postings, FTS_BLOCK_DOC_CAP, FTS_BLOCK_BYTE_TARGET);
            let mut impact_postings = postings.clone();
            impact_postings.sort_by(|left, right| {
                fts_impact_bucket(&right.packed_positions)
                    .cmp(&fts_impact_bucket(&left.packed_positions))
                    .then_with(|| left.document_id.cmp(&right.document_id))
            });
            let impact_blocks = build_compact_impact_blocks(
                &impact_postings,
                FTS_BLOCK_DOC_CAP,
                FTS_BLOCK_BYTE_TARGET,
            );
            let old_impact_blocks: Vec<u32> = paged
                .scan_numeric_impact_blocks(&snapshot, name, &encoded_key)?
                .map(|entry| entry.map(|(seq, _)| seq))
                .collect::<Result<_>>()?;

            let term_statistics = (!postings.is_empty()).then(|| {
                let mut statistics = crate::fts_format::FullTextTermStatistics {
                    document_frequency: postings.len() as u64,
                    collection_frequency: postings
                        .iter()
                        .map(|posting| posting.packed_positions.len() as u64)
                        .sum(),
                    posting_block_count: posting_blocks.len() as u32,
                    impact_block_count: impact_blocks.len() as u32,
                    posting_bytes: posting_blocks
                        .iter()
                        .map(|(_, bytes)| bytes.len() as u64)
                        .sum(),
                    impact_bytes: impact_blocks
                        .iter()
                        .map(|(_, bytes)| bytes.len() as u64)
                        .sum(),
                    first_doc_id: postings.first().map(|posting| posting.document_id),
                    last_doc_id: postings.last().map(|posting| posting.document_id),
                    maximum_contribution: 0.0,
                };
                for posting in &postings {
                    statistics.maximum_contribution = statistics.maximum_contribution.max(
                        fts_rank_single_term(&posting.packed_positions, [0.1, 0.2, 0.4, 1.0]),
                    );
                }
                statistics
            });
            match (
                previous_statistics
                    .as_ref()
                    .is_some_and(|statistics| statistics.document_frequency > 0),
                term_statistics.is_some(),
            ) {
                (false, true) => {
                    collection_statistics.term_count =
                        collection_statistics.term_count.saturating_add(1);
                }
                (true, false) => {
                    collection_statistics.term_count =
                        collection_statistics.term_count.saturating_sub(1);
                }
                _ => {}
            }
            collection_statistics.average_document_length =
                if collection_statistics.document_count == 0 {
                    0.0
                } else {
                    collection_statistics.total_document_length as f64
                        / collection_statistics.document_count as f64
                };

            self.in_paged_transaction(|paged, xid| {
                for last_document_id in &old_blocks {
                    paged.delete_numeric_posting_block(
                        xid,
                        name,
                        &encoded_key,
                        *last_document_id,
                    )?;
                }
                for seq in &old_impact_blocks {
                    paged.delete_numeric_impact_block(xid, name, &encoded_key, *seq)?;
                }
                for (document_id, pk, statistics) in &new_mappings {
                    paged.put_full_text_document_id(xid, name, *document_id, pk)?;
                    paged.put_full_text_document_statistics(xid, name, *document_id, statistics)?;
                }
                if posting_blocks.is_empty() {
                    // The immutable segment still contains this term. Keep an
                    // authoritative empty paged block: removing every override
                    // would make exact/prefix/ranked probes fall back to that
                    // segment and resurrect its deleted matches. The existing
                    // numeric codec represents an empty list without new format.
                    let empty = crate::paged_collection::encode_numeric_posting_block(&[], 0, 0.0);
                    paged.put_numeric_posting_block(xid, name, &encoded_key, 0, &empty)?;
                }
                for (last_document_id, bytes) in &posting_blocks {
                    paged.put_numeric_posting_block(
                        xid,
                        name,
                        &encoded_key,
                        *last_document_id,
                        bytes,
                    )?;
                }
                for (seq, (_, bytes)) in impact_blocks.iter().enumerate() {
                    paged.put_numeric_impact_block(xid, name, &encoded_key, seq as u32, bytes)?;
                }
                for (pk, bucket, _) in &tail {
                    paged.delete_index_entry(xid, name, &encoded_key, pk)?;
                    paged.delete_index_entry_v2(xid, name, &encoded_key, *bucket, pk)?;
                }
                for pk in &tombstones {
                    paged.delete_posting_tombstone(xid, name, &encoded_key, pk)?;
                }
                if let Some(statistics) = &term_statistics {
                    paged.put_full_text_term_statistics(xid, name, &encoded_key, statistics)?;
                } else {
                    // An absent dictionary row would likewise fall back to
                    // the immutable segment's old nonzero statistics.
                    paged.put_full_text_term_statistics(
                        xid,
                        name,
                        &encoded_key,
                        &crate::fts_format::FullTextTermStatistics::default(),
                    )?;
                }
                paged.put_full_text_collection_statistics(xid, name, &collection_statistics)
            })?;
            folded_terms += 1;
            blocks_written += posting_blocks.len();
        }
        if max_terms.is_none() {
            paged.checkpoint()?;
            vacuum_paged_records_to_completion(paged.as_ref())?;
            paged.sweep_dead_index_entries(usize::MAX)?;
        }
        Ok((folded_terms, blocks_written))
    }

    pub fn compact(&mut self) -> Result<CompactionReport> {
        self.compact_with_options(CompactionOptions::default())
    }

    pub fn compact_with_options_governed(
        &mut self,
        options: CompactionOptions,
        governor: &ResourceGovernor,
        demand: ResourceDemand,
        now_ms: u64,
    ) -> Result<CompactionReport> {
        let permit = governor.try_admit(ResourceLane::Compaction, demand, now_ms)?;
        let result = self.compact_with_options(options);
        drop(permit);
        result
    }

    /// Create or reopen an offline, collection-at-a-time compaction run. The
    /// database commit sequence is pinned for the lifetime of the run; writes
    /// between ticks fail closed before log truncation can occur.
    pub fn begin_incremental_compaction(
        &mut self,
        options: CompactionOptions,
        limits: IncrementalCompactionLimits,
        now_ms: u64,
    ) -> Result<IncrementalCompactionState> {
        limits.validate()?;
        if options.allow_pending {
            return Err(BicDbError::Compaction(
                "incremental compaction requires an offline, write-stable database".to_string(),
            ));
        }
        self.ensure_no_pending_transactions()?;
        let path = self.path.join(DEFAULT_INCREMENTAL_COMPACTION_STATE);
        match fs::symlink_metadata(&path) {
            Ok(metadata) => {
                if metadata.file_type().is_symlink() {
                    return Err(BicDbError::Compaction(
                        "refusing symlink incremental compaction state".to_string(),
                    ));
                }
                let existing = self.load_incremental_compaction(limits)?;
                if existing.phase != IncrementalCompactionPhase::Complete {
                    if existing.options == options {
                        return Ok(existing);
                    }
                    return Err(BicDbError::Compaction(
                        "another incremental compaction run is active".to_string(),
                    ));
                }
            }
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
            Err(error) => return Err(error.into()),
        }
        let mut collections = self
            .collections()
            .into_iter()
            .map(|collection| collection.name)
            .collect::<Vec<_>>();
        collections.sort();
        if collections.len() > limits.max_collections {
            return Err(BicDbError::Compaction(
                "database collection count exceeds incremental compaction limit".to_string(),
            ));
        }
        let transaction_log_bytes_before = file_len(&self.tx_log_path())?;
        let event_log_bytes_before = file_len(&event_segment_path_for(&self.path))?;
        let sync_log_bytes_before = file_len(&self.path.join("sync.log"))?;
        let run_id = Uuid::now_v7();
        let mut state = IncrementalCompactionState {
            format_version: INCREMENTAL_COMPACTION_FORMAT_VERSION,
            run_id,
            phase: IncrementalCompactionPhase::RewritingCollections,
            options,
            limits,
            collections: collections.clone(),
            next_collection: 0,
            starting_commit_seq: self.last_commit_seq(),
            created_at_ms: now_ms,
            updated_at_ms: now_ms,
            report: CompactionReport {
                checkpoint_id: Some(run_id.to_string()),
                transaction_log_bytes_before,
                event_log_bytes_before,
                sync_log_bytes_before,
                index_metadata_bytes: file_len(&self.path.join(DEFAULT_INDEX_CATALOG))?,
                sidecar_bytes: self.sidecar_bytes()?,
                ..CompactionReport::default()
            },
            checksum_sha256: String::new(),
        };
        state.refresh_checksum()?;
        self.write_compaction_checkpoint(
            &run_id.to_string(),
            CompactionCheckpointPhase::Started,
            &collections,
            transaction_log_bytes_before,
            event_log_bytes_before,
            sync_log_bytes_before,
        )?;
        self.save_incremental_compaction(&state)?;
        Ok(state)
    }

    pub fn load_incremental_compaction(
        &self,
        limits: IncrementalCompactionLimits,
    ) -> Result<IncrementalCompactionState> {
        limits.validate()?;
        let path = self.path.join(DEFAULT_INCREMENTAL_COMPACTION_STATE);
        let metadata = fs::symlink_metadata(&path)?;
        if metadata.file_type().is_symlink()
            || !metadata.is_file()
            || metadata.len() == 0
            || metadata.len() > limits.max_state_bytes
        {
            return Err(BicDbError::Compaction(
                "incremental compaction state is unsafe or outside its bound".to_string(),
            ));
        }
        #[cfg(unix)]
        let file = {
            use std::os::unix::fs::OpenOptionsExt;
            fs::OpenOptions::new()
                .read(true)
                .custom_flags(libc::O_NOFOLLOW)
                .open(&path)?
        };
        #[cfg(not(unix))]
        let file = File::open(&path)?;
        let length = metadata.len();
        let mut bytes = Vec::with_capacity(length as usize);
        file.take(limits.max_state_bytes.saturating_add(1))
            .read_to_end(&mut bytes)?;
        if bytes.len() as u64 != length || bytes.len() as u64 > limits.max_state_bytes {
            return Err(BicDbError::Compaction(
                "incremental compaction state changed or grew while reading".to_string(),
            ));
        }
        let state: IncrementalCompactionState = serde_json::from_slice(&bytes)?;
        if state.limits != limits {
            return Err(BicDbError::Compaction(
                "incremental compaction limits changed across restart".to_string(),
            ));
        }
        state.validate()?;
        Ok(state)
    }

    /// Advance exactly one collection or one finalization phase under the
    /// compaction resource lane, then atomically checkpoint the durable state.
    pub fn advance_incremental_compaction_governed(
        &mut self,
        limits: IncrementalCompactionLimits,
        governor: &ResourceGovernor,
        demand: ResourceDemand,
        now_ms: u64,
    ) -> Result<IncrementalCompactionAdvance> {
        let mut state = self.load_incremental_compaction(limits)?;
        if state.phase == IncrementalCompactionPhase::Complete {
            return Ok(IncrementalCompactionAdvance::Complete(state.report));
        }
        if now_ms < state.updated_at_ms {
            return Err(BicDbError::Compaction(
                "incremental compaction clock regressed".to_string(),
            ));
        }
        self.ensure_no_pending_transactions()?;
        if self.last_commit_seq() != state.starting_commit_seq {
            return Err(BicDbError::Compaction(
                "database changed during incremental compaction; discard and restart the run"
                    .to_string(),
            ));
        }
        let _permit = governor.try_admit(ResourceLane::Compaction, demand, now_ms)?;
        match state.phase {
            IncrementalCompactionPhase::RewritingCollections => {
                if let Some(collection) = state.collections.get(state.next_collection).cloned() {
                    let report = self.compact_collection_inner(&collection)?;
                    throttle_compaction_io(&state.options, report.bytes_before)?;
                    state.report.live_records = state
                        .report
                        .live_records
                        .saturating_add(report.live_records);
                    state.report.bytes_before = state
                        .report
                        .bytes_before
                        .saturating_add(report.bytes_before);
                    state.report.bytes_after =
                        state.report.bytes_after.saturating_add(report.bytes_after);
                    state.report.bytes_reclaimed = state
                        .report
                        .bytes_reclaimed
                        .saturating_add(report.bytes_reclaimed);
                    state.report.collections.push(report);
                    state.next_collection += 1;
                } else {
                    state.report.bytes_scanned = state
                        .report
                        .bytes_before
                        .saturating_add(state.report.transaction_log_bytes_before)
                        .saturating_add(state.report.event_log_bytes_before)
                        .saturating_add(state.report.sync_log_bytes_before)
                        .saturating_add(state.report.index_metadata_bytes)
                        .saturating_add(state.report.sidecar_bytes);
                    state.report.dead_records = estimate_dead_records(&state.report.collections);
                    let skip_logs = !state.options.force
                        && state.options.reclaim_threshold_percent > 0
                        && reclaim_percent(state.report.bytes_before, state.report.bytes_reclaimed)
                            < state.options.reclaim_threshold_percent;
                    if skip_logs {
                        state.report.transaction_log_bytes_after =
                            state.report.transaction_log_bytes_before;
                        state.report.event_log_bytes_after = state.report.event_log_bytes_before;
                        state.report.sync_log_bytes_after = state.report.sync_log_bytes_before;
                        state.phase = IncrementalCompactionPhase::Complete;
                        self.write_incremental_compatibility_checkpoint(
                            &state,
                            CompactionCheckpointPhase::Committed,
                        )?;
                    } else {
                        state.phase = IncrementalCompactionPhase::CheckpointingLogs;
                        self.write_incremental_compatibility_checkpoint(
                            &state,
                            CompactionCheckpointPhase::RecordsRewritten,
                        )?;
                    }
                }
            }
            IncrementalCompactionPhase::CheckpointingLogs => {
                self.tx_log.flush_pending()?;
                self.cut_transaction_log(u64::MAX, self.commit_seq.load(AtomicOrdering::SeqCst))?;
                self.tx_log.invalidate();
                self.tx_states
                    .retain(|_, value| *value == TxState::Committed);
                let (event_before, event_after, frozen_end) = {
                    let mut events = self.events.lock();
                    events.broker().trim_configured()?;
                    let frozen_end = self.freeze_local_event_positions(&mut events)?;
                    let (before, after) = events.compact()?;
                    (before, after, frozen_end)
                };
                self.invalidate_sync_vector_cache();
                let (sync_before, sync_after) = self
                    .sync_log
                    .get_mut()
                    .compact(self.commit_seq.load(AtomicOrdering::SeqCst))?;
                self.sync_state.last_export_offset = 0;
                self.sync_state.last_reconciled_offset = 0;
                self.sync_state.origin_position_base = self
                    .sync_state
                    .origin_position_base
                    .saturating_add(frozen_end);
                state.report.event_log_bytes_before = event_before;
                state.report.event_log_bytes_after = event_after;
                state.report.sync_log_bytes_before = sync_before;
                state.report.sync_log_bytes_after = sync_after;
                state.report.transaction_log_bytes_after = file_len(&self.tx_log_path())?;
                state.phase = IncrementalCompactionPhase::Publishing;
                self.write_incremental_compatibility_checkpoint(
                    &state,
                    CompactionCheckpointPhase::LogsCheckpointed,
                )?;
            }
            IncrementalCompactionPhase::Publishing => {
                self.persist_catalog()?;
                self.persist_index_catalog()?;
                self.persist_sync_state()?;
                self.write_incremental_compatibility_checkpoint(
                    &state,
                    CompactionCheckpointPhase::Committed,
                )?;
                if self.config.snapshot {
                    if let Err(error) = self.write_startup_snapshot() {
                        eprintln!("[snapshot] incremental compaction write failed: {error}");
                    }
                }
                state.phase = IncrementalCompactionPhase::Complete;
            }
            IncrementalCompactionPhase::Complete => unreachable!(),
        }
        state.updated_at_ms = now_ms;
        state.report.duration_ms = now_ms.saturating_sub(state.created_at_ms);
        state.refresh_checksum()?;
        self.save_incremental_compaction(&state)?;
        if state.phase == IncrementalCompactionPhase::Complete {
            Ok(IncrementalCompactionAdvance::Complete(state.report))
        } else {
            Ok(IncrementalCompactionAdvance::Progress {
                phase: state.phase,
                completed_collections: state.next_collection,
                total_collections: state.collections.len(),
            })
        }
    }

    /// Remove a validated incomplete coordinator checkpoint. Already rewritten
    /// collection files remain valid; a new run starts from current committed
    /// state and safely rewrites them again.
    pub fn discard_incremental_compaction(
        &self,
        limits: IncrementalCompactionLimits,
    ) -> Result<bool> {
        let path = self.path.join(DEFAULT_INCREMENTAL_COMPACTION_STATE);
        if !path.exists() {
            return Ok(false);
        }
        self.load_incremental_compaction(limits)?;
        fs::remove_file(&path)?;
        #[cfg(unix)]
        if self.config.fsync {
            File::open(&self.path)?.sync_all()?;
        }
        Ok(true)
    }

    pub(crate) fn save_incremental_compaction(
        &self,
        state: &IncrementalCompactionState,
    ) -> Result<()> {
        state.validate()?;
        let bytes = serde_json::to_vec(state)?;
        if bytes.len() as u64 > state.limits.max_state_bytes {
            return Err(BicDbError::Compaction(
                "incremental compaction state exceeds its write bound".to_string(),
            ));
        }
        storage::write_atomic(
            &self.path.join(DEFAULT_INCREMENTAL_COMPACTION_STATE),
            &bytes,
            self.config.fsync,
        )
    }

    pub(crate) fn write_incremental_compatibility_checkpoint(
        &self,
        state: &IncrementalCompactionState,
        phase: CompactionCheckpointPhase,
    ) -> Result<()> {
        self.write_compaction_checkpoint(
            &state.run_id.to_string(),
            phase,
            &state.collections[..state.next_collection],
            state.report.transaction_log_bytes_before,
            state.report.event_log_bytes_before,
            state.report.sync_log_bytes_before,
        )
    }

    /// Event-horizon trimming: bound record-audit history growth without
    /// breaking sync.
    ///
    /// The record-audit stream is the sync substrate, and state convergence
    /// only ever consumes each record's *winning* event (reconciliation
    /// replays winners; imports resolve last-writer-wins). So per
    /// `(collection, record)`:
    ///
    /// - **superseded events** (older than the winner) are dropped
    ///   unconditionally — any peer still holding one loses LWW against the
    ///   retained winner, so replays converge identically;
    /// - **winning upserts** are always retained — they *are* current state,
    ///   and a fresh device bootstraps from exactly this set;
    /// - **winning deletes** are retained until `acknowledged` passes their
    ///   offset (a lagging peer that still holds the record needs the delete
    ///   to arrive, otherwise its next push would resurrect the record).
    ///   `acknowledged` is the caller's peer horizon: a client passes its
    ///   export watermark (everything the server confirmed), a hub server
    ///   passes the minimum of its clients' pull checkpoints. Peers lagging
    ///   beyond the horizon must re-bootstrap.
    ///
    /// Every other stream — user event-sourcing streams, projections,
    /// broker, spatial audit — is retained untouched.
    ///
    /// Like `compact()`, this rewrites the event segment (offsets change),
    /// so the engine's sync export watermark resets to zero; re-exports are
    /// deduplicated by event id on the receiving side.
    pub fn trim_event_horizon(
        &mut self,
        acknowledged: SyncCheckpoint,
    ) -> Result<EventHorizonReport> {
        self.ensure_no_pending_transactions()?;

        let mut events = self.events.lock();
        let mut winners = BTreeMap::<(String, String), (Uuid, AuditOrder, bool, u64)>::new();
        for stored in events.read(RECORD_AUDIT_STREAM)? {
            let Some(mutation) = AuditMutation::from_event_based(
                &self.sync_state.node_id,
                self.sync_state.origin_position_base,
                &stored,
            )?
            else {
                continue;
            };
            let key = (mutation.collection.clone(), mutation.record_id.clone());
            let is_delete = matches!(mutation.action, AuditAction::Delete);
            match winners.get(&key) {
                Some((_, existing_order, _, _)) if *existing_order >= mutation.order => {}
                _ => {
                    winners.insert(
                        key,
                        (stored.event.id, mutation.order, is_delete, stored.offset),
                    );
                }
            }
        }

        let mut report = EventHorizonReport {
            events_before: events.stored_events().len(),
            ..Default::default()
        };
        // Freeze every retained LOCAL event's origin position into its sync
        // metadata before offsets change, and advance the durable position
        // base past everything ever assigned — mesh vectors stay sound
        // through the rewrite (origin positions never move, never repeat).
        let base = self.sync_state.origin_position_base;
        let mut old_log_end: u64 = 0;
        let freeze = |stored: &StoredEvent| -> Result<Event> {
            if sync_mesh::envelope_from_metadata(&stored.event)?.is_some() {
                return Ok(stored.event.clone());
            }
            let envelope =
                sync_mesh::envelope_for_event_based(&self.sync_state.node_id, base, stored)?;
            event_with_sync_metadata(stored.event.clone(), &envelope)
        };
        let mut retained = Vec::with_capacity(events.stored_events().len());
        for stored in events.stored_events() {
            old_log_end = old_log_end.max(stored.offset.saturating_add(1));
            if stored.event.stream != RECORD_AUDIT_STREAM {
                retained.push(freeze(stored)?);
                continue;
            }
            let Some(mutation) = AuditMutation::from_event_based(
                &self.sync_state.node_id,
                self.sync_state.origin_position_base,
                stored,
            )?
            else {
                // Unrecognized record-audit subtype: retain conservatively.
                retained.push(stored.event.clone());
                continue;
            };
            let key = (mutation.collection, mutation.record_id);
            match winners.get(&key) {
                Some((winner_id, _, is_delete, offset)) if *winner_id == stored.event.id => {
                    if *is_delete && *offset <= acknowledged.event_offset {
                        report.deletes_dropped += 1;
                    } else {
                        retained.push(freeze(stored)?);
                    }
                }
                Some(_) => report.superseded_dropped += 1,
                None => retained.push(freeze(stored)?),
            }
        }

        report.events_after = retained.len();
        if report.superseded_dropped == 0 && report.deletes_dropped == 0 {
            return Ok(report);
        }

        let (bytes_before, bytes_after) = events.rewrite_events(retained)?;
        report.bytes_before = bytes_before;
        report.bytes_after = bytes_after;
        drop(events);
        self.invalidate_sync_vector_cache();

        // Offsets changed with the rewrite; reset the export watermark just
        // like compact() does (re-exports dedup by event id downstream), and
        // advance the origin-position base past every position ever
        // assigned so future local events stay monotonic for mesh vectors.
        self.sync_state.last_export_offset = 0;
        self.sync_state.last_reconciled_offset = 0;
        self.sync_state.origin_position_base = base.saturating_add(old_log_end);
        self.persist_sync_state()?;
        Ok(report)
    }

    pub fn compact_with_options(&mut self, options: CompactionOptions) -> Result<CompactionReport> {
        let started = Instant::now();
        let pause_started = Instant::now();
        if !options.allow_pending {
            self.ensure_no_pending_transactions()?;
        }
        let collections = self
            .collections()
            .into_iter()
            .map(|collection| collection.name)
            .collect::<Vec<_>>();
        let tx_log_before = file_len(&self.tx_log_path())?;
        let event_log_before = file_len(&event_segment_path_for(&self.path))?;
        let sync_log_before = file_len(&self.path.join("sync.log"))?;
        let index_metadata_bytes = file_len(&self.path.join(DEFAULT_INDEX_CATALOG))?;
        let sidecar_bytes = self.sidecar_bytes()?;
        let checkpoint_id = Uuid::new_v4().to_string();

        let mut report = CompactionReport {
            checkpoint_id: Some(checkpoint_id.clone()),
            transaction_log_bytes_before: tx_log_before,
            event_log_bytes_before: event_log_before,
            sync_log_bytes_before: sync_log_before,
            index_metadata_bytes,
            sidecar_bytes,
            ..Default::default()
        };
        self.write_compaction_checkpoint(
            &checkpoint_id,
            CompactionCheckpointPhase::Started,
            &collections,
            tx_log_before,
            event_log_before,
            sync_log_before,
        )?;
        for collection in collections {
            let collection_report = self.compact_collection_inner(&collection)?;
            let bytes_before = collection_report.bytes_before;
            report.live_records += collection_report.live_records;
            report.bytes_before += collection_report.bytes_before;
            report.bytes_after += collection_report.bytes_after;
            report.bytes_reclaimed += collection_report.bytes_reclaimed;
            report.collections.push(collection_report);
            throttle_compaction_io(&options, bytes_before)?;
        }
        report.bytes_scanned = report
            .bytes_before
            .saturating_add(tx_log_before)
            .saturating_add(event_log_before)
            .saturating_add(sync_log_before)
            .saturating_add(index_metadata_bytes)
            .saturating_add(sidecar_bytes);
        report.dead_records = estimate_dead_records(&report.collections);
        if !options.force
            && options.reclaim_threshold_percent > 0
            && reclaim_percent(report.bytes_before, report.bytes_reclaimed)
                < options.reclaim_threshold_percent
        {
            self.write_compaction_checkpoint(
                report.checkpoint_id.as_deref().unwrap_or(""),
                CompactionCheckpointPhase::Committed,
                &report
                    .collections
                    .iter()
                    .map(|collection| collection.collection.clone())
                    .collect::<Vec<_>>(),
                tx_log_before,
                event_log_before,
                sync_log_before,
            )?;
            report.transaction_log_bytes_after = tx_log_before;
            report.event_log_bytes_after = event_log_before;
            report.sync_log_bytes_after = sync_log_before;
            report.duration_ms = duration_millis(started.elapsed());
            report.pause_time_ms = duration_millis(pause_started.elapsed());
            return Ok(report);
        }

        let compacted_collections = report
            .collections
            .iter()
            .map(|collection| collection.collection.clone())
            .collect::<Vec<_>>();
        self.write_compaction_checkpoint(
            &checkpoint_id,
            CompactionCheckpointPhase::RecordsRewritten,
            &compacted_collections,
            tx_log_before,
            event_log_before,
            sync_log_before,
        )?;
        // Flush any commits whose durable write was still deferred before we
        // discard the log file, then drop the handle so the next commit reopens
        // the fresh (truncated) log. We hold the write lock, so no new commit can
        // enqueue concurrently.
        self.tx_log.flush_pending()?;
        self.cut_transaction_log(u64::MAX, self.commit_seq.load(AtomicOrdering::SeqCst))?;
        self.tx_log.invalidate();
        self.tx_states
            .retain(|_, state| *state == TxState::Committed);
        let (event_before, event_after, frozen_end) = {
            let mut events = self.events.lock();
            // Enforce configured broker retention before compacting so the
            // rewrite drops trimmable queue history in the same pass.
            events.broker().trim_configured()?;
            let frozen_end = self.freeze_local_event_positions(&mut events)?;
            let (before, after) = events.compact()?;
            (before, after, frozen_end)
        };
        self.invalidate_sync_vector_cache();
        let (sync_before, sync_after) = self
            .sync_log
            .get_mut()
            .compact(self.commit_seq.load(AtomicOrdering::SeqCst))?;
        self.sync_state.last_export_offset = 0;
        self.sync_state.last_reconciled_offset = 0;
        self.sync_state.origin_position_base = self
            .sync_state
            .origin_position_base
            .saturating_add(frozen_end);
        report.event_log_bytes_before = event_before;
        report.event_log_bytes_after = event_after;
        report.sync_log_bytes_before = sync_before;
        report.sync_log_bytes_after = sync_after;
        report.transaction_log_bytes_after = file_len(&self.tx_log_path())?;
        self.write_compaction_checkpoint(
            &checkpoint_id,
            CompactionCheckpointPhase::LogsCheckpointed,
            &compacted_collections,
            tx_log_before,
            event_log_before,
            sync_log_before,
        )?;
        self.persist_catalog()?;
        self.persist_index_catalog()?;
        self.persist_sync_state()?;
        self.write_compaction_checkpoint(
            &checkpoint_id,
            CompactionCheckpointPhase::Committed,
            &compacted_collections,
            tx_log_before,
            event_log_before,
            sync_log_before,
        )?;
        // We are now at a quiescent point: segments hold exactly the live records,
        // the WAL is truncated, and the heap equals that state. Publish the binary
        // startup snapshot LAST (it is the commit marker) so the next open can skip
        // the JSON segment reparse. Opt-in; a write failure is non-fatal (the open
        // path always falls back to segments).
        if self.config.snapshot {
            if let Err(error) = self.write_startup_snapshot() {
                eprintln!("[snapshot] write failed (ignored): {error}");
            }
        }
        report.duration_ms = duration_millis(started.elapsed());
        report.pause_time_ms = duration_millis(pause_started.elapsed());
        Ok(report)
    }

    /// Serialize every live record into the binary startup snapshot. Called at the
    /// end of a full [`Self::compact`]. See [`crate::snapshot`].
    pub(crate) fn write_startup_snapshot(&self) -> Result<()> {
        let watermark = self.last_commit_seq();
        let mut names: Vec<String> = self.collections.keys().cloned().collect();
        names.sort();

        let mut frames: Vec<Vec<u8>> = Vec::new();
        let mut collection_metas = Vec::with_capacity(names.len());
        for name in names {
            let state = self.collection_state(&name)?;
            let guards = state.read_all();
            let records: Vec<&StoredRecord> = guards
                .iter()
                .flat_map(|shard| shard.records.values())
                .map(|entry| entry.record.as_ref())
                .collect();
            let record_count = records.len() as u64;
            let segment_frame_count = state.segment_frame_count;
            frames.extend(crate::snapshot::encode_collection_chunks(&name, &records));
            drop(guards);
            drop(state);
            // File size AFTER the compaction rewrote this segment. On open we compare
            // the live segment size against this; a post-snapshot commit appends to
            // the segment and grows it, so a mismatch means "stale" -> fall back.
            let segment_byte_len = match fs::metadata(self.segment_path(&name)) {
                Ok(meta) => meta.len(),
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => 0,
                Err(error) => return Err(error.into()),
            };
            collection_metas.push(crate::snapshot::SnapshotCollection {
                name,
                record_count,
                segment_frame_count,
                segment_byte_len,
            });
        }

        let manifest = crate::snapshot::SnapshotManifest {
            format_version: crate::snapshot::SNAPSHOT_FORMAT_VERSION,
            watermark_commit_seq: watermark,
            created_unix: unix_timestamp(),
            collections: collection_metas,
        };
        crate::snapshot::write_snapshot(
            &self.path,
            &manifest,
            &frames,
            self.config.fsync,
            &self.config.compression,
            &self.encryption,
        )
    }

    pub fn compact_collection(&mut self, collection: &str) -> Result<CompactionReport> {
        self.ensure_no_pending_transactions()?;
        self.ensure_collection(collection)?;
        let started = Instant::now();
        let collection_report = self.compact_collection_inner(collection)?;
        Ok(CompactionReport {
            live_records: collection_report.live_records,
            bytes_scanned: collection_report.bytes_before,
            bytes_before: collection_report.bytes_before,
            bytes_after: collection_report.bytes_after,
            bytes_reclaimed: collection_report.bytes_reclaimed,
            duration_ms: duration_millis(started.elapsed()),
            pause_time_ms: duration_millis(started.elapsed()),
            collections: vec![collection_report],
            ..CompactionReport::default()
        })
    }

    /// Machine-readable resident-memory accounting (see [`crate::residency`]).
    ///
    /// Phase 0 of `docs/server-paged-storage-todo.md`: every later gate in that
    /// roadmap is a bound on memory, and none can be evaluated without first
    /// attributing the bytes. The figures are estimates walked from the live
    /// structures — read the module docs before treating any of them as exact.
    ///
    /// This walks every resident record, so it is a diagnostic, not something to
    /// call per request. It takes only read locks and never blocks writers for
    /// longer than one shard at a time.
    pub fn residency_report(&self) -> Result<ResidencyReport> {
        let mut report = ResidencyReport::default();

        for (name, state) in &self.collections {
            let state = state.read();
            let mut collection = residency::CollectionResidency {
                name: name.clone(),
                ..Default::default()
            };
            for shard in state.read_all() {
                let shard = shard.residency();
                collection.record_count += shard.record_count;
                collection.version_count += shard.version_count;
                collection.rows_bytes += shard.rows_bytes;
                collection.version_chains_bytes += shard.version_chains_bytes;
                collection.primary_key_maps_bytes += shard.primary_key_maps_bytes;
            }
            collection.exact_vectors_bytes = state.vector_store.read().heap_bytes();
            report.collections.push(collection);
        }
        report.collections.sort_by(|a, b| a.name.cmp(&b.name));

        for (name, index) in &self.indexes {
            let index = index.read();
            report.indexes.push(residency::IndexResidency {
                name: name.clone(),
                collection: index.definition.collection.clone(),
                entry_count: index.store.total_entries() as u64,
                store_bytes: index.store.resident_bytes(),
                spatial_bytes: index.spatial.as_ref().map_or(0, |tree| {
                    residency::vec_bytes::<SpatialIndexEntry>(tree.size())
                }),
            });
        }
        report.indexes.sort_by(|a, b| a.name.cmp(&b.name));

        for (collection, index) in self.hnsw_indexes.read().iter() {
            report.hnsw.push(index.residency(collection));
        }
        report.hnsw.sort_by(|a, b| a.collection.cmp(&b.collection));

        report.graphs_bytes = self
            .graphs
            .read()
            .values()
            .map(|graph| std::mem::size_of::<GraphProjectionData>() as u64 + graph.heap_bytes())
            .sum();

        Ok(report.finalize(unix_timestamp()))
    }

    /// Return bounded operational telemetry for the server-paged engine.
    ///
    /// Embedded databases return `None`. This call never scans records, index
    /// entries, page contents, or WAL records and is safe for periodic metrics
    /// collection regardless of total database size.
    pub fn paged_storage_snapshot(&self) -> Result<Option<bicdb_page::PagedStoreSnapshot>> {
        self.paged_records
            .as_ref()
            .map(|paged| paged.storage_snapshot())
            .transpose()
    }

    /// Mirror a committed transaction's record writes into the paged store.
    ///
    /// No-op in `embedded_memory`. In `server_paged` this is what makes the page
    /// engine the durable home for rows: the same writes that updated the
    /// resident state are committed to pages under one transaction, so a crash
    /// recovers them through the page WAL rather than the segment log.
    pub(crate) fn apply_record_writes_to_paged(
        &self,
        writes_by_collection: &BTreeMap<&str, Vec<&TxWrite>>,
        deferred_page_commit: Option<&mut Option<bicdb_page::Lsn>>,
    ) -> Result<Option<bicdb_page::Xid>> {
        if writes_by_collection.is_empty() {
            return Ok(None);
        }
        // B-tree index definitions on this collection: their durable entries
        // are maintained in the SAME paged transaction as the rows, which is
        // what makes the index crash-consistent by construction — recovery
        // keeps or discards row and entries together, so a restart never needs
        // a corpus-wide rebuild to trust them (Phase 4's exit gate).
        // Resolve index metadata before taking the paged writer gate, preserving
        // the existing index-before-page lock order. All collections must share
        // ONE physical commit: per-collection commits recover a partial SQL
        // transaction if a later write or WAL sync fails.
        let prepared = writes_by_collection
            .iter()
            .map(|(&collection, writes)| {
                Ok((
                    collection,
                    writes,
                    self.paged_durable_index_defs(collection)?,
                ))
            })
            .collect::<Result<Vec<_>>>()?;
        self.in_paged_transaction_inner(true, deferred_page_commit, |paged, xid| {
            for (collection, writes, index_defs) in prepared {
                // Pre-image reads for index maintenance: the row state before this
                // transaction, overlaid with earlier writes in this same batch so
                // an upsert-then-delete of one key within a batch resolves in
                // order.
                let pre_snapshot = bicdb_page::Snapshot {
                    xid: 0,
                    xmax: xid,
                    in_flight: empty_in_flight(),
                };
                let mut batch_state: FxHashMap<&str, Option<Record>> = FxHashMap::default();
                for write in writes {
                    let previous = match batch_state.get(write.record_id.as_str()) {
                        Some(previous) => previous.clone(),
                        None if index_defs.is_empty() => None,
                        None => paged.get(&pre_snapshot, collection, &write.record_id)?,
                    };
                    match write.op {
                        TxWriteOp::Upsert => {
                            let record = write.record()?.ok_or_else(|| BicDbError::Corruption {
                                path: self.tx_log_path(),
                                message: "transaction upsert missing record".to_string(),
                            })?;
                            let locator = paged.put(xid, collection, record)?;
                            apply_paged_index_upsert(
                                paged,
                                xid,
                                collection,
                                &index_defs,
                                previous.as_ref(),
                                record,
                                Some((locator, xid)),
                            )?;
                            batch_state
                                .insert(write.record_id.as_str(), Some(record.as_ref().clone()));
                        }
                        TxWriteOp::Delete => {
                            paged.delete(xid, collection, &write.record_id)?;
                            if let Some(previous) = &previous {
                                apply_paged_index_delete(
                                    paged,
                                    xid,
                                    collection,
                                    &index_defs,
                                    previous,
                                    &write.record_id,
                                )?;
                            }
                            batch_state.insert(write.record_id.as_str(), None);
                        }
                    }
                }
                if std::env::var_os("BICDB_TEST_FAIL_PAGED_COLLECTION_APPLY")
                    .is_some_and(|name| name == collection)
                {
                    return Err(BicDbError::PagedStorage(format!(
                        "injected paged apply failure after collection {collection}"
                    )));
                }
            }
            Ok(())
        })
    }

    /// Names and fields of the B-tree indexes on `collection` whose entries are
    /// durably maintained in the page store. B-tree entries are one composite
    /// key per row; full-text entries are one key per TERM of the row's
    /// materialized projection. Spatial, array, and jsonb kinds remain
    /// resident-only for now; their durable form is the rest of Phase 4.
    pub(crate) fn paged_durable_index_defs(
        &self,
        collection: &str,
    ) -> Result<Vec<PagedDurableIndexDef>> {
        if self.paged_records.is_none() {
            return Ok(Vec::new());
        }
        self.indexes
            .values()
            .filter_map(|state| {
                let state = state.read();
                // A spatial index maintains a durable delta tail when packed
                // OR while a packed build is in flight (the delta is what
                // makes resuming that build sound); a plain resident spatial
                // index writes nothing durable.
                (state.definition.collection == collection
                    && (matches!(
                        state.definition.kind,
                        IndexKind::BTree | IndexKind::FullText
                    ) || (state.definition.kind == IndexKind::Spatial
                        && (state.packed_spatial.is_some() || state.spatial_delta_durable))))
                    .then(|| {
                        // The format read must not fail silently: writing v2
                        // entries into a v3 index is corruption, not degradation.
                        let entry_format = match self.paged_records.as_ref() {
                            Some(paged) => paged.entry_format_cached(&state.definition.name)?,
                            None => crate::paged_collection::IndexEntryFormat::V2,
                        };
                        Ok(PagedDurableIndexDef {
                            nulls_not_distinct: state.definition.nulls_not_distinct,
                            name: state.definition.name.clone(),
                            fields: state.definition.fields.clone(),
                            kind: state.definition.kind.clone(),
                            predicate: state.definition.predicate.clone(),
                            entry_format,
                            unique: state.definition.unique,
                        })
                    })
            })
            .collect()
    }

    /// Run `apply` against the paged store inside one transaction, committing on
    /// success and aborting on any error.
    ///
    /// No-op in `embedded_memory`, where `apply` is never called.
    ///
    /// Aborting rather than leaving the transaction open matters: an abandoned
    /// paged transaction never commits, so its versions stay invisible forever
    /// while still occupying pages. Every write path into the paged store goes
    /// through here so that discipline is stated once rather than repeated —
    /// getting it wrong in one path is a silent partial write.
    /// Returns the paged transaction id on success (`None` in embedded mode),
    /// which is what eviction stubs pin their as-of reads to.
    pub(crate) fn in_paged_transaction<F>(&self, apply: F) -> Result<Option<bicdb_page::Xid>>
    where
        F: FnOnce(&crate::paged_collection::PagedRecords, bicdb_page::Xid) -> Result<()>,
    {
        self.in_paged_transaction_inner(false, None, apply)
    }

    fn in_paged_transaction_inner<F>(
        &self,
        durable_decision: bool,
        deferred_page_commit: Option<&mut Option<bicdb_page::Lsn>>,
        apply: F,
    ) -> Result<Option<bicdb_page::Xid>>
    where
        F: FnOnce(&crate::paged_collection::PagedRecords, bicdb_page::Xid) -> Result<()>,
    {
        let Some(paged) = &self.paged_records else {
            return Ok(None);
        };
        // Held across begin..commit so no other batch's operations interleave
        // with this one — see `PagedStore::write_guard`. Without it, two
        // core-committed batches could interleave puts and commits, producing
        // spurious conflicts, orphaned versions, and stubs pinned to
        // transactions that do not contain their own rows.
        let _guard = paged.write_guard();
        self.check_recovery_state()?;
        // Every page apply uses the same structural admission. The logical
        // decision controls recovery/error handling, never an eviction waiver.
        let (xid, _) = paged.begin();
        match apply(paged, xid) {
            Ok(()) => {
                let committed = match deferred_page_commit {
                    Some(lsn) => paged.commit_deferred(xid).map(|commit| *lsn = Some(commit)),
                    None => paged.commit(xid),
                };
                if let Err(error) = committed {
                    self.fence_durability("paged.commit", &error);
                    if durable_decision {
                        // The caller holds a durable transaction-log
                        // decision and reports the outcome with its
                        // commit sequence.
                        return Err(error);
                    }
                    // Here the page-log commit record is the decision, and
                    // it may have reached the disk: never a refused write.
                    return Err(BicDbError::CommitOutcomeUnknown {
                        sequence: None,
                        transaction_id: None,
                        incarnation: self.incarnation.clone(),
                        detail: format!("page transaction {xid} did not commit cleanly: {error}"),
                    });
                }
                Ok(Some(xid))
            }
            Err(error) => {
                if let Err(abort_error) = paged.abort(xid) {
                    self.fence_durability("paged.abort", &abort_error);
                } else if durable_decision {
                    self.fence_durability("commit.materialize", &error);
                }
                Err(error)
            }
        }
    }

    /// The eviction context for rows written to `collection` by paged
    /// transaction `xid`: a shared fetch that resolves a primary key to its
    /// record **as of that transaction**, pinned so a superseded version's stub
    /// keeps answering with the value it had when it was current (see
    /// `EvictedPayload`). One allocation per commit batch, shared by every row
    /// in it.
    pub(crate) fn paged_stub_fetch(
        &self,
        collection: &str,
        xid: bicdb_page::Xid,
    ) -> Option<PagedStubFetch> {
        Some(self.paged_apply_ctx(collection, xid)?.post)
    }

    /// Both pinned fetches for one commit batch: `post` (as of the batch's own
    /// paged transaction) and `pre` (the instant before it — the pre-image used
    /// to seed baselines on lazy collections). See [`PagedApplyCtx`].
    pub(crate) fn paged_apply_ctx(
        &self,
        collection: &str,
        xid: bicdb_page::Xid,
    ) -> Option<PagedApplyCtx> {
        let paged = Arc::clone(self.paged_records.as_ref()?);
        let physical: Arc<str> = Arc::from(paged.physical_collection(collection).as_ref());
        let post_snapshot = bicdb_page::Snapshot {
            xid,
            xmax: xid + 1,
            in_flight: empty_in_flight(),
        };
        // `xmax = xid` excludes the transaction itself: everything committed
        // strictly before it — the pre-image. `xid: 0` (a read outside any
        // transaction), NOT the batch's xid: a snapshot's own transaction sees
        // its own writes, which is precisely what the pre-image must not.
        let pre_snapshot = bicdb_page::Snapshot {
            xid: 0,
            xmax: xid,
            in_flight: empty_in_flight(),
        };
        let post = {
            let paged = Arc::clone(&paged);
            let physical = Arc::clone(&physical);
            Arc::new(move |pk: &str| paged.get_physical_record(&post_snapshot, &physical, pk))
                as PagedStubFetch
        };
        let pre = Arc::new(move |pk: &str| paged.get_physical_record(&pre_snapshot, &physical, pk))
            as PagedStubFetch;
        Some(PagedApplyCtx { xid, post, pre })
    }

    pub fn stats(&self) -> Result<DbStats> {
        self.check_recovery_state()?;
        let mut collections = self
            .collections
            .values()
            .map(|state| {
                let state = state.read();
                let segment_bytes = storage::seek_to_end(&self.segment_path(&state.meta.name))?;
                // In paged mode the page store is the complete view (shards may
                // be a touched-rows cache), so count and logical bytes come
                // from one scan of it. O(rows) I/O per call, bounded by the
                // buffer pool — stats is an operator action, not a hot path.
                if let Some(paged) = &self.paged_records {
                    let snapshot = paged.latest_snapshot();
                    let mut record_count = 0usize;
                    let mut logical_record_bytes = 0u64;
                    for record in paged.scan(&snapshot, &state.meta.name)? {
                        let record = record?;
                        record_count += 1;
                        logical_record_bytes += serde_json::to_vec(&record)?.len() as u64;
                    }
                    return Ok(CollectionStats {
                        name: state.meta.name.clone(),
                        mode: state.meta.mode.clone(),
                        vector_dim: state.meta.vector_dim,
                        record_count,
                        segment_bytes,
                        logical_record_bytes,
                        storage_overhead_bytes: segment_bytes.saturating_sub(logical_record_bytes),
                        last_segment_offset: None,
                    });
                }
                // `wire_bytes_len` rather than serializing the entry directly:
                // the resident entry may be an eviction stub, and the caller
                // asked how big the rows are, not the resident representation.
                let logical_record_bytes = state
                    .read_all()
                    .iter()
                    .flat_map(|shard| shard.records.values())
                    .map(|entry| entry.record.wire_bytes_len())
                    .collect::<std::result::Result<Vec<_>, _>>()?
                    .into_iter()
                    .sum();
                let last_segment_offset = state
                    .read_all()
                    .iter()
                    .flat_map(|shard| shard.records.values())
                    .map(|entry| entry.offset)
                    .max();
                Ok(CollectionStats {
                    name: state.meta.name.clone(),
                    mode: state.meta.mode.clone(),
                    vector_dim: state.meta.vector_dim,
                    record_count: state.record_count(),
                    segment_bytes,
                    logical_record_bytes,
                    storage_overhead_bytes: segment_bytes.saturating_sub(logical_record_bytes),
                    last_segment_offset,
                })
            })
            .collect::<Result<Vec<_>>>()?;
        collections.sort_by(|left, right| left.name.cmp(&right.name));

        let record_count = collections
            .iter()
            .map(|collection| collection.record_count)
            .sum();

        Ok(DbStats {
            path: self.path.clone(),
            collection_count: collections.len(),
            record_count,
            pending_sync_ops: self.pending_sync_ops().len(),
            size_bytes: storage::total_dir_size(&self.path)?,
            collections,
        })
    }

    pub fn flush(&self) -> Result<()> {
        if self.config.fsync {
            return Ok(());
        }
        format::persist_current(&self.path, self.config.fsync)?;
        self.persist_catalog()?;
        self.persist_sync_state()?;
        self.persist_ha_state()?;
        for name in self.collections.keys() {
            storage::sync_file(&self.segment_path(name))?;
        }
        storage::sync_file(&self.tx_log_path())?;
        self.events.lock().flush()?;
        self.sync_log.lock().flush()
    }

    /// Everything [`Self::close`] makes durable, without closing: the paged
    /// store checkpoints (bounding its WAL), the core transaction log is
    /// bounded, and segment/log files flush. Bulk importers call this as a
    /// resume barrier between batches — the previous pattern of
    /// close+reopen per checkpoint paid a full recovery scan every cycle,
    /// and the cost grows with the store.
    pub fn checkpoint_for_resume(&self) -> Result<()> {
        let _admission = self.serializable_commit_admission.write();
        self.check_recovery_state()?;
        self.tx_log.flush_pending()?;
        if let Some(paged) = &self.paged_records {
            paged.checkpoint()?;
            let log_path = self.tx_log_path();
            let log_len = file_len(&log_path)?;
            if log_len > 0 {
                self.cut_transaction_log(log_len, self.commit_seq.load(AtomicOrdering::SeqCst))?;
            }
        }
        self.flush()
    }

    /// Online, checkpoint-consistent backup of a live paged database:
    /// TWO chained artifacts, streamed while writes continue.
    ///
    /// 1. `base_path` — a full archive whose page segments and active WAL
    ///    are copied fuzzily (size-pinned, unhashed) under a backup pin
    ///    that defers WAL truncation and page-tail reclaim. Pages stream
    ///    BEFORE any WAL byte.
    /// 2. `wal_tail_path` — after the base completes, the active WAL is
    ///    sealed and an incremental ships the sealed, immutable segment
    ///    chain. Because the WAL is a physical page-image log with a
    ///    writeback barrier, that chain covers every page state the base
    ///    copy could have observed.
    ///
    /// Restore applies both in order; opening the restored directory
    /// replays the sealed chain and truncates the base's stale active-WAL
    /// copy at its LSN discontinuity — exactly a crash at the seal point.
    /// Requires an extent-segmented store (`bicdb store segment` migrates).
    pub fn create_online_backup(
        &self,
        base_path: impl AsRef<Path>,
        wal_tail_path: impl AsRef<Path>,
        options: crate::backup::BackupCreateOptions,
    ) -> Result<OnlineBackupReport> {
        let Some(paged) = &self.paged_records else {
            return Err(BicDbError::Backup(
                "online backup requires server_paged storage".to_string(),
            ));
        };
        // This compatibility API has no owned core snapshot. Keep its core
        // history fixed for both artifacts; raw page-store traffic can still
        // run under the WAL pin. New live callers should capture an owned v4
        // snapshot and release their host guard before copying.
        self.checkpoint_for_resume()?;
        let _quiesced = self.serializable_commit_admission.write();
        self.tx_log_handle()
            .write_durable(self.last_applied_commit_seq())?;
        online_backup_pinned(
            paged,
            &self.path,
            base_path.as_ref(),
            wal_tail_path.as_ref(),
            options,
            || Ok(()),
        )
    }

    /// Continuous WAL archiving: seal the active WAL (the cut), copy every
    /// sealed segment the archive does not already hold into
    /// `destination`, fsync, and release the copied segments for local
    /// checkpoint truncation. Call on a cadence — the archive's freshness
    /// IS the recovery point objective.
    ///
    /// The first call enables archive retention, persistently (it survives
    /// reopens until [`Self::disable_wal_archiving`]): sealed segments
    /// survive local truncation until archived, so a stalled archiver grows
    /// the local WAL directory (deliberately: space traded for a gap-free
    /// archive) rather than gapping the archive. Roll a
    /// restore forward with [`apply_archived_wal`]: restore an online-backup
    /// chain, apply the archive, open.
    ///
    /// Fail-closed: a segment counts as archived (and local truncation may
    /// delete it) only after its bytes AND its directory entry are durable in
    /// the archive, confirmed by this handle's own fsyncs. A segment already
    /// in the archive that this handle has not confirmed is compared and
    /// copied again rather than trusted. The first failed step stops the
    /// archiver for this handle ([`Self::wal_archive_failure`]): nothing more
    /// is marked archived and nothing unarchived is deleted, until a
    /// reopened handle copies every unconfirmed segment again. The database
    /// itself stays writable. See `docs/durability-failure-handling.md`.
    pub fn archive_wal_segments(&self, destination: impl AsRef<Path>) -> Result<WalArchiveReport> {
        let Some(paged) = &self.paged_records else {
            return Err(BicDbError::Backup(
                "WAL archiving requires server_paged storage".to_string(),
            ));
        };
        let store = paged.store();
        let wal = store.wal();
        if let Some(failure) = wal.archive_health().failure() {
            return Err(page_archive_error(failure));
        }
        // Retention first: from here on nothing unconfirmed is deleted.
        store
            .enable_wal_archive_retention()
            .map_err(crate::error::durability_error)?;
        let destination = destination.as_ref();
        let fsync = self.config.fsync;
        let fail = |site: &str, path: &Path, error: &dyn std::fmt::Display| {
            page_archive_error(wal.record_archive_failure(site, path, error))
        };
        if !destination.is_dir() {
            fs::create_dir_all(destination)
                .map_err(|error| fail("wal_archive.create", destination, &error))?;
            if fsync {
                sync_parent_dir("wal_archive.dir_sync", destination)
                    .map_err(|error| fail("wal_archive.dir_sync", destination, &error))?;
            }
        }
        wal.set_archive_destination(destination);
        // Read back the confirmed prefix before advancing it: on a new
        // handle, periodically, and while an earlier verification is
        // recorded as failed. A failure stops this archiver (nothing more is
        // confirmed, nothing local released).
        let previous_failed =
            crate::archive_guard::load_verification(&page_log_verification_path(wal.path()))
                .is_some_and(|verification| !verification.ok);
        let interval = crate::archive_guard::ArchiveGuardConfig::from_env()
            .map(|config| config.verify_interval)
            .unwrap_or_else(|_| {
                crate::archive_guard::ArchiveGuardConfig::default().verify_interval
            });
        let due = previous_failed
            || wal
                .archive_verified_at()
                .is_none_or(|at| at.elapsed() >= interval);
        if due {
            let verification = self.verify_wal_archive_at(destination)?;
            if !verification.ok {
                return Err(page_archive_error(
                    wal.archive_health()
                        .failure()
                        .expect("a failed verification records a failure"),
                ));
            }
        }
        let sealed = store
            .seal_wal_for_backup()
            .map_err(|error| BicDbError::Backup(error.to_string()))?;
        let confirmed = wal.archived_through();
        let mut report = WalArchiveReport {
            archived: 0,
            bytes: 0,
            archived_through: None,
            skipped: 0,
        };
        for path in sealed {
            let name = path
                .file_name()
                .and_then(|name| name.to_str())
                .ok_or_else(|| {
                    BicDbError::Backup(format!(
                        "sealed WAL segment {} has no readable name",
                        path.display()
                    ))
                })?
                .to_string();
            let sequence: u64 = name
                .rsplit('.')
                .next()
                .and_then(|suffix| suffix.parse().ok())
                .ok_or_else(|| {
                    BicDbError::Backup(format!("sealed WAL segment {name} has no sequence"))
                })?;
            if sequence <= confirmed {
                // Confirmed durable by this handle earlier.
                report.skipped += 1;
                continue;
            }
            let target = destination.join(&name);
            let source_len = fs::metadata(&path)?.len();
            match fs::metadata(&target) {
                Ok(existing) if existing.len() != source_len => {
                    return Err(fail(
                        "wal_archive.mismatch",
                        &target,
                        &format!(
                            "archive already holds {name} with {} bytes but the store's copy \
                             has {source_len}; refusing to overwrite an archived segment",
                            existing.len()
                        ),
                    ));
                }
                Ok(_) => {
                    // Present but not confirmed by this handle: an earlier
                    // run may have failed after the rename, so its bytes or
                    // entry are not proven durable. Same bytes are copied
                    // again (fresh writes this handle syncs itself); other
                    // bytes are refused.
                    let same = files_equal(&path, &target)
                        .map_err(|error| fail("wal_archive.copy", &target, &error))?;
                    if !same {
                        return Err(fail(
                            "wal_archive.mismatch",
                            &target,
                            &format!(
                                "archive already holds {name} with different contents; \
                                 refusing to overwrite an archived segment"
                            ),
                        ));
                    }
                }
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
                Err(error) => return Err(fail("wal_archive.copy", &target, &error)),
            }
            // Copy through a temp name + rename so a torn copy can never be
            // mistaken for an archived segment.
            let staging = destination.join(format!("{name}.partial"));
            let copied = (|| -> std::result::Result<(), (&'static str, std::io::Error)> {
                bicdb_page::test_faults::io_fault("wal_archive.copy", &staging)
                    .and_then(|()| fs::copy(&path, &staging).map(|_| ()))
                    .map_err(|error| ("wal_archive.copy", error))?;
                if fsync {
                    bicdb_page::test_faults::io_fault("wal_archive.sync", &staging)
                        .and_then(|()| File::open(&staging))
                        .and_then(|copied| copied.sync_all())
                        .map_err(|error| ("wal_archive.sync", error))?;
                }
                bicdb_page::test_faults::io_fault("wal_archive.rename", &target)
                    .and_then(|()| fs::rename(&staging, &target))
                    .map_err(|error| ("wal_archive.rename", error))
            })();
            if let Err((site, error)) = copied {
                let _ = fs::remove_file(&staging);
                return Err(fail(site, &target, &error));
            }
            bicdb_page::test_faults::crash_point("wal_archive.after_rename");
            report.archived += 1;
            report.bytes = report.bytes.saturating_add(source_len);
            report.archived_through = Some(
                report
                    .archived_through
                    .map_or(sequence, |max| max.max(sequence)),
            );
        }
        // The renames are only durable once the directory is; a swallowed
        // failure here used to release segments whose archive entry a crash
        // could still lose.
        if fsync && report.archived > 0 {
            bicdb_page::test_faults::io_fault("wal_archive.dir_sync", destination)
                .and_then(|()| File::open(destination))
                .and_then(|dir| dir.sync_all())
                .map_err(|error| fail("wal_archive.dir_sync", destination, &error))?;
        }
        bicdb_page::test_faults::crash_point("wal_archive.before_mark");
        if let Some(through) = report.archived_through {
            store
                .mark_wal_archived_through(through)
                .map_err(crate::error::durability_error)?;
        }
        report.archived_through = report
            .archived_through
            .or((confirmed > 0).then_some(confirmed));
        Ok(report)
    }

    /// Read back the page-log archive's confirmed prefix (every archived
    /// segment up to the confirmed one: record checksums, no torn segment,
    /// LSN continuity) and persist the result. A failure stops the page-log
    /// archiver on this handle. `None` when this handle has not archived
    /// anywhere yet.
    pub fn verify_wal_archive(&self) -> Result<Option<crate::archive_guard::ArchiveVerification>> {
        let Some(paged) = &self.paged_records else {
            return Ok(None);
        };
        let Some(destination) = paged.store().wal().archive_destination() else {
            return Ok(None);
        };
        self.verify_wal_archive_at(&destination).map(Some)
    }

    fn verify_wal_archive_at(
        &self,
        destination: &Path,
    ) -> Result<crate::archive_guard::ArchiveVerification> {
        let paged = self.paged_records.as_ref().ok_or_else(|| {
            BicDbError::Backup("WAL archiving requires server_paged storage".into())
        })?;
        let wal = paged.store().wal();
        let through = wal.archived_through();
        let result = bicdb_page::wal::verify_archived_segments(destination, through);
        let verification = crate::archive_guard::ArchiveVerification {
            archive: "page_log".into(),
            ok: result.is_ok(),
            at_unix_millis: crate::archive_guard::unix_millis(),
            through,
            detail: match &result {
                Ok(report) => format!(
                    "{} segment(s), {} record(s), LSN {:?}..{:?}",
                    report.segments, report.records, report.first_lsn, report.last_lsn
                ),
                Err(error) => error.to_string(),
            },
        };
        crate::archive_guard::store_verification(
            &page_log_verification_path(wal.path()),
            &verification,
            self.config.fsync,
        )?;
        wal.set_archive_verified_now();
        if !verification.ok {
            wal.record_archive_failure("wal_archive.verify", destination, &verification.detail);
        }
        Ok(verification)
    }

    /// The last persisted page-log archive verification.
    pub fn page_log_archive_verification(
        &self,
    ) -> Option<crate::archive_guard::ArchiveVerification> {
        let paged = self.paged_records.as_ref()?;
        crate::archive_guard::load_verification(&page_log_verification_path(
            paged.store().wal().path(),
        ))
    }

    /// The page-log archiver's first failure on this handle, if any. While
    /// set, [`Self::archive_wal_segments`] refuses and local sealed segments
    /// are retained.
    pub fn wal_archive_failure(&self) -> Option<crate::WriteFailure> {
        self.paged_records
            .as_ref()
            .and_then(|paged| paged.store().wal().archive_health().failure())
    }

    /// Page-log archive state, including the local bytes retention keeps
    /// for it. `None` outside paged storage.
    pub fn wal_archive_status(&self) -> Option<crate::db::WalArchiveStatus> {
        let paged = self.paged_records.as_ref()?;
        let wal = paged.store().wal();
        let (unarchived_segments, unarchived_bytes) = wal.unarchived_sealed();
        Some(crate::db::WalArchiveStatus {
            retention_enabled: wal.archive_retention_enabled(),
            archived_through: wal.archived_through(),
            unarchived_segments,
            unarchived_bytes,
            failure: wal.archive_health().failure(),
        })
    }

    /// Whether this paged store keeps unarchived sealed segments
    /// (persistent; see [`Self::archive_wal_segments`]).
    pub fn wal_archive_retention_enabled(&self) -> bool {
        self.paged_records
            .as_ref()
            .is_some_and(|paged| paged.store().wal().archive_retention_enabled())
    }

    /// Stop page-log archiving on purpose: the next checkpoint deletes
    /// sealed segments whether archived or not.
    pub fn disable_wal_archiving(&self) -> Result<()> {
        let Some(paged) = &self.paged_records else {
            return Ok(());
        };
        paged
            .store()
            .disable_wal_archive_retention()
            .map_err(crate::error::durability_error)
    }

    /// Begin migrating a live monolithic paged store to `extent_bytes`
    /// segment files WITHOUT downtime. Drive it to completion with repeated
    /// [`Self::advance_extent_migration`] calls (a maintenance loop);
    /// crash-safe and resumable — progress is durable in the superblock.
    pub fn begin_extent_migration(&self, extent_bytes: u64) -> Result<()> {
        let Some(paged) = &self.paged_records else {
            return Err(BicDbError::PagedStorage(
                "extent migration requires server_paged storage".to_string(),
            ));
        };
        paged
            .store()
            .buffer_pool()
            .store()
            .begin_extent_migration(extent_bytes)
            .map_err(|error| BicDbError::PagedStorage(error.to_string()))
    }

    /// One bounded online-migration step; see [`Self::begin_extent_migration`].
    pub fn advance_extent_migration(
        &self,
        max_pages: u64,
    ) -> Result<bicdb_page::ExtentMigrationReport> {
        let Some(paged) = &self.paged_records else {
            return Err(BicDbError::PagedStorage(
                "extent migration requires server_paged storage".to_string(),
            ));
        };
        paged
            .store()
            .buffer_pool()
            .store()
            .advance_extent_migration(max_pages)
            .map_err(|error| BicDbError::PagedStorage(error.to_string()))
    }

    pub fn close(self) -> Result<()> {
        self.check_recovery_state()?;
        self.tx_log.flush_pending()?;
        // Paged mode: bound the core transaction log at the session boundary,
        // same contract as the truncation at open (see there for why nothing
        // else bounds it in this mode). Checkpoint the page store first so the
        // log's contents are durably past needing before they are dropped.
        if let Some(paged) = &self.paged_records {
            paged.checkpoint()?;
            let log_path = self.tx_log_path();
            let log_len = file_len(&log_path)?;
            if log_len > 0 {
                self.cut_transaction_log(log_len, self.commit_seq.load(AtomicOrdering::SeqCst))?;
            }
        }
        self.flush()
    }

    pub fn format_metadata(&self) -> Result<FormatMetadata> {
        format::load_metadata(&self.path)?.ok_or_else(|| {
            BicDbError::FormatCompatibility(format!(
                "database is missing required {DEFAULT_FORMAT_METADATA}"
            ))
        })
    }

    pub fn plan_format_migration(path: impl AsRef<Path>) -> Result<FormatMigrationPlan> {
        format::plan_migration(path.as_ref(), true)
    }

    /// Refuse use of a handle whose durable transaction needs redo. Opening a
    /// new handle replays that decision before making the database available.
    pub fn check_recovery_state(&self) -> Result<()> {
        self.durability
            .check()
            .map_err(crate::error::durability_error)
    }

    /// This handle's fail-closed durability state. Never fenced itself, so
    /// operators and status endpoints can read why a database refuses
    /// writes.
    pub fn durability_state(&self) -> bicdb_page::DurabilityState {
        self.durability.state()
    }

    /// The shared durability state, for fault-injection tests that need to
    /// fence the database from a hook. Not an operator API.
    #[doc(hidden)]
    pub fn durability_health_for_test(&self) -> Arc<bicdb_page::DurabilityHealth> {
        self.durability.clone()
    }

    /// Move the database to `WriteFailed` (first failure wins). Every later
    /// write, and every read `check_recovery_state` guards, is refused
    /// until the database is reopened.
    pub(crate) fn fence_durability(&self, site: &str, error: &dyn std::fmt::Display) {
        self.durability.record_failure(site, error);
    }

    /// The commit-outcome error for `sequence` after a durability failure.
    fn commit_outcome_unknown(
        &self,
        transaction_id: u64,
        sequence: u64,
        error: &BicDbError,
    ) -> BicDbError {
        let cause = match self.durability.failure() {
            Some(failure) => format!("the database is fenced by a failure at {failure}"),
            None => error.to_string(),
        };
        BicDbError::CommitOutcomeUnknown {
            sequence: Some(sequence),
            transaction_id: Some(transaction_id),
            incarnation: self.incarnation.clone(),
            detail: format!("{error}; {cause}"),
        }
    }

    /// The verification step of a reopen after a durability failure. Normal
    /// recovery has already run; when the previous handle left the failure
    /// marker, a full checkpoint (page log sync, page flush and sync,
    /// checkpoint record, superblock, transaction-log flush and cut) must
    /// succeed end to end before the database accepts writes. Only then is
    /// the marker removed. A failure keeps the marker and fails the open.
    pub(crate) fn verify_after_durability_failure(&self) -> Result<()> {
        let marker = self.path.join(DURABILITY_FAILURE_MARKER);
        let previous = match std::fs::read(&marker) {
            Ok(bytes) => serde_json::from_slice::<bicdb_page::WriteFailure>(&bytes).ok(),
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(()),
            Err(error) => return Err(error.into()),
        };
        let previous = previous.map_or_else(|| "unreadable marker".to_string(), |f| f.to_string());
        bicdb_page::health::log_event(&serde_json::json!({
            "event": "durability.verify_started",
            "severity": "warn",
            "previous_failure": previous,
        }));
        let verified = (|| -> Result<()> {
            self.checkpoint_for_resume()?;
            // Rewrite the transaction log (copy, fsync, rename, directory
            // fsync) rather than fsync it: after a failed fsync the frames
            // recovery just read may exist only in the page cache, clean but
            // never written, and an fsync of clean pages writes nothing. A
            // copy writes every byte recovery used to a new, synced inode.
            // Embedded mode, or a cut that kept the whole log, would
            // otherwise leave such frames exposed to an OS crash.
            let log = self.tx_log_path();
            if log.exists() {
                let Some(_native_wal_cut) = self.tx_log.native_wal_cut_guard()? else {
                    return Err(BicDbError::HighAvailability(
                        "cannot rewrite recovery WAL while native apply receipts are retained"
                            .into(),
                    ));
                };
                self.tx_log.flush_pending()?;
                let _backup_gate = storage::acquire_database_backup_write_guard(&self.path)?;
                copy_transaction_log_tail(&log, 0, true)?;
                self.tx_log.invalidate();
            }
            // The failure may have been a replacement of an HA or consensus
            // state file whose rename landed but whose directory sync did
            // not. Rewrite both through the full protocol so the vote, term,
            // epoch and role this node now acts on are durable.
            self.ha_node.persist_current()?;
            if self.path.join(DEFAULT_CONSENSUS_STATE).exists() {
                self.persist_consensus_state()?;
            }
            self.check_recovery_state()
        })();
        if let Err(error) = verified {
            return Err(BicDbError::WriteFailed {
                site: "open.verify".into(),
                detail: format!(
                    "verification after the earlier failure ({previous}) did not complete: {error}"
                ),
            });
        }
        std::fs::remove_file(&marker)?;
        if self.config.fsync {
            std::fs::File::open(&self.path)?.sync_all()?;
        }
        bicdb_page::health::log_event(&serde_json::json!({
            "event": "durability.verified",
            "severity": "info",
            "previous_failure": previous,
        }));
        Ok(())
    }

    pub(crate) fn ensure_writable(&self, operation: &str) -> Result<()> {
        self.check_recovery_state()?;
        if self.local_index_maintenance {
            return Ok(());
        }
        // `probe` asks whether this node is a writable primary at all.
        if operation != "probe" {
            self.archive_backpressure.enforce(operation)?;
        }
        let replication_role = self.config.replication.enabled.then(|| self.ha_node.role());
        let reason = if self.ha_state.role == HaRole::Standby
            || replication_role == Some(NodeRole::Standby)
        {
            "on a hot standby/read replica"
        } else if replication_role.is_some() && self.ha_node.is_draining() {
            "while drained for planned switchover"
        } else if replication_role == Some(NodeRole::Fenced) {
            "on a former primary that a newer primary superseded (fenced)"
        } else if replication_role.is_some() && self.sync_quorum.is_closed() {
            "after writer authority closed; restart before accepting writes"
        } else if let Some(refusal) =
            replication_role.and_then(|_| self.sync_quorum.lease_refusal())
        {
            return Err(BicDbError::ReadOnlyStandby(format!(
                "{operation} is refused: {refusal}"
            )));
        } else {
            return Ok(());
        };
        let primary = self.ha_node.read(|file| file.primary_sql_address.clone());
        Err(BicDbError::ReadOnlyStandby(match primary {
            Some(primary) => format!("{operation} is refused {reason}{PRIMARY_MARKER}{primary}"),
            None => format!("{operation} is refused {reason}"),
        }))
    }

    pub(crate) fn persist_ha_state(&self) -> Result<()> {
        persist_ha_state(&self.path, &self.ha_state, self.config.fsync)
    }

    pub(crate) fn persist_consensus_state(&self) -> Result<()> {
        persist_consensus_state(
            &self.path,
            &self.consensus_state,
            self.config.fsync,
            storage::FailClosed::AfterRename(&self.durability),
        )
    }

    /// Applies a transaction (conflict check, in-memory apply) and enqueues its
    /// WAL bytes in commit-sequence order. Returns the commit sequence. The WAL
    /// is NOT fsync'd here; the caller must call `tx_log_handle().write_durable(
    /// seq)` (after releasing the database write lock, so concurrent commits
    /// pipeline and coalesce) before acknowledging the commit.
    pub(crate) fn validate_native_commit_validators(&self, tx: &Transaction) -> Result<()> {
        for validator in &tx.commit_validators {
            match validator {
                NativeCommitValidator::AppendOnly { relation } => {
                    for write in tx
                        .writes
                        .iter()
                        .filter(|write| &write.collection == relation)
                    {
                        if write.op == TxWriteOp::Delete
                            || self.get_unchecked(relation, &write.record_id)?.is_some()
                        {
                            return Err(BicDbError::CommitValidation(format!(
                                "append-only relation `{relation}` rejected mutation of `{}`",
                                write.record_id
                            )));
                        }
                    }
                }
                NativeCommitValidator::ImmutableFields { relation, fields } => {
                    for write in tx
                        .writes
                        .iter()
                        .filter(|write| &write.collection == relation)
                    {
                        let (Some(before), Some(after)) = (
                            self.get_unchecked(relation, &write.record_id)?,
                            write.record()?.map(Arc::as_ref),
                        ) else {
                            continue;
                        };
                        for field in fields {
                            if before.metadata.get(field) != after.metadata.get(field) {
                                return Err(BicDbError::CommitValidation(format!(
                                    "immutable field `{field}` changed on `{relation}`/`{}`",
                                    write.record_id
                                )));
                            }
                        }
                    }
                }
                NativeCommitValidator::TenantWorkspaceImmutable {
                    relation,
                    tenant_field,
                    workspace_field,
                } => {
                    for write in tx
                        .writes
                        .iter()
                        .filter(|write| &write.collection == relation)
                    {
                        let (Some(before), Some(after)) = (
                            self.get_unchecked(relation, &write.record_id)?,
                            write.record()?.map(Arc::as_ref),
                        ) else {
                            continue;
                        };
                        for (boundary, field) in [
                            ("tenant", tenant_field.as_ref()),
                            ("workspace", workspace_field.as_ref()),
                        ] {
                            if field.is_some_and(|field| {
                                before.metadata.get(field) != after.metadata.get(field)
                            }) {
                                return Err(BicDbError::CommitValidation(format!(
                                    "{boundary} field is immutable on `{relation}`/`{}`",
                                    write.record_id
                                )));
                            }
                        }
                    }
                }
                NativeCommitValidator::OptimisticVersion { relation, field } => {
                    for write in tx
                        .writes
                        .iter()
                        .filter(|write| &write.collection == relation)
                    {
                        let (Some(before), Some(after)) = (
                            self.get_unchecked(relation, &write.record_id)?,
                            write.record()?.map(Arc::as_ref),
                        ) else {
                            continue;
                        };
                        let previous = before
                            .metadata
                            .get(field)
                            .and_then(Value::as_u64)
                            .ok_or_else(|| {
                                BicDbError::CommitValidation(format!(
                                    "`{relation}`/`{}` lacks version field `{field}`",
                                    write.record_id
                                ))
                            })?;
                        let next = after
                            .metadata
                            .get(field)
                            .and_then(Value::as_u64)
                            .ok_or_else(|| {
                                BicDbError::CommitValidation(format!(
                                    "`{relation}`/`{}` lacks version field `{field}`",
                                    write.record_id
                                ))
                            })?;
                        if next != previous.saturating_add(1) {
                            return Err(BicDbError::CommitValidation(format!(
                                "`{relation}`/`{}` version must advance from {previous} to {}",
                                write.record_id,
                                previous.saturating_add(1)
                            )));
                        }
                    }
                }
                NativeCommitValidator::LedgerBalanced {
                    relation,
                    subject_field,
                    debit_field,
                    credit_field,
                } => {
                    let records = resulting_records_for_relation(self, tx, relation)?;
                    let mut balances = BTreeMap::<String, (f64, f64)>::new();
                    for record in records {
                        let Some(subject) =
                            record.metadata.get(subject_field).and_then(Value::as_str)
                        else {
                            continue;
                        };
                        let debit = json_number(record.metadata.get(debit_field)).unwrap_or(0.0);
                        let credit = json_number(record.metadata.get(credit_field)).unwrap_or(0.0);
                        let entry = balances.entry(subject.to_string()).or_default();
                        entry.0 += debit;
                        entry.1 += credit;
                    }
                    for (subject, (debit, credit)) in balances {
                        if (debit - credit).abs() > 1e-9 {
                            return Err(BicDbError::CommitValidation(format!(
                                "ledger `{relation}` is unbalanced for `{subject}`: debit={debit} credit={credit}"
                            )));
                        }
                    }
                }
                NativeCommitValidator::AggregateInvariant {
                    relation,
                    subject_field,
                    value_field,
                    minimum,
                    maximum,
                } => {
                    if !minimum.is_finite() || !maximum.is_finite() || minimum > maximum {
                        return Err(BicDbError::CommitValidation(format!(
                            "aggregate validator for `{relation}` has invalid bounds"
                        )));
                    }
                    let records = resulting_records_for_relation(self, tx, relation)?;
                    let mut totals = BTreeMap::<String, f64>::new();
                    for record in records {
                        let Some(subject) =
                            record.metadata.get(subject_field).and_then(Value::as_str)
                        else {
                            continue;
                        };
                        *totals.entry(subject.to_string()).or_default() +=
                            json_number(record.metadata.get(value_field)).unwrap_or(0.0);
                    }
                    for (subject, total) in totals {
                        if total < *minimum || total > *maximum {
                            return Err(BicDbError::CommitValidation(format!(
                                "aggregate invariant failed for `{relation}` subject `{subject}`: {total} not in [{minimum}, {maximum}]"
                            )));
                        }
                    }
                }
                NativeCommitValidator::FinanceGuard {
                    relation,
                    amount_field,
                    maximum_absolute_amount,
                } => {
                    if !maximum_absolute_amount.is_finite() || *maximum_absolute_amount < 0.0 {
                        return Err(BicDbError::CommitValidation(format!(
                            "finance guard for `{relation}` has invalid maximum"
                        )));
                    }
                    for write in tx
                        .writes
                        .iter()
                        .filter(|write| &write.collection == relation)
                    {
                        let Some(record) = write.record()?.map(Arc::as_ref) else {
                            continue;
                        };
                        let amount =
                            json_number(record.metadata.get(amount_field)).ok_or_else(|| {
                                BicDbError::CommitValidation(format!(
                                    "`{relation}`/`{}` lacks numeric `{amount_field}`",
                                    write.record_id
                                ))
                            })?;
                        if !amount.is_finite() || amount.abs() > *maximum_absolute_amount {
                            return Err(BicDbError::CommitValidation(format!(
                                "finance guard rejected `{relation}`/`{}` amount {amount}",
                                write.record_id
                            )));
                        }
                    }
                }
                NativeCommitValidator::ApplicationInvariant { definition } => {
                    validate_carrier_invariant(self, tx, definition)?;
                }
            }
        }
        Ok(())
    }

    pub(crate) fn validate_serializable_reads(&self, tx: &Transaction) -> Result<()> {
        if tx.isolation != TransactionIsolation::Serializable {
            return Ok(());
        }
        for relation in &tx.serializable_reads {
            let expected = tx
                .serializable_generation_snapshot
                .get(relation)
                .copied()
                .unwrap_or_default();
            let actual = self.collection_generation(relation);
            if actual != expected {
                return Err(BicDbError::TransactionConflict(format!(
                    "serializable relation `{relation}` changed after transaction {} snapshot",
                    tx.id.0
                )));
            }
        }
        Ok(())
    }

    /// The commit body. `flashback_scn` is `Some` only when the caller
    /// (`commit_transaction` in db/flashback.rs) holds the flashback clock and
    /// this transaction writes a flashback-tracked collection.
    pub(super) fn commit_transaction_inner(
        &self,
        tx: &mut Transaction,
        flashback_scn: Option<u64>,
    ) -> Result<u64> {
        if tx.state != TxState::Pending {
            return Err(BicDbError::TransactionNotPending);
        }
        self.ensure_writable_by_consensus(tx)?;
        let _serializable_shared = (tx.isolation != TransactionIsolation::Serializable)
            .then(|| self.serializable_commit_admission.read());
        let _serializable_exclusive = (tx.isolation == TransactionIsolation::Serializable)
            .then(|| self.serializable_commit_admission.write());
        self.check_recovery_state()?;
        self.validate_transaction_collection_incarnations(tx)?;
        // CONCURRENT COMMIT (no global commit_lock). Correctness rests on four
        // independent mechanisms, each guarding exactly what it must:
        //  * same-record W-W: optimistic per-record `write_locks` (a 2nd writer of
        //    a record errors at write time), so two committers never apply the same
        //    record concurrently -> per-shard conflict-check + apply is atomic per
        //    record. The version-chain watermark is bumped during apply, before the write lock
        //    is released below, so a later writer's conflict check sees it.
        //  * unique-index validate+apply atomicity: done under the touched indexes'
        //    write locks, held across the validate-all-then-apply-all section
        //    (`validate_and_apply_index_mutations`), acquired in canonical name
        //    order so concurrent committers cannot deadlock.
        //  * WAL ordering: `tx_log.enqueue` is keyed by commit_seq into a BTreeMap
        //    and `drain_contiguous` only emits a gap-free prefix, so seqs may be
        //    assigned/enqueued out of order; a plain atomic fetch_add suffices.
        //  * MVCC visibility: `mark_committed_seq` advances the watermark only
        //    across the contiguous applied prefix, so a snapshot never observes a
        //    seq before every lower seq is fully applied (records included).
        let mut timer = commit_trace::Timer::start();
        // Repair-carrying writes lock and (if the row moved past the snapshot)
        // rebuild their records FIRST, so every later stage — index mutations,
        // conflict detection, WAL encode, apply — sees the final record.
        self.repair_conflicting_delta_writes(tx)?;
        // Flashback history rows join this transaction after repair (so they
        // carry the final row images) and before every later stage, so they
        // are validated, logged, applied and recovered exactly like the data.
        if let Some(scn) = flashback_scn {
            self.flashback_inject_history(tx, scn)?;
        }
        let writes_by_collection = tx_writes_by_collection(&tx.writes);
        let structural_schema_records_changed = writes_by_collection
            .keys()
            .any(|collection| CLUSTER_SCHEMA_CATALOG_COLLECTIONS.contains(collection));
        let mut index_mutations_by_collection =
            self.tx_index_mutations_by_collection(&writes_by_collection, tx.writes_are_unique())?;
        timer.lap(&commit_trace::INDEX_BUILD);
        // Plan vector dimensions per collection (abort point: dimension mismatch).
        // Tells the apply path whether a collection needs the rare exclusive
        // (dimension-changing) path or the common concurrent read-guard path.
        let dim_plan = self.plan_vector_dims(&writes_by_collection)?;
        // A/B gate: when `BICDB_GLOBAL_COMMIT_LOCK` is set, serialize the entire
        // commit critical section under one global mutex, reproducing the old
        // pre-removal `commit_lock` baseline (conflict check + index validate/apply
        // + seq assignment + record apply + watermark publish all run as one). The
        // guard wraps the existing per-shard/per-index locks (it only serializes,
        // never reorders acquisition) and drops at function scope. When the gate is
        // off (default) the lock is never taken and this is a single relaxed load,
        // leaving the concurrent path byte-identical to before. Held from here so a
        // committer's full apply completes before the next committer begins.
        let has_carrier_invariants = tx.commit_validators.iter().any(|validator| {
            matches!(
                validator,
                NativeCommitValidator::ApplicationInvariant { .. }
            )
        });
        let _commit_guard = if global_commit_lock_enabled() || has_carrier_invariants {
            Some(self.commit_lock.lock())
        } else {
            None
        };
        self.detect_commit_conflicts(tx)?;
        self.validate_serializable_reads(tx)?;
        // Cross-record BicDB application invariants must observe a stable committed set
        // through record apply. Transactions carrying them therefore share the
        // global commit boundary above; ordinary transactions retain the
        // disjoint-write concurrent path.
        self.validate_native_commit_validators(tx)?;
        timer.lap(&commit_trace::CONFLICT);
        // Resolve each mutation's record locator for validation. Existing records
        // (updates/deletes) resolve now; brand-new records are still unallocated
        // (`None`) and validated in pk-space.
        self.fill_all_index_mutation_rowids(&mut index_mutations_by_collection)?;
        // Index uniqueness VALIDATION (abort point: unique violation), under the
        // touched indexes' READ locks. The mutating apply is deferred until after
        // record apply (below), once every record's locator is allocated. This is
        // the ONLY commit-vs-commit serialization point, and only for commits whose
        // index sets overlap; record apply runs fully concurrently.
        let _unique_claims = self.claim_unique_keys(tx, &index_mutations_by_collection)?;
        let _exclusion_claims = self.claim_exclusion_ranges(tx, &index_mutations_by_collection)?;
        self.validate_index_mutations(&index_mutations_by_collection)?;
        let admission = if tx.bypass_commit_admission || tx.writes.is_empty() {
            None
        } else {
            let admission = self.commit_admission.read().clone();
            if admission.is_none() && self.config.require_commit_admission {
                return Err(BicDbError::Cluster(
                    "distributed write rejected: range-quorum commit authority is not ready"
                        .to_string(),
                ));
            }
            admission
        };
        let admission_ticket = if let Some(admission) = admission.as_ref() {
            let mutations = tx
                .writes
                .iter()
                .map(|write| {
                    let record = match write.op {
                        TxWriteOp::Upsert => Some(
                            write
                                .record()?
                                .map(|record| (**record).clone())
                                .ok_or_else(|| {
                                    BicDbError::Cluster(format!(
                                        "distributed upsert {}/{} has no record payload",
                                        write.collection, write.record_id
                                    ))
                                })?,
                        ),
                        TxWriteOp::Delete => None,
                    };
                    Ok(CommitAdmissionMutation {
                        collection: write.collection.clone(),
                        record_id: write.record_id.clone(),
                        record,
                    })
                })
                .collect::<Result<Vec<_>>>()?;
            let intent = CommitAdmissionIntent {
                transaction_id: tx.id.0,
                mutations,
            };
            Some(
                if self
                    .range_image_native_birth_active
                    .load(AtomicOrdering::Acquire)
                {
                    let ticket = admission.admit_with_native_context(&intent, self)?;
                    tx.commit_admission_ticket = Some((Arc::clone(admission), ticket.clone()));
                    tx.native_admission_recovery_release = Some(NativeAdmissionRecoveryRelease {
                        admission: Arc::clone(admission),
                        ticket: Some(ticket.clone()),
                    });
                    ticket
                } else {
                    admission.admit(&intent)?
                },
            )
        } else {
            None
        };
        self.require_native_transaction_mutation_scope(tx)?;
        #[cfg(test)]
        if tx.native_admission_recovery_release.is_some() && self.test_native_admission_rejected() {
            return Err(BicDbError::Cluster(
                "injected native post-admission/pre-WAL rejection".into(),
            ));
        }
        let sync_ops = if tx.imported_projection {
            Vec::new()
        } else {
            self.sync_ops_for_commit(&index_mutations_by_collection)?
        };
        // Change-capture ops are not appended to `sync.log` here, before the
        // decision: a commit that then aborts (a failed decision write, a
        // withdrawn commit, a crash) would leave ops a consumer reads as
        // committed. They travel in the commit's own transaction-log batch and
        // reach `sync.log` only once the commit is durable and visible (below).
        let mut record_audit_events = if tx.imported_projection {
            Vec::new()
        } else {
            self.record_audit_events_for_commit(&index_mutations_by_collection)?
        };
        record_audit_events.extend(tx.imported_record_audit_events.iter().cloned());
        test_commit_pause_after_validate();
        timer.lap(&commit_trace::VALIDATE);
        // This abortable test hook runs before the durable decision. Real
        // storage failures after that decision have an uncertain outcome and
        // must be recovered, never rewritten as an aborted partial apply.
        if std::env::var_os("BICDB_TEST_REJECT_COMMIT_BEFORE_DECISION").is_some() {
            return Err(BicDbError::PagedStorage(
                "injected pre-decision rejection".into(),
            ));
        }
        if tx.database_mutation_permit.is_some() && !tx.writes.is_empty() {
            self.invalidate_native_range_images_before_mutation(
                None,
                "unscoped native/standalone commit",
            )?;
        }
        bicdb_page::test_faults::crash_point("commit.before_decision");
        // Past validation: reserve and durably log the transaction decision.
        // A plain atomic add is monotonic; the seq-keyed writer queue tolerates
        // out-of-order enqueue; the writer coalesces the contiguous prefix.
        let commit_seq = self.commit_seq.fetch_add(1, AtomicOrdering::SeqCst) + 1;
        test_commit_pause_after_seq_reserved();
        if repair_trace_filter().is_some() {
            for write in &tx.writes {
                if let Some(record) = write.record()?.map(Arc::as_ref) {
                    repair_trace(
                        &write.collection,
                        &write.record_id,
                        tx.id.0,
                        write.statement_snapshot,
                        commit_seq,
                        || {
                            format!(
                                "seq_assigned repair={} meta={}",
                                write.repair.is_some(),
                                record.metadata
                            )
                        },
                    );
                }
            }
        }
        let prepared = std::mem::take(&mut tx.prepared_wal);
        // Keep complete logical redo in every storage mode. A page-WAL sync
        // can fail after its commit bytes were written, and materialization can
        // fail after some work. Marker-only logging cannot repair that outcome.
        let pending_publishes = tx.pending_broker_publishes.lock().clone();
        // The sequence above is already public, but this encoding is fallible.
        // If it fails we must still occupy the queue slot: `drain_contiguous`
        // only advances across an unbroken prefix, so an abandoned sequence
        // would strand every later commit's durability behind a gap that never
        // fills. Nothing was applied and no client is acknowledged, so an empty
        // slot is exactly right — it carries no frames into recovery.
        let encoded = self.encode_tx_commit_frames(
            tx.id,
            commit_seq,
            &tx.writes,
            &pending_publishes,
            &record_audit_events,
            &sync_ops,
            prepared,
        );
        let wal_bytes = match encoded {
            Ok(bytes) => bytes,
            Err(error) => {
                self.tx_log.enqueue(commit_seq, Vec::new());
                // This reserved sequence represents no applied mutation, but
                // it is nevertheless complete. Leaving it absent from the
                // applied watermark permanently hides every later successful
                // commit behind an impossible gap.
                self.mark_committed_seq(commit_seq);
                return Err(error);
            }
        };
        self.tx_log.enqueue(commit_seq, wal_bytes);
        tx.receipt_commit_started(commit_seq);
        // A durable logical decision precedes every physical/resident apply.
        // A failed sync may still have persisted it, so errors fence the handle
        // and leave the complete redo intact for restart and replication.
        match self.tx_log.write_durable(commit_seq) {
            Ok(()) => {}
            // A backup-gate timeout (a backup or branch holding the gate)
            // happens before any byte is written. It must not fence a
            // healthy primary. Withdraw the commit so no later batch can
            // write it: it then definitively did not commit, which is an
            // ordinary, retryable error. If a concurrent batch already made
            // it durable, it committed and the commit proceeds.
            Err(error @ BicDbError::Backup(_)) => {
                if self.tx_log.abandon_unwritten(commit_seq) {
                    // The empty slot keeps the applied watermark gap-free.
                    self.mark_committed_seq(commit_seq);
                    tx.receipt_commit_withdrawn();
                    return Err(error);
                }
            }
            Err(error) => {
                // The log fenced itself on an I/O failure; the enqueue-gap
                // bound fences here. Some or all of the batch may be on
                // disk: the outcome is unknown.
                self.fence_durability("transaction_log.write", &error);
                tx.receipt_recovery_required(commit_seq);
                return Err(self.commit_outcome_unknown(tx.id.0, commit_seq, &error));
            }
        }
        bicdb_page::test_faults::crash_point("commit.after_txlog_durable");
        timer.lap(&commit_trace::WAL_ENCODE);
        let deferred = self
            .deferred_materializer
            .as_ref()
            .map(|handle| &handle.materializer);
        let mut deferred_page_commit = None;
        // Record/version/vector apply: per-shard write locks under the shared
        // collection read guard, so disjoint-key commits (even within one
        // collection) apply in parallel. This allocates each brand-new record's
        // rowid (the index payload resolved next).
        let apply_result = (|| -> Result<()> {
            if std::env::var_os("BICDB_TEST_FAIL_COMMIT_APPLY").is_some() {
                return Err(BicDbError::PagedStorage(
                    "injected post-decision materialization failure".into(),
                ));
            }
            self.apply_committed_record_writes(
                commit_seq,
                &writes_by_collection,
                &index_mutations_by_collection,
                &dim_plan,
                &mut timer,
                deferred.map(|_| &mut deferred_page_commit),
            )?;
            bicdb_page::test_faults::crash_point("commit.after_page_apply");
            // Now every record is resident: re-resolve locators (brand-new records now
            // resolve to `Some`) and apply the index entries (Pass 2). Returns spatial
            // audit events to append after the index locks drop.
            self.fill_all_index_mutation_rowids(&mut index_mutations_by_collection)?;
            let spatial_events = self.apply_index_mutations(&index_mutations_by_collection)?;
            if !spatial_events.is_empty() {
                let mut events = self.events.lock();
                for event in spatial_events {
                    events.append(event)?;
                }
            }
            // The record-audit outbox is part of the transaction WAL above.  Keep
            // it on the transaction until the caller has made that WAL durable;
            // `finalize_commit_admission` then publishes it idempotently.
            tx.pending_record_audit_events = record_audit_events;
            self.refresh_graph_projections()?;
            if structural_schema_records_changed {
                self.schema_compatibility.invalidate();
            }
            if self.paged_records.is_some() && !tx.writes.is_empty() {
                // This acknowledgement is written only AFTER the entire page
                // transaction and dependent catalog/index work succeeded. Full
                // redo remains retained for replication, while normal startup
                // can keep native collections lazy instead of replaying them.
                let payload = serde_json::to_vec(&TxFrame::CommitMaterialized {
                    tx_id: tx.id,
                    timestamp: unix_timestamp(),
                    commit_seq,
                })?;
                let framed = storage::encode_frames_to_bytes(
                    &self.tx_log_path(),
                    FrameKind::Transaction,
                    &[payload],
                    &CompressionConfig::disabled(),
                    &self.encryption,
                )?;
                match (deferred, deferred_page_commit) {
                    (Some(materializer), Some(lsn)) => {
                        materializer.enqueue(commit_seq, lsn, framed);
                    }
                    (Some(materializer), None) => {
                        // No deferred page commit was recorded: cover the
                        // whole log tail, a superset of this commit.
                        let tail = self
                            .paged_records
                            .as_ref()
                            .map_or(0, |paged| paged.store().wal().next_lsn().saturating_sub(1));
                        materializer.enqueue(commit_seq, tail, framed);
                    }
                    (None, _) => self.tx_log.append_auxiliary(&framed)?,
                }
                bicdb_page::test_faults::crash_point("commit.after_marker");
            }
            timer.lap(&commit_trace::GRAPH);
            Ok(())
        })();
        if let Err(error) = apply_result {
            // The decision is durable, so recovery will apply it; this
            // handle cannot, and must not report it as committed.
            self.fence_durability("commit.materialize", &error);
            tx.receipt_recovery_required(commit_seq);
            return Err(self.commit_outcome_unknown(tx.id.0, commit_seq, &error));
        }
        // Done: drop the tx_states entry rather than leaving a `Committed`
        // tombstone. Nothing reads a completed tx's state by tx_id (visibility is
        // commit_seq-based via the version chain; conflict detection never consults
        // tx_states; the only reader, `ensure_no_pending_transactions`, treats an
        // absent entry as "not pending"). Keeping committed entries leaked one map
        // entry per transaction forever (1M+ under a sustained workload). tx_states now holds only
        // in-flight transactions, bounded by concurrency.
        self.tx_states.remove(&tx.id.0);
        // Publish visibility only after this seq's records are fully applied; the
        // watermark advances across the contiguous applied prefix (see above).
        self.mark_committed_seq(commit_seq);
        // Row-lock waiters wake to re-read the row, so release them only once
        // this commit is visible to their refreshed snapshots.
        self.wait_until_visible(commit_seq);
        let locked_keys = tx.locked_keys.get_mut().take_all();
        release_owned_write_locks(&self.write_locks, tx.id, &locked_keys);
        // Fail-closed: once the database is fenced no commit is reported
        // committed, even one whose decision reached the disk before the
        // failure (recovery keeps that one). The receipt says recovery
        // required; the caller must not assume either outcome.
        if self.durability.is_failed() {
            tx.receipt_recovery_required(commit_seq);
            let fenced = self.check_recovery_state().unwrap_err();
            return Err(self.commit_outcome_unknown(tx.id.0, commit_seq, &fenced));
        }
        // The commit is durable and visible: publish its change-capture ops.
        // A failure here leaves them only in the transaction log. The commit
        // stays committed (a refusal would make the client retry and
        // duplicate it); the database is fenced, so no checkpoint or
        // compaction moves past the log's copy, and the reopen republishes it.
        if !sync_ops.is_empty() {
            if let Err(error) = self.sync_log.lock().append_ops(&sync_ops) {
                self.fence_durability("sync_log.publish", &error);
                bicdb_page::health::log_event(&serde_json::json!({
                    "event": "durability.sync_publication_deferred",
                    "severity": "warn",
                    "transaction_id": tx.id.0,
                    "commit_seq": commit_seq,
                    "error": error.to_string(),
                    "action": "the commit is durable; recovery republishes its change-capture ops",
                }));
            }
            bicdb_page::test_faults::crash_point("commit.after_sync_publish");
        }
        tx.state = TxState::Committed;
        tx.committed_seq = Some(commit_seq);
        // The decision is already durable. Complete the outboxes while this
        // commit still holds admission: a checkpoint must not cut their redo
        // between the durable decision and publication. The caller's legacy
        // finalizer calls remain safe, idempotent no-ops afterwards.
        #[cfg(test)]
        let publish_outboxes = !tx.skip_commit_outboxes_for_crash_test;
        #[cfg(not(test))]
        let publish_outboxes = true;
        if publish_outboxes {
            tx.finalize_committed_record_audit_events()?;
            tx.finalize_committed_broker_outbox();
        }
        tx.receipt_commit_finished(commit_seq);
        timer.lap(&commit_trace::BOOKKEEPING);
        commit_trace::tick();
        // So this thread's next `begin_transaction` does not start behind its own
        // commit and self-conflict on a row nobody else touched.
        self.note_commit_seq_on_this_thread(commit_seq);
        if let (Some(admission), Some(ticket)) = (admission, admission_ticket) {
            tx.commit_admission_ticket = Some((admission, ticket));
        }
        Ok(commit_seq)
    }
}

fn page_archive_error(failure: crate::WriteFailure) -> BicDbError {
    BicDbError::ArchiveFailed {
        archive: "page_log".into(),
        site: failure.site,
        detail: failure.error,
    }
}

/// Fsync the directory that holds `path` (making a new entry durable).
fn sync_parent_dir(site: &str, path: &Path) -> std::io::Result<()> {
    let Some(parent) = path.parent().filter(|p| !p.as_os_str().is_empty()) else {
        return Ok(());
    };
    bicdb_page::test_faults::io_fault(site, parent)?;
    File::open(parent)?.sync_all()
}

/// Byte-for-byte comparison of two files.
fn files_equal(left: &Path, right: &Path) -> std::io::Result<bool> {
    use std::io::Read;
    let mut left = std::io::BufReader::new(File::open(left)?);
    let mut right = std::io::BufReader::new(File::open(right)?);
    let mut a = vec![0u8; 64 * 1024];
    let mut b = vec![0u8; 64 * 1024];
    loop {
        let read = left.read(&mut a)?;
        if read == 0 {
            return Ok(right.read(&mut b[..1])? == 0);
        }
        right.read_exact(&mut b[..read]).map_err(|error| {
            if error.kind() == std::io::ErrorKind::UnexpectedEof {
                std::io::Error::other("archive copy is shorter than the local segment")
            } else {
                error
            }
        })?;
        if a[..read] != b[..read] {
            return Ok(false);
        }
    }
}

/// Persisted result of the last page-log archive verification.
pub(crate) fn page_log_verification_path(wal: &Path) -> PathBuf {
    let mut os = wal.as_os_str().to_os_string();
    os.push("-archive-verification");
    PathBuf::from(os)
}
