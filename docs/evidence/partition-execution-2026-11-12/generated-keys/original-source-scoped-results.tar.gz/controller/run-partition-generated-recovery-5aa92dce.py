import json,pathlib,subprocess,time,sys
root=pathlib.Path('/root/bicdb-durability-s3');out=root/'report-partition-generated-recovery-5aa92dce.json'
record={'source':'5aa92dcecb29b639251acc81a5d60428dfae96f7','status':'waiting_for_probe_build','started_unix':time.time(),'scope':'Original30genuineold482controls then independentcanonicalverifier,152processcuts and96actualEIO cases oncopies only. ExactlatestgeneratedSQL source. These are not VM/HA/fullapplication qualification.','steps':[]}
def save():out.write_text(json.dumps(record,indent=2)+'\n')
assert not out.exists();save()
while subprocess.check_output(['systemctl','show','bicdb-partition-generated-current-probes','-p','ActiveState','--value'],text=True).strip() in ['active','activating','reloading']:time.sleep(3)
build=json.loads((root/'report-partition-generated-current-probes.json').read_text());assert build['source']==record['source'] and build['status']=='focused_passed',build
record['status']='running';save()
for script in ['run-partition-legacy-qualification-5aa92dce.py','verify-partition-legacy-qualification-5aa92dce.py','run-partition-crash-matrix-5aa92dce.py','run-partition-io-failure-matrix-5aa92dce.py']:
 step={'script':script,'started_unix':time.time()};record['steps'].append(step);save();step.update(exit=subprocess.call(['python3',str(root/'host-control'/script)]),finished_unix=time.time());save()
 if step['exit']!=0:break
record.update(status='recovery_commands_passed' if len(record['steps'])==4 and all(s['exit']==0 for s in record['steps']) else 'recovery_commands_failed',finished_unix=time.time());save();print(json.dumps(record));sys.exit(0 if record['status']=='recovery_commands_passed' else 1)
