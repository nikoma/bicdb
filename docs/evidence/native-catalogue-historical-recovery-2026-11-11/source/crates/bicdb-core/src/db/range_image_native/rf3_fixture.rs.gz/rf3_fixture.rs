//! Actual local RF3 origin/certificate fixture. Every data acknowledgement is
//! returned by a real fsynced ClusterDataNodeService; no canned ACK or supplied
//! certificate-voter set is used. Initial RF3 membership is a declared validated
//! test precondition, not evidence of live node joining or authenticated TCP.
use super::*;
use crate::distribution::{ClusterNode, ClusterTopology, RangeReplica, ReplicaId};
use crate::distribution_data::ClusterDataNodeService;
use crate::distribution_range_consensus::{
    RangeWriteAck, RangeWriteCommand, RangeWriteCoordinator, RangeWriteProbe, RangeWriteProgress,
    RangeWriteRepairBatch, RangeWriteRepairLimits, RangeWriteState, RangeWriteTransport,
};
use crate::{DistributionConfig, DistributionStore};

#[derive(Clone, Debug)]
pub(crate) struct ActualNativeRf3RpcObservation {
    pub(crate) operation: &'static str,
    pub(crate) destination: ClusterNodeId,
    pub(crate) command_sha256: Option<String>,
    pub(crate) state: Option<RangeWriteState>,
    pub(crate) error: Option<String>,
}

/// In-process service transport. Caller identity is the same explicit trusted
/// caller argument used by embedded APIs. It is NOT a transport-authentication
/// proof; real mTLS/metadata-role admission remains a separate integration gate.
#[derive(Debug)]
pub(crate) struct ActualNativeRf3ServiceTransport {
    caller: ClusterNodeId,
    topology: Arc<RwLock<ClusterTopology>>,
    services: BTreeMap<ClusterNodeId, Arc<Mutex<ClusterDataNodeService>>>,
    observations: Mutex<Vec<ActualNativeRf3RpcObservation>>,
}
impl ActualNativeRf3ServiceTransport {
    fn range(&self, id: RangeId, epoch: u64) -> Result<RangeDescriptor> {
        self.topology
            .read()
            .range_by_id(id)
            .filter(|r| r.epoch == epoch)
            .cloned()
            .ok_or_else(|| invalid("actual RF3 fixture range/epoch differs"))
    }
    fn service(&self, id: &ClusterNodeId) -> Result<&Arc<Mutex<ClusterDataNodeService>>> {
        self.services
            .get(id)
            .ok_or_else(|| invalid("actual RF3 destination absent"))
    }
    fn record_ack(
        &self,
        operation: &'static str,
        destination: &ClusterNodeId,
        command: &RangeWriteCommand,
        result: Result<RangeWriteAck>,
    ) -> Result<RangeWriteAck> {
        self.observations
            .lock()
            .push(ActualNativeRf3RpcObservation {
                operation,
                destination: destination.clone(),
                command_sha256: Some(command.checksum_sha256.clone()),
                state: result.as_ref().ok().map(|ack| ack.state),
                error: result.as_ref().err().map(ToString::to_string),
            });
        result
    }
    pub(crate) fn observations(&self) -> Vec<ActualNativeRf3RpcObservation> {
        self.observations.lock().clone()
    }
}
impl RangeWriteTransport for ActualNativeRf3ServiceTransport {
    fn range_write_progress(
        &self,
        node: &ClusterNodeId,
        id: RangeId,
        epoch: u64,
    ) -> Result<RangeWriteProgress> {
        let range = self.range(id, epoch)?;
        self.service(node)?
            .lock()
            .range_write_progress_for_peer(&range, &self.caller)
    }
    fn apply_range_write_repair(
        &self,
        node: &ClusterNodeId,
        batch: &RangeWriteRepairBatch,
        limits: &RangeWriteRepairLimits,
    ) -> Result<RangeWriteProgress> {
        let range = self.range(batch.range_id, batch.range_epoch)?;
        self.service(node)?
            .lock()
            .apply_range_write_repair(&range, &self.caller, batch, limits)
    }
    fn fetch_range_write_repair(
        &self,
        node: &ClusterNodeId,
        id: RangeId,
        epoch: u64,
        after: u64,
        limits: &RangeWriteRepairLimits,
    ) -> Result<RangeWriteRepairBatch> {
        let range = self.range(id, epoch)?;
        self.service(node)?
            .lock()
            .export_range_write_repair(&range, &self.caller, after, limits)
    }
    fn probe_range_write(
        &self,
        node: &ClusterNodeId,
        id: RangeId,
        epoch: u64,
        index: u64,
    ) -> Result<RangeWriteProbe> {
        let range = self.range(id, epoch)?;
        self.service(node)?
            .lock()
            .probe_range_write_for_peer(&range, &self.caller, index)
    }
    fn prepare_range_write(
        &self,
        node: &ClusterNodeId,
        command: &RangeWriteCommand,
    ) -> Result<RangeWriteAck> {
        let range = self.range(command.range_id, command.range_epoch)?;
        let result =
            self.service(node)?
                .lock()
                .prepare_range_write(&range, &self.caller, command.clone());
        self.record_ack("prepare", node, command, result)
    }
    fn commit_range_write(
        &self,
        node: &ClusterNodeId,
        command: &RangeWriteCommand,
    ) -> Result<RangeWriteAck> {
        let range = self.range(command.range_id, command.range_epoch)?;
        let result = self
            .service(node)?
            .lock()
            .commit_range_write(&range, &self.caller, command);
        self.record_ack("commit", node, command, result)
    }
    fn certify_range_write(
        &self,
        node: &ClusterNodeId,
        command: &RangeWriteCommand,
    ) -> Result<RangeWriteAck> {
        let range = self.range(command.range_id, command.range_epoch)?;
        let result = self
            .service(node)?
            .lock()
            .certify_range_write(&range, &self.caller, command);
        self.record_ack("certify", node, command, result)
    }
    fn apply_range_write(
        &self,
        node: &ClusterNodeId,
        command: &RangeWriteCommand,
    ) -> Result<RangeWriteAck> {
        let range = self.range(command.range_id, command.range_epoch)?;
        let result =
            self.service(node)?
                .lock()
                .apply_certified_range_write(&range, &self.caller, command);
        self.record_ack("apply", node, command, result)
    }
    fn abort_range_write(
        &self,
        node: &ClusterNodeId,
        command: &RangeWriteCommand,
    ) -> Result<RangeWriteAck> {
        let range = self.range(command.range_id, command.range_epoch)?;
        let result = self
            .service(node)?
            .lock()
            .abort_range_write(&range, &self.caller, command);
        self.record_ack("abort", node, command, result)
    }
}

pub(crate) struct ActualNativeRf3Fixture {
    pub(crate) root: tempfile::TempDir,
    pub(crate) topology: Arc<RwLock<ClusterTopology>>,
    pub(crate) databases: BTreeMap<ClusterNodeId, Arc<RwLock<BicDb>>>,
    pub(crate) services: BTreeMap<ClusterNodeId, Arc<Mutex<ClusterDataNodeService>>>,
    pub(crate) specs: BTreeMap<ClusterNodeId, RangeImageBirthSpec>,
    pub(crate) transport: Arc<ActualNativeRf3ServiceTransport>,
    pub(crate) coordinator: Arc<RangeWriteCoordinator<ActualNativeRf3ServiceTransport>>,
}
impl ActualNativeRf3Fixture {
    pub(crate) fn new() -> Self {
        let root = tempfile::tempdir().unwrap();
        let cluster = ClusterId::new("actual-native-rf3-origin").unwrap();
        let leader = ClusterNodeId::new("n0").unwrap();
        let bootstrap = Uuid::now_v7();
        let mut metadata = DistributionStore::initialize_at(
            root.path().join("metadata"),
            DistributionConfig {
                enabled: true,
                cluster_id: cluster.clone(),
                node_id: leader.clone(),
                node_address: "127.0.0.1:19000".into(),
                initial_ranges: 1,
                replication_factor: 3,
                range_image_bootstrap_id: Some(bootstrap),
                ..Default::default()
            },
            true,
            1,
        )
        .unwrap();
        for (id, port) in [("n1", 19001), ("n2", 19002)] {
            metadata
                .join_node(
                    ClusterNode::new(
                        ClusterNodeId::new(id).unwrap(),
                        format!("127.0.0.1:{port}"),
                        1,
                        1_000_000,
                        1,
                    )
                    .unwrap(),
                    &leader,
                    1,
                )
                .unwrap();
        }
        let mut topology = metadata.topology().clone();
        // Explicit INITIAL topology fixture, before any birth/data/genesis.
        // Do not represent this as executing an online learner-promotion plan.
        for id in ["n1", "n2"] {
            let replica_id = ReplicaId::new(topology.next_replica_id).unwrap();
            topology.next_replica_id += 1;
            topology
                .ranges
                .values_mut()
                .next()
                .unwrap()
                .replicas
                .push(RangeReplica {
                    id: replica_id,
                    node_id: ClusterNodeId::new(id).unwrap(),
                    role: RangeReplicaRole::Voter,
                });
        }
        topology.validate().unwrap();
        let range = topology.ranges.values().next().unwrap().clone();
        let members = topology
            .nodes
            .iter()
            .map(|(id, node)| {
                (
                    id.clone(),
                    RangeImageBirthMember {
                        incarnation: node.incarnation,
                        tls_certificate_sha256: node.tls_certificate_sha256.clone(),
                        pending_tls_certificate_sha256: node.pending_tls_certificate_sha256.clone(),
                    },
                )
            })
            .collect::<BTreeMap<_, _>>();
        let config = DbConfig::default()
            .with_fsync(true)
            .with_storage_mode(StorageMode::ServerPaged)
            .with_paged_buffer_pool_bytes(8 * 1024 * 1024);
        let mut databases = BTreeMap::new();
        let mut specs = BTreeMap::new();
        let mut schema = None;
        for node in topology.nodes.values() {
            let spec = RangeImageBirthSpec {
                cluster_id: cluster.clone(),
                bootstrap_id: bootstrap,
                node_id: node.id.clone(),
                member_incarnation: node.incarnation,
                initial_members: members.clone(),
                restore_activation: None,
                initial_ranges: vec![range.clone()],
            };
            let path = root.path().join(node.id.as_str());
            let (mut db, _) =
                BicDb::create_new_range_image_database(&path, config.clone(), spec.clone())
                    .unwrap();
            db.create_collection("items").unwrap();
            drop(db);
            let (db, genesis) =
                BicDb::open_range_image_database(&path, config.clone(), &spec).unwrap();
            let fingerprint = db.schema_compatibility_fingerprint().unwrap().sha256;
            if let Some(expected) = &schema {
                assert_eq!(expected, &fingerprint)
            } else {
                schema = Some(fingerprint)
            }
            let db = Arc::new(RwLock::new(db));
            let gate = db.read().range_mutation_gate();
            let frozen = gate.try_freeze(range.id, Uuid::now_v7()).unwrap();
            BicDb::initialize_range_image_genesis(
                &db,
                &genesis,
                &range,
                &frozen,
                Duration::from_secs(3),
                &CancellationToken::uncancelable(),
            )
            .unwrap();
            drop(frozen);
            databases.insert(node.id.clone(), db);
            specs.insert(node.id.clone(), spec);
        }
        for node in topology.nodes.values_mut() {
            node.labels.insert(
                crate::distribution::SCHEMA_COMPATIBILITY_NODE_LABEL.into(),
                schema.clone().unwrap(),
            );
        }
        let topology = Arc::new(RwLock::new(topology));
        let services = databases
            .iter()
            .map(|(id, db)| {
                let service = ClusterDataNodeService::open(
                    cluster.clone(),
                    id.clone(),
                    db.read().data_path(),
                    Arc::clone(db),
                    true,
                )
                .unwrap();
                (id.clone(), Arc::new(Mutex::new(service)))
            })
            .collect::<BTreeMap<_, _>>();
        let transport = Arc::new(ActualNativeRf3ServiceTransport {
            caller: leader.clone(),
            topology: Arc::clone(&topology),
            services: services.clone(),
            observations: Mutex::new(Vec::new()),
        });
        let coordinator = Arc::new(
            RangeWriteCoordinator::new_schema_fenced(
                cluster,
                leader.clone(),
                Arc::clone(&topology),
                Arc::clone(&services[&leader]),
                Arc::clone(&transport),
            )
            .unwrap(),
        );
        coordinator.recover_local_leadership(8).unwrap();
        databases[&leader]
            .read()
            .install_commit_admission(coordinator.clone());
        Self {
            root,
            topology,
            databases,
            services,
            specs,
            transport,
            coordinator,
        }
    }
    pub(crate) fn leader(&self) -> ClusterNodeId {
        self.topology
            .read()
            .ranges
            .values()
            .next()
            .unwrap()
            .leader
            .clone()
    }
    pub(crate) fn append(&self, key: &str) -> Result<()> {
        let leader = self.leader();
        let db = self.databases[&leader].write();
        let mut tx = db.begin_transaction()?;
        tx.insert("items", Record::new(key))?;
        tx.commit()
    }
}
impl Drop for ActualNativeRf3Fixture {
    fn drop(&mut self) {
        for db in self.databases.values() {
            db.read().clear_commit_admission();
        }
    }
}

#[test]
fn native_rf3_actual_services_ack_origin_while_bare_replica_apply_remains_refused() {
    let fixture = ActualNativeRf3Fixture::new();
    fixture.append("actual-rf3-origin").unwrap();
    let topology = fixture.topology.read();
    let range = topology.ranges.values().next().unwrap();
    let leader = &range.leader;
    let source = fixture.databases[leader].read();
    let lineage = source
        .current_native_range_source_lineage(range.id)
        .unwrap();
    assert_eq!(lineage.range_index(), 1);
    assert!(source.get("items", "actual-rf3-origin").unwrap().is_some());
    let observations = fixture.transport.observations();
    for node in topology.nodes.keys().filter(|node| *node != leader) {
        let rows = observations
            .iter()
            .filter(|row| &row.destination == node)
            .collect::<Vec<_>>();
        for (operation, state) in [
            ("prepare", RangeWriteState::Prepared),
            ("commit", RangeWriteState::Committed),
            ("certify", RangeWriteState::QuorumCommitted),
        ] {
            assert!(rows.iter().any(|row| row.operation == operation
                && row.state == Some(state)
                && row.error.is_none()));
        }
        assert!(rows.iter().any(|row| row.operation == "apply"
            && row.state.is_none()
            && row
                .error
                .as_deref()
                .is_some_and(|error| error.contains("authenticated current-leader instruction"))));
        let service = fixture.services[node].lock();
        let probe = service
            .probe_range_write_for_peer(range, leader, 1)
            .unwrap();
        let entry = probe.entry.unwrap();
        assert_eq!(entry.state, RangeWriteState::QuorumCommitted);
        assert_eq!(probe.progress.last_index, 1);
        assert_eq!(probe.progress.resolved_through, 0);
        let db = fixture.databases[node].read();
        assert_eq!(
            db.current_native_range_source_lineage(range.id)
                .unwrap()
                .range_index(),
            0
        );
        assert!(db.get("items", "actual-rf3-origin").unwrap().is_none());
        assert!(rows
            .iter()
            .filter_map(|row| row.command_sha256.as_deref())
            .all(|hash| hash == entry.command.checksum_sha256));
    }
    // This is a healthy local ACK/certificate component characterization. It
    // proves neither follower materialization nor RF3 crash-recovery readiness.
}
