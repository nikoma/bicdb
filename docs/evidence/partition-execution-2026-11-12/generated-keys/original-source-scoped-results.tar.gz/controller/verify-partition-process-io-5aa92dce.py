import hashlib,json,pathlib,sys,time
root=pathlib.Path('/root/bicdb-durability-s3');source='5aa92dcecb29b639251acc81a5d60428dfae96f7';out=root/'report-partition-process-io-5aa-independent.json'
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
record={'source':source,'status':'verification_failed','recorded_unix':time.time(),'scope':'Independent exact coverage/no duplicates/source+binary identity/original14ACK linkage/fulloldrecordmanifest/3stableopens/acknowledged-new/oldreaderrefusal-and-byteidentity checks. Replays original controller reports; not VM/physical HA/fullapplication.','matrices':[]}
try:
 build=json.loads((root/'report-partition-generated-current-probes.json').read_text());assert build['source']==source and build['status']=='focused_passed'
 probe=build['additional_binaries']['partition_crash_probe'];assert sha(pathlib.Path(probe['binary']))==probe['binary_sha256']
 old=root/'partition-old-store-fixtures-482-20261112';fixtures=json.loads((old/'result.json').read_text());ledger=[json.loads(x) for x in (old/'ack-ledger.jsonl').read_text().splitlines()];assert len(ledger)==14
 assert sha(pathlib.Path(fixtures['binary']))==fixtures['binary_sha256']
 for fixture in fixtures['cases']:
  db=pathlib.Path(fixture['directory'])/'db';actual={str(p.relative_to(db)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in db.rglob('*') if p.is_file() and not p.is_symlink()};assert actual==fixture['files']
 for kind,count in [('crash',152),('io-failure',96)]:
  folder=root/f'partition-{kind}-matrix-5aa92dce';p=folder/'result.json';r=json.loads(p.read_text());assert r['source']==source and r['production_equivalent']==source and r['originals_unchanged'] is True
  assert r['status']==('crash_matrix_passed' if kind=='crash' else 'io_failure_matrix_passed') and len(r['cases'])==count and len(r['controls'])==8
  assert r['binary']==probe['binary'] and r['binary_sha256']==probe['binary_sha256']
  wanted_controls={(m,c) for m in ['embedded_memory','server_paged'] for c in ['parent_heap','bad_child_bound','policy_keep_stored','policy_preserve_historical']};seen_controls=set();expected=set();seen=set()
  for c in r['controls']:
   key=(c['mode'],c['case']);assert key in wanted_controls and key not in seen_controls;seen_controls.add(key);assert c['native_commit_span']==1
   oldsnap=json.loads((folder/c['old_snapshot']).read_text());newsnap=json.loads((folder/c['new_snapshot']).read_text());assert oldsnap!=newsnap
   original='independent_child_policy' if c['case'].startswith('policy_') else c['case'];acks=[a for a in ledger if a['mode']==c['mode'] and a['case']==original];assert c['original_ACKs_linked']==len(acks)==len(oldsnap['rows']) and acks
   for a in acks:
    row=next(x for x in oldsnap['rows'] if x[0]==a['relation'] and x[1]==str(a['k']));assert row[3]['metadata']['payload']==a['payload'] and row[3]['id']==str(a['k'])
   if kind=='crash':
    points=['sql_partition.format_fence.'+s+':1' for s in ['after_write','after_sync','after_rename','after_dir_sync']]+['partition_upgrade.after_ack:1','transaction_log.write:1','transaction_log.sync:1']
    if c['mode']=='server_paged':points+=['commit.'+s+':1' for s in ['before_decision','after_txlog_durable','after_page_apply','after_marker','after_sync_publish']]
   else:points=['sql_partition.format_fence.'+s+':1' for s in ['write','sync','rename','dir_sync']]+['transaction_log.write:1','transaction_log.sync:1']
   expected.update((c['mode'],c['case'],point,variant) for point in points for variant in [False,True])
  assert seen_controls==wanted_controls
  for c in r['cases']:
   basename=pathlib.Path(c['database_copy']).name;case=next(name for mode,name in wanted_controls if mode==c['mode'] and basename.startswith(mode+'-'+name+'-'))
   variant=c['volatile_page_and_directory_emulation' if kind=='crash' else 'persistent_fault'];key=(c['mode'],case,c['point'],variant);assert key in expected and key not in seen;seen.add(key)
   assert c['passed'] is True and c['verify_exit']==0
   obs=c['observations'];assert len(obs)==3 and [x['reopen'] for x in obs]==[0,1,2] and len({x['state'] for x in obs})==1
   for x in obs:assert x['full_records_and_schemas_equal'] is True and x['native_indexes_valid'] is True and x['state'] in ['complete_old','complete_new']
   if kind=='crash':
    assert c['cut_exit']==-6 and c['cut_reached'] is True
    assert c['acknowledged']==(c['point']=='partition_upgrade.after_ack:1')
    if c['acknowledged']:assert all(x['state']=='complete_new' for x in obs)
   else:
    assert c['failure_exit']==0 and c['fault_reached'] is True and c['upgrade_acknowledged'] is False
    failure=c['failure_report'];assert failure['upgrade_acknowledged'] is False and failure['after_failure_write_refused'] is True and failure['error'] and failure['after_failure_error']
   if any(x['reader_fence'] for x in obs):assert c['old_reader_exit']!=0 and c['old_reader_refused'] is True and c['old_reader_byte_identity'] is True
  assert seen==expected and len(seen)==count
  record['matrices'].append({'path':str(p),'sha256':sha(p),'cases':count,'passed':count,'controls':8,'stable_old':sum(c['observations'][0]['state']=='complete_old' for c in r['cases']),'stable_new':sum(c['observations'][0]['state']=='complete_new' for c in r['cases'])})
 record.update(status='verified_passed',total_overlapping_case_invocations=248,unique_original_ACKs=14,originals_unchanged=True,binary_sha256=probe['binary_sha256'])
except BaseException as error:record['error']=repr(error)
assert not out.exists();out.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));sys.exit(0 if record['status']=='verified_passed' else 1)
