//! Write-ahead log, checkpoints, and crash recovery.
//!
//! Phase 3 of `docs/server-paged-storage-todo.md`:
//!
//! - "Extend the WAL with enough page/tuple intent to repeat committed changes
//!   idempotently and reject torn or out-of-order records."
//! - "Enforce write-ahead ordering: the relevant WAL is durable before a dirty
//!   data/index page may reach durable storage."
//! - "Implement group commit without weakening `fsync` semantics."
//! - "Implement fuzzy checkpoints that record a durable redo point while writes
//!   continue."
//!
//! # Physical logging, and what it costs
//!
//! Records carry **full page after-images**. Replay is then trivially
//! idempotent — writing the same page image twice is indistinguishable from
//! writing it once — which is what makes the crash matrix tractable: recovery
//! can replay from any point without tracking which changes it has already
//! applied.
//!
//! The cost is write amplification: modifying one 40-byte tuple logs a whole
//! page. Logical or physiological logging would log less but requires each
//! record to be replayable against a page in *unknown* state, which is where
//! recovery bugs live. Physical logging first, measured, is the right order —
//! and the amplification is visible in [`WalSnapshot::bytes_appended`] rather
//! than being a surprise later.
//!
//! # Write-ahead ordering
//!
//! [`Checkpointer`] owns the ordering. `log_and_write` appends the page image
//! before the page is made dirty in the pool, and `checkpoint` syncs the log
//! before flushing pages, so no dirty page can reach disk ahead of its log
//! record. The invariant lives in one type rather than in a rule everyone has
//! to remember at every call site.
//!
//! # Group commit
//!
//! Commits accumulate and one `fsync` covers all of them. `fsync` semantics are
//! not weakened: a commit does not return until the log is durable *past its
//! own LSN*. Waiters simply share the sync that satisfies them, which is the
//! whole point — throughput comes from amortizing the sync, never from skipping
//! it.

use std::fs::{File, OpenOptions};
use std::io::{Read, Seek, SeekFrom, Write};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::time::{Instant, SystemTime, UNIX_EPOCH};

use parking_lot::{Condvar, Mutex};

use crate::error::{PageError, Result};
use crate::health::DurabilityHealth;
use crate::mvcc::{RecoveredOutcomes, TxStatus};
use crate::page::{PageId, MAX_PAGE_SIZE};

/// Log sequence number. Monotonic, gap-free, never reused.
pub type Lsn = u64;

const RECORD_MAGIC: [u8; 4] = *b"BWAL";
/// magic + lsn + kind + reserved + payload_len + crc
const RECORD_HEADER_BYTES: usize = 4 + 8 + 1 + 3 + 4 + 4;
const RECORD_FIXED_BODY_BYTES: usize = 8 + 8;
/// Hard allocation ceiling for one decoded WAL record. Page images are the
/// largest supported payload; transaction and checkpoint records have none.
pub const MAX_WAL_RECORD_BYTES: usize =
    RECORD_HEADER_BYTES + RECORD_FIXED_BODY_BYTES + MAX_PAGE_SIZE as usize;

/// What a log record describes.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[repr(u8)]
pub enum RecordKind {
    /// Full after-image of one page.
    PageImage = 1,
    /// A transaction became durable. Everything logged before it is committed.
    Commit = 2,
    /// A checkpoint: everything before `redo_lsn` is already in the page file.
    Checkpoint = 3,
    /// A transaction was abandoned; its page images before this must not be
    /// treated as committed.
    Abort = 4,
}

impl RecordKind {
    fn from_u8(value: u8) -> Option<Self> {
        Some(match value {
            1 => Self::PageImage,
            2 => Self::Commit,
            3 => Self::Checkpoint,
            4 => Self::Abort,
            _ => return None,
        })
    }
}

/// One decoded log record.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct WalRecord {
    pub lsn: Lsn,
    pub kind: RecordKind,
    /// For `PageImage`, the page this is an image of.
    pub page_id: PageId,
    /// For `Commit`/`Abort`, the transaction; for `Checkpoint`, the redo LSN.
    pub transaction: u64,
    pub payload: Vec<u8>,
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct WalSnapshot {
    pub records_appended: u64,
    pub bytes_appended: u64,
    pub syncs: u64,
    pub sync_failures: u64,
    /// WAL records newly covered by successful physical sync operations.
    pub sync_records_total: u64,
    pub last_sync_records: u64,
    pub max_sync_records: u64,
    pub sync_latency: crate::manager::PageIoLatencySnapshot,
    /// Commits that were satisfied by another thread's sync.
    pub group_commit_savings: u64,
    pub checkpoints: u64,
    pub last_checkpoint_completed_at_millis: u64,
    /// Computed when the snapshot is taken; zero means no checkpoint has
    /// completed in this process.
    pub checkpoint_age_millis: u64,
    pub durable_lsn: Lsn,
    pub next_lsn: Lsn,
    pub redo_lsn: Lsn,
    /// Active-file seals into immutable `store.wal.<seq>` segments.
    #[serde(default)]
    pub segments_sealed: u64,
}

/// Outcome of replaying a log.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RecoveryReport {
    pub records_scanned: u64,
    pub pages_replayed: u64,
    /// Pages advertised by the pre-recovery allocator list and detached before
    /// the first replayed page image. Replayed allocations may make some live;
    /// the remainder stay safely orphaned until bounded reclamation.
    #[serde(default)]
    pub free_pages_detached: u64,
    /// Page images that belonged to no committed transaction and were skipped.
    pub uncommitted_skipped: u64,
    pub committed_transactions: u64,
    /// Records after the last valid one, discarded as a torn tail.
    pub truncated_bytes: u64,
    /// Logical WAL bytes present when recovery began.
    pub wal_bytes_scanned: u64,
    /// Number of bounded forward scans. Recovery deliberately makes two.
    pub scan_passes: u64,
    /// Largest validated header + body retained by the streaming scanner.
    pub peak_record_bytes: u64,
    /// Final commit/abort decisions restored into the recent MVCC table.
    pub transaction_outcomes: u64,
    /// Commit and abort records observed before duplicate decisions collapse.
    #[serde(default)]
    pub terminal_outcome_records: u64,
    /// Peak heap capacity used by compact transaction outcomes during pass one.
    #[serde(default)]
    pub peak_transaction_outcome_bytes: u64,
    /// Terminal outcomes absorbed into the durable watermark by the open-time
    /// freeze. Bounded by the exception capacity rather than left resident.
    #[serde(default)]
    pub frozen_outcomes_at_open: u64,
    /// Durable abort exceptions resident after the open-time freeze.
    #[serde(default)]
    pub abort_exceptions_at_open: u64,
    /// Terminal outcomes retained by the disk-backed status spill at open.
    #[serde(default)]
    pub status_spill_entries_at_open: u64,
    /// Status-spill pages chained at open.
    #[serde(default)]
    pub status_spill_pages_at_open: u64,
    /// The meta page used the pre-durable-abort-exceptions layout and was
    /// rewritten in the current layout at open (`accept_legacy_meta`).
    #[serde(default)]
    pub legacy_meta_migrated: bool,
    /// Highest transaction id named by any record in the log — including page
    /// images whose transaction never reached a terminal record. A crashed
    /// writer that evicted pages (steal) but never committed appears only
    /// here; `next_xid` must advance past it, or its id is reissued and the
    /// reissued transaction's commit retroactively blesses the crashed one's
    /// on-disk versions.
    #[serde(default)]
    pub max_record_transaction: u64,
    /// Sealed segments of a stale chain that ended before the checkpoint
    /// horizon, deleted unreplayed: the remains of an interrupted log reset
    /// (see `ResetShape` in `wal.rs`).
    #[serde(default)]
    pub stale_segments_discarded: u64,
    pub duration_nanos: u64,
    pub redo_lsn: Lsn,
    pub end_lsn: Lsn,
}

struct WalRecordView<'a> {
    lsn: Lsn,
    kind: RecordKind,
    page_id: PageId,
    transaction: u64,
    payload: &'a mut [u8],
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
struct WalScanReport {
    records: u64,
    valid_bytes: u64,
    truncated_bytes: u64,
    peak_record_bytes: u64,
    /// LSN of the first valid record of the whole chain.
    first_lsn: Option<Lsn>,
    last_lsn: Option<Lsn>,
}

struct SyncState {
    /// Highest LSN known durable on disk.
    durable_lsn: Lsn,
    /// A sync is in flight.
    syncing: bool,
}

#[derive(Debug, Default)]
struct CheckpointFreshness {
    completed_at_millis: u64,
    completed_at: Option<Instant>,
}

/// The write-ahead log.
#[derive(Debug)]
pub struct Wal {
    path: PathBuf,
    file: Mutex<File>,
    /// Fixed segment size; `0` = one unbounded active file (legacy). When an
    /// append would push the ACTIVE file past this at a record boundary, the
    /// file is made durable, renamed `store.wal.<seq>` (sealed, immutable —
    /// the unit of archiving and backup), and a fresh active file starts.
    segment_bytes: u64,
    /// Ascending first-LSN names of sealed segments currently on disk.
    /// Mutated only under the file mutex. First-LSN naming (not a restart-
    /// prone counter) plus the reopen floor makes every sealed name unique
    /// for the store's lifetime — the invariant a WAL archive needs.
    sealed: Mutex<Vec<u64>>,
    /// First LSN the CURRENT active file will contain (next_lsn at the
    /// moment it was created or reset). Becomes the file's sealed name.
    active_first_lsn: AtomicU64,
    /// Sealed segments with names <= this are safe for checkpoint reset to
    /// DELETE while archive retention is on (the archiver copied them).
    archived_through: AtomicU64,
    /// When set, reset() retains sealed segments beyond `archived_through`
    /// instead of deleting them, so a WAL archive never gaps. Growth is
    /// bounded only by the archiver keeping up — same failure mode as
    /// PostgreSQL's archive_command, and deliberately so.
    archive_retention: AtomicBool,
    /// The page-log archiver's own health. Its first failure stops
    /// [`Self::mark_archived_through`] for this handle.
    archive_health: std::sync::Arc<crate::health::ArchiveHealth>,
    /// Where this handle's archiver last archived to, and when this handle
    /// last verified the archive's confirmed prefix.
    archive_destination: Mutex<Option<PathBuf>>,
    archive_verified_at: Mutex<Option<Instant>>,
    /// Total bytes across sealed segments (the active file's bytes are
    /// `end_offset`).
    sealed_bytes: AtomicU64,
    next_lsn: AtomicU64,
    /// Bytes written to the ACTIVE file, i.e. its append offset.
    end_offset: AtomicU64,
    /// Active-file offset covered by the last successful sync. Only
    /// power-loss emulation in tests reads it.
    synced_offset: AtomicU64,
    /// Highest LSN of a commit record appended by [`Self::commit_unsynced`]
    /// (0: none). Page writeback syncs through it first, see
    /// [`Self::sync_deferred_commits`].
    deferred_commit_lsn: AtomicU64,
    sync_state: Mutex<SyncState>,
    sync_signal: Condvar,
    fsync: bool,
    redo_lsn: AtomicU64,
    metrics: Mutex<WalSnapshot>,
    checkpoint_freshness: Mutex<CheckpointFreshness>,
    /// Transactions with a commit record in the current log generation.
    /// Consulted by [`Self::abort`] so a commit-then-abort contradiction can
    /// never be written: recovery treats contradictory terminal records as
    /// corruption and refuses to open, so the natural cleanup path after a
    /// failed commit fsync (the record may be on disk even though the sync
    /// failed) must not append an abort. Cleared on [`Self::reset`], which
    /// discards the commit records it tracks. Contiguous transaction IDs are
    /// represented as ranges, with a hard range-count ceiling so a pinned
    /// checkpoint cannot turn this safety index into unbounded memory.
    committed_this_generation: Mutex<CommittedRanges>,
    /// Fail-closed durability state shared with the page file and the
    /// database host. The first failed append, sync, seal or reset moves it
    /// to `WriteFailed`; from then on no append is accepted and no sync
    /// publishes durability. A failed `fsync` can drop the dirty pages it
    /// could not write and clear the error, so a retried `fsync` that
    /// succeeds proves nothing about the records written before it.
    health: std::sync::Arc<DurabilityHealth>,
}

const MAX_COMMITTED_RANGES: usize = 4_096;

#[derive(Debug, Default)]
struct CommittedRanges {
    ranges: Vec<(u64, u64)>,
}

impl CommittedRanges {
    fn contains(&self, xid: u64) -> bool {
        self.ranges
            .binary_search_by(|(start, end)| {
                if xid < *start {
                    std::cmp::Ordering::Greater
                } else if xid > *end {
                    std::cmp::Ordering::Less
                } else {
                    std::cmp::Ordering::Equal
                }
            })
            .is_ok()
    }

    fn insert(&mut self, xid: u64) -> bool {
        if self.contains(xid) {
            return true;
        }
        let position = self.ranges.partition_point(|(_, end)| *end < xid);
        let merge_previous =
            position > 0 && self.ranges[position - 1].1.checked_add(1) == Some(xid);
        let merge_next =
            position < self.ranges.len() && xid.checked_add(1) == Some(self.ranges[position].0);
        match (merge_previous, merge_next) {
            (true, true) => {
                let next_end = self.ranges[position].1;
                self.ranges[position - 1].1 = next_end;
                self.ranges.remove(position);
            }
            (true, false) => self.ranges[position - 1].1 = xid,
            (false, true) => self.ranges[position].0 = xid,
            (false, false) if self.ranges.len() < MAX_COMMITTED_RANGES => {
                self.ranges.insert(position, (xid, xid));
            }
            (false, false) => return false,
        }
        true
    }

    fn clear(&mut self) {
        self.ranges.clear();
    }
}

#[allow(dead_code)]
impl std::fmt::Debug for SyncState {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("SyncState")
            .field("durable_lsn", &self.durable_lsn)
            .field("syncing", &self.syncing)
            .finish()
    }
}

impl Wal {
    /// Open or create a log with one unbounded active file.
    pub fn open(path: impl AsRef<Path>, fsync: bool) -> Result<Self> {
        Self::open_with_segments(path, fsync, 0)
    }

    /// Open or create a log; `segment_bytes > 0` seals the active file into
    /// immutable `store.wal.<seq>` segments as it fills. Sealed segments left
    /// by an earlier run are discovered and replayed regardless of the
    /// current setting, so the option can change between opens.
    pub fn open_with_segments(
        path: impl AsRef<Path>,
        fsync: bool,
        segment_bytes: u64,
    ) -> Result<Self> {
        Self::open_with_segments_and_floor(path, fsync, segment_bytes, 0)
    }

    /// `lsn_floor` (the superblock's checkpoint LSN horizon) keeps LSNs
    /// monotonic across truncate+reopen cycles: without it an emptied log
    /// restarts at 1 and sealed-segment names could recur.
    pub fn open_with_segments_and_floor(
        path: impl AsRef<Path>,
        fsync: bool,
        segment_bytes: u64,
        lsn_floor: u64,
    ) -> Result<Self> {
        let path = path.as_ref().to_path_buf();
        if let Some(parent) = path.parent() {
            if !parent.as_os_str().is_empty() {
                std::fs::create_dir_all(parent).map_err(|e| PageError::io(parent, e))?;
            }
        }
        let file = OpenOptions::new()
            .read(true)
            .write(true)
            .create(true)
            .truncate(false)
            .open(&path)
            .map_err(|e| PageError::io(&path, e))?;
        let end_offset = file.metadata().map_err(|e| PageError::io(&path, e))?.len();
        let (sealed, sealed_bytes) = discover_sealed_segments(&path)?;
        let initial_lsn = lsn_floor.max(1);
        // Archive retention outlives the handle that enabled it: a reopen
        // (and the checkpoints recovery runs) must not delete sealed segments
        // the archiver has not confirmed, or the archive gaps for good.
        let archive_retention = archive_retention_marker(&path).exists();
        // Segments an earlier handle confirmed durable in the archive (bytes
        // and directory entries, by its own fsyncs) stay confirmed: local
        // truncation may delete them. Unreadable means nothing confirmed.
        let confirmed = if archive_retention {
            read_archive_confirmed(&path)
        } else {
            0
        };

        Ok(Self {
            path,
            file: Mutex::new(file),
            segment_bytes,
            sealed: Mutex::new(sealed),
            active_first_lsn: AtomicU64::new(initial_lsn),
            archived_through: AtomicU64::new(confirmed),
            archive_retention: AtomicBool::new(archive_retention),
            archive_health: crate::health::ArchiveHealth::new(),
            archive_destination: Mutex::new(None),
            archive_verified_at: Mutex::new(None),
            sealed_bytes: AtomicU64::new(sealed_bytes),
            next_lsn: AtomicU64::new(initial_lsn),
            end_offset: AtomicU64::new(end_offset),
            synced_offset: AtomicU64::new(end_offset),
            deferred_commit_lsn: AtomicU64::new(0),
            sync_state: Mutex::new(SyncState {
                durable_lsn: 0,
                syncing: false,
            }),
            sync_signal: Condvar::new(),
            fsync,
            redo_lsn: AtomicU64::new(0),
            metrics: Mutex::new(WalSnapshot::default()),
            checkpoint_freshness: Mutex::new(CheckpointFreshness::default()),
            committed_this_generation: Mutex::new(CommittedRanges::default()),
            health: DurabilityHealth::new(),
        })
    }

    /// Share `health` with the other layers of the same database.
    pub fn with_health(mut self, health: std::sync::Arc<DurabilityHealth>) -> Self {
        self.health = health;
        self
    }

    /// This log's fail-closed durability state.
    pub fn health(&self) -> &std::sync::Arc<DurabilityHealth> {
        &self.health
    }

    /// Record a durability-critical I/O failure on this log.
    fn fail(&self, site: &str, path: &Path, error: impl std::fmt::Display) -> PageError {
        self.health
            .record_failure(site, &format!("{}: {error}", path.display()))
    }

    pub fn path(&self) -> &Path {
        &self.path
    }

    fn sealed_path(&self, sequence: u64) -> PathBuf {
        let mut os = self.path.as_os_str().to_os_string();
        os.push(format!(".{sequence}"));
        PathBuf::from(os)
    }

    /// Paths of the immutable sealed segments, ascending. What a WAL
    /// archiver or online backup streams before the active file.
    pub fn sealed_segment_paths(&self) -> Vec<PathBuf> {
        self.sealed
            .lock()
            .iter()
            .map(|sequence| self.sealed_path(*sequence))
            .collect()
    }

    /// Open independent read descriptors at one WAL boundary. The caller holds
    /// the paged writer gate and a backup pin, so reset cannot invalidate these
    /// prefixes. Subsequent rotation is safe: descriptors retain old inodes.
    pub(crate) fn capture_backup_files(
        &self,
        max_files: usize,
        deadline: std::time::Instant,
    ) -> Result<Vec<(PathBuf, File, u64)>> {
        let _writer = self.file.lock();
        let mut paths = self.sealed_segment_paths();
        paths.push(self.path.clone());
        if paths.len() > max_files {
            return Err(PageError::BackupSnapshot {
                reason: "captured WAL file limit exceeded".into(),
            });
        }
        let mut captured = Vec::with_capacity(paths.len());
        for path in paths {
            if std::time::Instant::now() >= deadline {
                return Err(PageError::BackupSnapshot {
                    reason: "WAL capture coordination budget exceeded".into(),
                });
            }
            let mut options = OpenOptions::new();
            options.read(true);
            #[cfg(unix)]
            {
                use std::os::unix::fs::OpenOptionsExt;
                options.custom_flags(libc::O_NOFOLLOW);
            }
            let file = options.open(&path).map_err(|e| PageError::io(&path, e))?;
            let meta = file.metadata().map_err(|e| PageError::io(&path, e))?;
            if !meta.is_file() {
                return Err(PageError::BackupSnapshot {
                    reason: "WAL source is not a regular file".into(),
                });
            }
            captured.push((path, file, meta.len()));
        }
        Ok(captured)
    }

    /// Explicitly seal the active file (online backup's consistency cut).
    /// A no-op when the active file is empty. Refused when segmentation is
    /// disabled: sealed files next to a legacy-layout store would be
    /// invisible to a pre-segmentation engine.
    pub fn seal_active(&self) -> Result<()> {
        if self.segment_bytes == 0 {
            return Err(PageError::InvalidMaintenanceLimits {
                reason: "WAL segmentation is disabled for this store (legacy monolithic \
                         layout); re-segment the page store to enable online-consistent backup"
                    .to_string(),
            });
        }
        let mut file = self.file.lock();
        let active = self.end_offset.load(Ordering::Acquire);
        if active == 0 {
            return Ok(());
        }
        self.seal_active_locked(&mut file, active)
    }

    /// Seal the active file: make it durable, rename it to the next sealed
    /// sequence, and start a fresh active file. Caller holds the file mutex.
    fn seal_active_locked(&self, file: &mut File, active_bytes: u64) -> Result<()> {
        self.health.check()?;
        if self.fsync {
            crate::test_faults::io_fault("page_log.seal_sync", &self.path)
                .and_then(|()| file.sync_data())
                .map_err(|e| self.fail("page_log.seal_sync", &self.path, e))?;
        } else {
            file.flush().map_err(|e| PageError::io(&self.path, e))?;
        }
        // The seal's own sync covers the whole file. Power-loss emulation
        // reads this offset; without it a crash right after the rename would
        // cut synced bytes out of the now-sealed segment.
        self.synced_offset.store(active_bytes, Ordering::Release);
        let sequence = self.active_first_lsn.load(Ordering::Acquire);
        let sealed_path = self.sealed_path(sequence);
        std::fs::rename(&self.path, &sealed_path)
            .map_err(|e| self.fail("page_log.seal_rename", &sealed_path, e))?;
        crate::test_faults::crash_point_with_locked_wal("wal_seal.after_rename", self);
        let fresh = OpenOptions::new()
            .read(true)
            .write(true)
            .create(true)
            .truncate(true)
            .open(&self.path)
            .map_err(|e| self.fail("page_log.seal_rename", &self.path, e))?;
        if self.fsync {
            // The rename is what makes the sealed name and the fresh active
            // file the log's layout. A swallowed directory sync used to let a
            // crash revive the pre-seal layout after this returned success.
            if let Some(parent) = self.path.parent().filter(|p| !p.as_os_str().is_empty()) {
                crate::test_faults::io_fault("page_log.seal_dir_sync", parent)
                    .and_then(|()| File::open(parent))
                    .and_then(|dir| dir.sync_all())
                    .map_err(|e| self.fail("page_log.seal_dir_sync", parent, e))?;
            }
        }
        *file = fresh;
        self.active_first_lsn
            .store(self.next_lsn.load(Ordering::Acquire), Ordering::Release);
        self.sealed.lock().push(sequence);
        self.sealed_bytes.fetch_add(active_bytes, Ordering::AcqRel);
        self.end_offset.store(0, Ordering::Release);
        self.synced_offset.store(0, Ordering::Release);
        let mut metrics = self.metrics.lock();
        metrics.segments_sealed = metrics.segments_sealed.saturating_add(1);
        Ok(())
    }

    pub fn next_lsn(&self) -> Lsn {
        self.next_lsn.load(Ordering::Acquire)
    }

    pub fn durable_lsn(&self) -> Lsn {
        self.sync_state.lock().durable_lsn
    }

    pub fn redo_lsn(&self) -> Lsn {
        self.redo_lsn.load(Ordering::Acquire)
    }

    pub fn snapshot(&self) -> WalSnapshot {
        let mut snapshot = *self.metrics.lock();
        snapshot.durable_lsn = self.durable_lsn();
        snapshot.next_lsn = self.next_lsn();
        snapshot.redo_lsn = self.redo_lsn();
        let checkpoint = self.checkpoint_freshness.lock();
        snapshot.last_checkpoint_completed_at_millis = checkpoint.completed_at_millis;
        snapshot.checkpoint_age_millis = checkpoint
            .completed_at
            .map(|completed| u64::try_from(completed.elapsed().as_millis()).unwrap_or(u64::MAX))
            .unwrap_or(0);
        snapshot
    }

    /// Append a record, returning its LSN. Does not sync.
    fn append(
        &self,
        kind: RecordKind,
        page_id: PageId,
        transaction: u64,
        payload: &[u8],
    ) -> Result<Lsn> {
        let mut body = Vec::with_capacity(16 + payload.len());
        body.extend_from_slice(&page_id.to_le_bytes());
        body.extend_from_slice(&transaction.to_le_bytes());
        body.extend_from_slice(payload);

        // The LSN is assigned *under the file lock*, together with the append.
        //
        // Assigning it first and locking afterwards is the obvious-looking
        // version and it is wrong: two threads can take LSNs 5 and 6 and then
        // write in the opposite order, leaving the log physically out of
        // sequence. Recovery reads the log in file order, so it would stop at
        // the discontinuity and silently discard everything after it — losing
        // committed work with no error anywhere. Holding one lock across both
        // makes file order and LSN order the same thing by construction.
        let lsn;
        let written;
        {
            let mut file = self.file.lock();
            // Checked under the file lock: once a failure is recorded no
            // further record reaches the file, so nothing appended after it
            // can be mistaken for part of the log's durable prefix.
            self.health.check()?;
            // Seal at record boundaries only: a record never spans segment
            // files, so every sealed file is a self-contained record run.
            if self.segment_bytes > 0 {
                let active = self.end_offset.load(Ordering::Acquire);
                let record_bytes = (RECORD_HEADER_BYTES + body.len()) as u64;
                if active > 0 && active.saturating_add(record_bytes) > self.segment_bytes {
                    self.seal_active_locked(&mut file, active)?;
                }
            }
            lsn = self.next_lsn.fetch_add(1, Ordering::AcqRel);

            let mut buffer = Vec::with_capacity(RECORD_HEADER_BYTES + body.len());
            buffer.extend_from_slice(&RECORD_MAGIC);
            buffer.extend_from_slice(&lsn.to_le_bytes());
            buffer.push(kind as u8);
            buffer.extend_from_slice(&[0u8; 3]);
            buffer.extend_from_slice(&(body.len() as u32).to_le_bytes());

            let mut hasher = crc32fast::Hasher::new();
            hasher.update(&buffer);
            hasher.update(&body);
            buffer.extend_from_slice(&hasher.finalize().to_le_bytes());
            buffer.extend_from_slice(&body);

            // A failed or partial write leaves a torn record in the middle of
            // the log and burns its LSN: recovery stops at it and discards
            // everything after. Nothing may be appended behind it.
            crate::test_faults::io_fault("page_log.write", &self.path)
                .and_then(|()| file.seek(SeekFrom::End(0)).map(|_| ()))
                .and_then(|()| file.write_all(&buffer))
                .map_err(|e| self.fail("page_log.write", &self.path, e))?;
            written = buffer.len();
            // Keep the published append offset in the same critical section as
            // the bytes it describes. A concurrent segment seal/reset must
            // never observe the new file length with the old counter (or the
            // reverse) and make a retention or truncation decision from a
            // torn logical state.
            self.end_offset.fetch_add(written as u64, Ordering::AcqRel);
        }

        let mut metrics = self.metrics.lock();
        metrics.records_appended = metrics.records_appended.saturating_add(1);
        metrics.bytes_appended = metrics.bytes_appended.saturating_add(written as u64);
        Ok(lsn)
    }

    /// Log a full page after-image.
    pub fn log_page_image(&self, page_id: PageId, transaction: u64, image: &[u8]) -> Result<Lsn> {
        self.append(RecordKind::PageImage, page_id, transaction, image)
    }

    /// Log a commit and make the log durable through it.
    ///
    /// Returns after the commit record is on disk, never before.
    pub fn commit(&self, transaction: u64) -> Result<Lsn> {
        let lsn = self.append_commit(transaction)?;
        // Recorded before the sync: the record is in the log whether or not
        // the fsync below succeeds, and it is the record's existence that
        // must forbid a later abort for the same transaction.
        self.sync_through(lsn)?;
        Ok(lsn)
    }

    /// Log a commit WITHOUT making it durable. Returns the record's LSN; the
    /// caller owns the obligation to `sync_through` it before anything relies
    /// on it surviving a crash. Only for transactions whose redo is durable
    /// elsewhere, so that losing this record loses nothing.
    pub fn commit_unsynced(&self, transaction: u64) -> Result<Lsn> {
        let lsn = self.append_commit(transaction)?;
        self.deferred_commit_lsn.fetch_max(lsn, Ordering::AcqRel);
        Ok(lsn)
    }

    /// Make every commit record appended by [`Self::commit_unsynced`] so far
    /// durable. A no-op when there is none, or when it is already durable.
    ///
    /// The writeback barrier needs this. A page whose after-image was already
    /// logged (by a commit's `log_dirty_pages`) is written back without a new
    /// log record, and with a synced commit that was safe: logged implied
    /// durable. A deferred commit breaks that implication, so before such a
    /// page reaches the page file the log is synced through the deferred
    /// commits that may have logged it (WAL before data, I5).
    pub fn sync_deferred_commits(&self) -> Result<()> {
        let lsn = self.deferred_commit_lsn.load(Ordering::Acquire);
        if lsn == 0 {
            return Ok(());
        }
        self.sync_through(lsn)
    }

    /// Highest commit LSN appended by [`Self::commit_unsynced`], or 0 if the
    /// log never took a deferred commit. Synced commits never set it, so on
    /// the default commit path it stays 0.
    pub fn deferred_commit_lsn(&self) -> Lsn {
        self.deferred_commit_lsn.load(Ordering::Acquire)
    }

    /// Test support: the active-file offset the last successful sync covered.
    #[cfg(test)]
    pub(crate) fn synced_offset_for_test(&self) -> u64 {
        self.synced_offset.load(Ordering::Acquire)
    }

    fn append_commit(&self, transaction: u64) -> Result<Lsn> {
        if !self.committed_this_generation.lock().insert(transaction) {
            return Err(PageError::InvalidMaintenanceLimits {
                reason: format!(
                    "WAL generation exceeds the bounded {MAX_COMMITTED_RANGES}-range commit index"
                ),
            });
        }
        self.append(RecordKind::Commit, 0, transaction, &[])
    }

    /// Power-loss emulation for tests: cut the active file back to what the
    /// last successful sync covered. Sealed segments were synced when sealed.
    pub(crate) fn discard_unsynced_tail_for_test(&self) {
        // Under the file lock: `sync_through` publishes `synced_offset` before
        // releasing it, so no sync can be half-recorded here, and no append
        // can land after the cut. Holding the lock is fine, the process
        // aborts next.
        let file = self.file.lock();
        let synced = self.synced_offset.load(Ordering::Acquire);
        let _ = file.set_len(synced);
        let _ = file.sync_all();
        std::mem::forget(file);
    }

    /// Log an abort. Not synced: an abandoned transaction that is lost to a
    /// crash is indistinguishable from one that never committed, and recovery
    /// discards uncommitted work anyway.
    ///
    /// Commit wins: if this log generation already holds a commit record for
    /// `transaction` — including one whose fsync failed, since the bytes may
    /// be on disk regardless — the abort is not appended. Recovery treats a
    /// commit-then-abort pair as corruption and refuses to open, so the pair
    /// must be unwritable in the first place.
    pub fn abort(&self, transaction: u64) -> Result<Lsn> {
        if self.committed_this_generation.lock().contains(transaction) {
            return Ok(self.next_lsn().saturating_sub(1));
        }
        self.append(RecordKind::Abort, 0, transaction, &[])
    }

    /// Make the log durable through `lsn`, sharing one `fsync` across waiters.
    ///
    /// The sharing is what makes this group commit. It does not weaken
    /// durability: a caller returns only once `durable_lsn >= lsn`, so its own
    /// record is on disk. It simply may be another thread's `fsync` that put it
    /// there.
    pub fn sync_through(&self, lsn: Lsn) -> Result<()> {
        let mut state = self.sync_state.lock();
        loop {
            // Durability published before any failure is real: a successful
            // sync covered it. `durable_lsn` never advances after a failure.
            if state.durable_lsn >= lsn {
                return Ok(());
            }
            // Fail-closed: a waiter whose record was not covered before the
            // failure gets the failure, never a retry of its own. Retrying is
            // what turned a failed fsync into a false durability report.
            self.health.check()?;
            if state.syncing {
                // Someone else is syncing; their sync may cover us.
                let mut metrics = self.metrics.lock();
                metrics.group_commit_savings = metrics.group_commit_savings.saturating_add(1);
                drop(metrics);
                self.sync_signal.wait(&mut state);
                continue;
            }

            state.syncing = true;
            // The target is captured before releasing the lock: anything
            // appended after this point is not promised by this sync.
            let target = self.next_lsn.load(Ordering::Acquire).saturating_sub(1);
            drop(state);

            let mut file = self.file.lock();
            let covered_offset = self.end_offset.load(Ordering::Acquire);
            let started = Instant::now();
            let result = if self.fsync {
                crate::test_faults::io_fault("page_log.sync", &self.path)
                    .and_then(|()| file.sync_data())
                    .map_err(|e| self.fail("page_log.sync", &self.path, e))
            } else {
                file.flush().map_err(|e| PageError::io(&self.path, e))
            };
            // A failure recorded anywhere while this sync ran (a torn append,
            // a failed seal) fences the log: the target may name the record
            // that failed, so this sync publishes nothing.
            let result = result.and_then(|()| self.health.check());
            let elapsed = started.elapsed();
            if result.is_ok() {
                self.synced_offset.store(covered_offset, Ordering::Release);
            }
            drop(file);

            state = self.sync_state.lock();
            state.syncing = false;
            match result {
                Ok(()) => {
                    let records = target.saturating_sub(state.durable_lsn);
                    state.durable_lsn = state.durable_lsn.max(target);
                    let mut metrics = self.metrics.lock();
                    metrics.syncs = metrics.syncs.saturating_add(1);
                    metrics.sync_records_total = metrics.sync_records_total.saturating_add(records);
                    metrics.last_sync_records = records;
                    metrics.max_sync_records = metrics.max_sync_records.max(records);
                    metrics.sync_latency.observe(elapsed);
                }
                Err(error) => {
                    let mut metrics = self.metrics.lock();
                    metrics.sync_failures = metrics.sync_failures.saturating_add(1);
                    self.sync_signal.notify_all();
                    return Err(error);
                }
            }
            self.sync_signal.notify_all();
        }
    }

    /// Make everything appended so far durable.
    pub fn sync(&self) -> Result<()> {
        let target = self.next_lsn.load(Ordering::Acquire).saturating_sub(1);
        self.sync_through(target)
    }

    /// Record a checkpoint: everything before `redo_lsn` is already in the page
    /// file, so recovery may start there.
    ///
    /// The caller's contract: every page dirtied before `redo_lsn` has been
    /// flushed. Records appended between `redo_lsn` and this record are
    /// replayed, because recovery redoes from this record's `redo_lsn` when it
    /// is the last checkpoint record below the published horizon
    /// ([`recover_with_outcomes`]). Publishing the horizon (`publish_root` in
    /// [`Checkpointer::finish_checkpoint`]) is what must be fenced: no page
    /// image may be appended between this record and the publication, which
    /// both checkpoint paths guarantee by holding the store's writer gate
    /// with no dirty page left.
    pub fn checkpoint(&self, redo_lsn: Lsn, root_page: PageId) -> Result<Lsn> {
        let lsn = self.append(RecordKind::Checkpoint, root_page, redo_lsn, &[])?;
        self.sync_through(lsn)?;
        self.redo_lsn.store(redo_lsn, Ordering::Release);
        {
            let mut metrics = self.metrics.lock();
            metrics.checkpoints = metrics.checkpoints.saturating_add(1);
        }
        {
            let mut checkpoint = self.checkpoint_freshness.lock();
            checkpoint.completed_at_millis = unix_time_millis();
            checkpoint.completed_at = Some(Instant::now());
        }
        Ok(lsn)
    }

    /// Read every valid record in the log, in order.
    ///
    /// Stops at the first record that fails to decode and reports how many
    /// bytes were discarded. A torn tail is *expected* after a crash — the log
    /// is appended to continuously, so a crash almost always lands mid-record —
    /// and truncating it is correct rather than a corruption event: those bytes
    /// were never acknowledged to anyone.
    ///
    /// This compatibility helper materializes the returned records. Startup
    /// recovery uses the bounded streaming scanner directly and never calls it.
    pub fn read_all(&self) -> Result<(Vec<WalRecord>, u64)> {
        let mut records = Vec::new();
        let scan = self.scan_records(
            MAX_WAL_RECORD_BYTES - RECORD_HEADER_BYTES,
            false,
            |record| {
                records.push(WalRecord {
                    lsn: record.lsn,
                    kind: record.kind,
                    page_id: record.page_id,
                    transaction: record.transaction,
                    payload: record.payload.to_vec(),
                });
                Ok(())
            },
        )?;

        Ok((records, scan.truncated_bytes))
    }

    /// Validate the complete sealed+active chain without retaining record
    /// payloads. Verification uses the same bounded streaming decoder as
    /// recovery and refuses sealed corruption or LSN gaps.
    pub fn verify_integrity(&self) -> Result<u64> {
        Ok(self
            .scan_records(
                MAX_WAL_RECORD_BYTES - RECORD_HEADER_BYTES,
                false,
                |_| Ok(()),
            )?
            .truncated_bytes)
    }

    /// Stream only terminal decisions in `[start_xid, end_xid)`, validating
    /// the WAL while keeping page-image payload memory bounded to one record.
    /// Intended for offline forensic reconstruction of a damaged status spill.
    pub fn terminal_outcomes_in_range(
        &self,
        start_xid: u64,
        end_xid: u64,
    ) -> Result<(Vec<(u64, TxStatus)>, u64)> {
        if start_xid >= end_xid {
            return Err(PageError::InvalidMaintenanceLimits {
                reason: "WAL outcome range must have start_xid < end_xid".to_string(),
            });
        }
        let mut outcomes = std::collections::BTreeMap::new();
        let scan = self.scan_records(
            MAX_WAL_RECORD_BYTES - RECORD_HEADER_BYTES,
            false,
            |record| {
                let status = match record.kind {
                    RecordKind::Commit => TxStatus::Committed,
                    RecordKind::Abort => TxStatus::Aborted,
                    _ => return Ok(()),
                };
                if record.transaction < start_xid || record.transaction >= end_xid {
                    return Ok(());
                }
                if let Some(previous) = outcomes.insert(record.transaction, status) {
                    if previous != status {
                        return Err(PageError::WalCorruption {
                            path: self.path.clone(),
                            lsn: record.lsn,
                            reason: format!(
                                "transaction {} has contradictory commit and abort records",
                                record.transaction
                            ),
                        });
                    }
                }
                Ok(())
            },
        )?;
        Ok((outcomes.into_iter().collect(), scan.truncated_bytes))
    }

    /// Stream valid records using one reusable, explicitly bounded body
    /// allocation. When requested, torn-tail truncation happens while the WAL
    /// file lock is still held, so a concurrent append cannot be discarded.
    fn scan_records<F>(
        &self,
        max_body_bytes: usize,
        truncate_torn_tail: bool,
        visit: F,
    ) -> Result<WalScanReport>
    where
        F: FnMut(WalRecordView<'_>) -> Result<()>,
    {
        self.scan_records_checked(max_body_bytes, truncate_torn_tail, |_| Ok(()), visit)
    }

    /// [`Self::scan_records`], running `check` on the complete scan before
    /// any torn tail is truncated, so a rejected log is left untouched.
    fn scan_records_checked<F, C>(
        &self,
        max_body_bytes: usize,
        truncate_torn_tail: bool,
        check: C,
        mut visit: F,
    ) -> Result<WalScanReport>
    where
        F: FnMut(WalRecordView<'_>) -> Result<()>,
        C: FnOnce(&WalScanReport) -> Result<()>,
    {
        let max_body_bytes = max_body_bytes.min(MAX_WAL_RECORD_BYTES - RECORD_HEADER_BYTES);
        let mut file = self.file.lock();
        let mut scan = WalScanReport::default();
        let mut expected_lsn = None;

        // Sealed segments first, ascending. They are immutable and were made
        // durable before sealing, so a scan that stops early inside one — or
        // an LSN chain break between files — is CORRUPTION, never a torn
        // tail: truncating here would silently drop later sealed segments
        // full of acknowledged commits.
        let sealed = self.sealed.lock().clone();
        for sequence in &sealed {
            let path = self.sealed_path(*sequence);
            let mut segment = File::open(&path).map_err(|e| PageError::io(&path, e))?;
            let (valid, _) = scan_wal_file(
                &mut segment,
                &path,
                max_body_bytes,
                &mut expected_lsn,
                &mut scan,
                &mut visit,
            )?;
            let segment_bytes = segment
                .metadata()
                .map_err(|e| PageError::io(&path, e))?
                .len();
            if valid != segment_bytes {
                return Err(PageError::WalCorruption {
                    path,
                    lsn: scan.last_lsn.unwrap_or(0),
                    reason: format!(
                        "sealed WAL segment holds {segment_bytes} bytes but only {valid} decode; \
                         a sealed segment can never have a torn tail"
                    ),
                });
            }
        }

        // The active file: a torn tail here is expected after a crash.
        file.seek(SeekFrom::Start(0))
            .map_err(|error| PageError::io(&self.path, error))?;
        let file_bytes = file
            .metadata()
            .map_err(|error| PageError::io(&self.path, error))?
            .len();
        let (active_valid, active_first_lsn) = scan_wal_file(
            &mut *file,
            &self.path,
            max_body_bytes,
            &mut expected_lsn,
            &mut scan,
            &mut visit,
        )?;

        scan.truncated_bytes = file_bytes.saturating_sub(active_valid);
        check(&scan)?;
        if truncate_torn_tail && scan.truncated_bytes > 0 {
            file.set_len(active_valid)
                .map_err(|error| PageError::io(&self.path, error))?;
        }
        drop(file);

        if truncate_torn_tail {
            self.end_offset.store(active_valid, Ordering::Release);
            let floor = self.next_lsn.load(Ordering::Acquire);
            let next = scan
                .last_lsn
                .map_or(floor.max(1), |lsn| (lsn + 1).max(floor));
            self.next_lsn.store(next, Ordering::Release);
            self.active_first_lsn
                .store(active_first_lsn.unwrap_or(next), Ordering::Release);
        }

        Ok(scan)
    }

    /// Discard a torn tail so later appends are contiguous.
    pub fn truncate_torn_tail(&self) -> Result<u64> {
        Ok(self
            .scan_records(MAX_WAL_RECORD_BYTES - RECORD_HEADER_BYTES, true, |_| Ok(()))?
            .truncated_bytes)
    }

    /// Reset the log after a checkpoint has made it redundant: DELETE every
    /// sealed segment archive retention does not still need, then truncate
    /// the active file.
    ///
    /// Only safe once every page dirtied by the discarded records is durable in
    /// the page file. Callers get there through [`Checkpointer::checkpoint`].
    ///
    /// # Crash order
    ///
    /// The active file holds the checkpoint record that names the redo point,
    /// so it is emptied LAST. The sealed segments go first, oldest first, and
    /// the directory is synced before the truncation, which is synced too. A
    /// crash at any point leaves either a chain that still reaches the
    /// checkpoint record (oldest segments gone, active file intact: recovery
    /// honours the redo point) or an empty log. The opposite order left newer
    /// sealed segments next to an empty active file: a chain of records all
    /// older than the published horizon, with no checkpoint record, which
    /// recovery replayed over newer pages (`docs/recovery-semantics.md`,
    /// GAP-2). [`recover_with_outcomes`] still recognises that shape, as an
    /// older engine leaves it, and finishes the reset instead of replaying it.
    ///
    /// Every step fails closed: an unlink, directory sync, truncation or sync
    /// failure records a durability failure (sites `page_log.reset_unlink`,
    /// `page_log.reset_dir_sync`, `page_log.reset`, `page_log.reset_sync`).
    pub fn reset(&self) -> Result<bool> {
        let mut file = self.file.lock();
        // A fenced store never discards its log: after a failure the page
        // file's durability is unproven, and the log is the redo. A failure
        // or crash part-way through is safe by the crash order below.
        self.health.check()?;
        let retention = self.archive_retention.load(Ordering::Acquire);
        // Under archive retention EVERY record must flow through a sealed
        // segment before local truncation discards it — the checkpoint
        // record and any commits since the last seal are redundant for
        // local recovery (their pages are durable) but a hole in the
        // archive's LSN chain would fail roll-forward closed forever.
        if retention && self.segment_bytes > 0 {
            let active = self.end_offset.load(Ordering::Acquire);
            if active > 0 {
                self.seal_active_locked(&mut file, active)?;
            }
            crate::test_faults::crash_point_with_locked_wal("wal_reset.after_seal", self);
        }
        let archived_through = self.archived_through.load(Ordering::Acquire);
        let mut sealed = self.sealed.lock();
        // Oldest first. One pass over the list: `kept` is what stays on disk
        // (retained by archive retention, or not reached because a deletion
        // failed), so list and disk agree on every return.
        let pending = std::mem::take(&mut *sealed);
        let mut kept = Vec::new();
        let mut deleted_any = false;
        let mut failure = None;
        for (index, &sequence) in pending.iter().enumerate() {
            let path = self.sealed_path(sequence);
            // With archive retention on, a sealed segment the archiver has
            // not confirmed yet must survive local truncation — deleting it
            // would gap the archive chain forever.
            if retention && sequence > archived_through {
                kept.push(sequence);
                continue;
            }
            if let Err(error) = crate::test_faults::io_fault("page_log.reset_unlink", &path)
                .and_then(|()| std::fs::remove_file(&path))
            {
                kept.extend_from_slice(&pending[index..]);
                failure = Some(self.fail("page_log.reset_unlink", &path, error));
                break;
            }
            deleted_any = true;
            crate::test_faults::crash_point_with_locked_wal("wal_reset.after_segment_delete", self);
        }
        *sealed = kept;
        self.sealed_bytes
            .store(self.sealed_bytes_on_disk(&sealed), Ordering::Release);
        if let Some(failure) = failure {
            return Err(failure);
        }
        if deleted_any && self.fsync {
            // The deletions must be durable before the truncation can be.
            // Otherwise a power cut may keep the truncation and revive the
            // deleted segments: the shape this order exists to prevent.
            if let Some(parent) = self.path.parent().filter(|p| !p.as_os_str().is_empty()) {
                crate::test_faults::io_fault("page_log.reset_dir_sync", parent)
                    .and_then(|()| File::open(parent))
                    .and_then(|dir| dir.sync_all())
                    .map_err(|e| self.fail("page_log.reset_dir_sync", parent, e))?;
            }
        }
        crate::test_faults::crash_point_with_locked_wal("wal_reset.after_segments_removed", self);
        crate::test_faults::io_fault("page_log.reset", &self.path)
            .and_then(|()| file.set_len(0))
            .map_err(|e| self.fail("page_log.reset", &self.path, e))?;
        if self.fsync {
            crate::test_faults::io_fault("page_log.reset_sync", &self.path)
                .and_then(|()| file.sync_all())
                .map_err(|e| self.fail("page_log.reset_sync", &self.path, e))?;
        }
        // Power-loss emulation treats the truncation as durable from here.
        self.synced_offset.store(0, Ordering::Release);
        crate::test_faults::crash_point_with_locked_wal("wal_reset.after_active_truncate", self);
        let locally_empty = sealed.is_empty();
        drop(sealed);
        drop(file);
        self.end_offset.store(0, Ordering::Release);
        self.synced_offset.store(0, Ordering::Release);
        let next = self.next_lsn.load(Ordering::Acquire);
        self.active_first_lsn.store(next, Ordering::Release);
        self.sync_state.lock().durable_lsn = next.saturating_sub(1);
        // The truncation discarded every commit record this set tracked.
        self.committed_this_generation.lock().clear();
        Ok(locally_empty)
    }

    fn sealed_bytes_on_disk(&self, sealed: &[u64]) -> u64 {
        sealed
            .iter()
            .map(|sequence| {
                std::fs::metadata(self.sealed_path(*sequence))
                    .map(|metadata| metadata.len())
                    .unwrap_or(0)
            })
            .sum()
    }

    /// Classify the log against the page file's horizon before recovery
    /// touches anything. Read-only. See [`ResetShape`].
    fn reset_shape(&self, max_body_bytes: usize, horizon: Lsn) -> Result<ResetShape> {
        if horizon == 0 {
            return Ok(ResetShape::Normal);
        }
        let mut file = self.file.lock();
        let sealed = self.sealed.lock().clone();
        let mut ignore = |_: WalRecordView<'_>| -> Result<()> { Ok(()) };
        // The active file's own valid run, ignoring continuity with the
        // sealed chain: its first and last LSN.
        let active_bytes = file
            .metadata()
            .map_err(|error| PageError::io(&self.path, error))?
            .len();
        let mut active_scan = WalScanReport::default();
        let (_, active_first) = scan_wal_file(
            &mut *file,
            &self.path,
            max_body_bytes,
            &mut None,
            &mut active_scan,
            &mut ignore,
        )?;
        let active_last = active_scan.last_lsn;
        let Some(&last_sealed) = sealed.last() else {
            return Ok(match active_last {
                Some(last) if last.saturating_add(1) < horizon => ResetShape::Corrupt(format!(
                    "the page log ends at LSN {last}, before the checkpoint record {} of the \
                     page file's horizon {horizon}",
                    horizon - 1
                )),
                _ => ResetShape::Normal,
            });
        };
        let path = self.sealed_path(last_sealed);
        let mut segment = File::open(&path).map_err(|e| PageError::io(&path, e))?;
        let mut sealed_scan = WalScanReport::default();
        scan_wal_file(
            &mut segment,
            &path,
            max_body_bytes,
            &mut None,
            &mut sealed_scan,
            &mut ignore,
        )?;
        // An undecodable sealed segment is corruption pass 1 reports.
        let Some(sealed_last) = sealed_scan.last_lsn else {
            return Ok(ResetShape::Normal);
        };
        let chain_last = match (active_first, active_last) {
            (Some(first), Some(last)) if first == sealed_last + 1 => last,
            _ => sealed_last,
        };
        if chain_last.saturating_add(1) >= horizon {
            return Ok(ResetShape::Normal);
        }
        Ok(if active_bytes == 0 {
            ResetShape::InterruptedReset
        } else if active_first == Some(horizon) {
            ResetShape::StaleSealedBeforeActive
        } else {
            ResetShape::Corrupt(format!(
                "the sealed page-log segments end at LSN {sealed_last}, before the checkpoint \
                 record {} of the page file's horizon {horizon}, and the active file \
                 ({active_bytes} bytes) does not start at the horizon (first LSN {active_first:?})",
                horizon - 1
            ))
        })
    }

    /// Delete every sealed segment (all older than the horizon, see
    /// [`ResetShape::StaleSealedBeforeActive`]) without touching the active
    /// file, then sync the directory. Fails closed. Returns how many went.
    fn drop_stale_sealed_segments(&self) -> Result<u64> {
        let _file = self.file.lock();
        self.health.check()?;
        let mut sealed = self.sealed.lock();
        let pending = std::mem::take(&mut *sealed);
        let mut deleted = 0u64;
        for (index, &sequence) in pending.iter().enumerate() {
            let path = self.sealed_path(sequence);
            if let Err(error) = crate::test_faults::io_fault("page_log.reset_unlink", &path)
                .and_then(|()| std::fs::remove_file(&path))
            {
                *sealed = pending[index..].to_vec();
                self.sealed_bytes
                    .store(self.sealed_bytes_on_disk(&sealed), Ordering::Release);
                return Err(self.fail("page_log.reset_unlink", &path, error));
            }
            deleted += 1;
        }
        self.sealed_bytes.store(0, Ordering::Release);
        if self.fsync {
            if let Some(parent) = self.path.parent().filter(|p| !p.as_os_str().is_empty()) {
                crate::test_faults::io_fault("page_log.reset_dir_sync", parent)
                    .and_then(|()| File::open(parent))
                    .and_then(|dir| dir.sync_all())
                    .map_err(|e| self.fail("page_log.reset_dir_sync", parent, e))?;
            }
        }
        Ok(deleted)
    }

    /// Turn on archive retention: checkpoint truncation keeps sealed
    /// segments the archiver has not confirmed via
    /// [`Self::mark_archived_through`]. The setting is persisted next to the
    /// log (`<log>-archive-retention`), so it also holds for every later
    /// handle until [`Self::disable_archive_retention`]; a reopened handle
    /// starts with nothing confirmed, so it keeps every sealed segment until
    /// the archiver confirms it again.
    pub fn enable_archive_retention(&self) -> Result<()> {
        // In memory first: from here on nothing unconfirmed is deleted, even
        // if persisting the setting fails below.
        self.archive_retention.store(true, Ordering::Release);
        let marker = archive_retention_marker(&self.path);
        if marker.exists() {
            return Ok(());
        }
        let persist = || -> std::io::Result<()> {
            crate::test_faults::io_fault("wal_archive.retention", &marker)?;
            let file = File::create(&marker)?;
            if self.fsync {
                file.sync_all()?;
                if let Some(parent) = marker.parent().filter(|p| !p.as_os_str().is_empty()) {
                    File::open(parent)?.sync_all()?;
                }
            }
            Ok(())
        };
        persist().map_err(|error| {
            let failure = self.record_archive_failure("wal_archive.retention", &marker, &error);
            PageError::ArchiveFailed {
                site: failure.site,
                detail: failure.error,
            }
        })
    }

    /// Turn archive retention off (archiving was stopped on purpose): the
    /// next checkpoint deletes sealed segments whether archived or not.
    pub fn disable_archive_retention(&self) -> Result<()> {
        let marker = archive_retention_marker(&self.path);
        for path in [marker.clone(), archive_confirmed_path(&self.path)] {
            match std::fs::remove_file(&path) {
                Ok(()) => {}
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
                Err(error) => return Err(PageError::io(&path, error)),
            }
        }
        if self.fsync {
            if let Some(parent) = marker.parent().filter(|p| !p.as_os_str().is_empty()) {
                File::open(parent)
                    .and_then(|dir| dir.sync_all())
                    .map_err(|e| PageError::io(parent, e))?;
            }
        }
        self.archive_retention.store(false, Ordering::Release);
        Ok(())
    }

    /// Whether checkpoint truncation keeps unarchived sealed segments.
    pub fn archive_retention_enabled(&self) -> bool {
        self.archive_retention.load(Ordering::Acquire)
    }

    /// Highest sealed-segment name this handle has confirmed archived.
    pub fn archived_through(&self) -> u64 {
        self.archived_through.load(Ordering::Acquire)
    }

    /// Sealed segments on disk named above [`Self::archived_through`]
    /// (count, total bytes): what archive retention keeps locally until the
    /// archiver confirms them. One `stat` per such segment.
    pub fn unarchived_sealed(&self) -> (u64, u64) {
        let through = self.archived_through();
        let sealed = self.sealed.lock().clone();
        let mut count = 0u64;
        let mut bytes = 0u64;
        for sequence in sealed.into_iter().filter(|sequence| *sequence > through) {
            count += 1;
            bytes = bytes.saturating_add(
                std::fs::metadata(self.sealed_path(sequence))
                    .map(|metadata| metadata.len())
                    .unwrap_or(0),
            );
        }
        (count, bytes)
    }

    /// The archiver durably holds every sealed segment named <= `sequence`
    /// (bytes and directory entries); local truncation may delete them.
    /// Refused once the archiver failed on this handle: a later "successful"
    /// step proves nothing about the bytes the failure may have dropped.
    pub fn mark_archived_through(&self, sequence: u64) -> Result<()> {
        if let Some(failure) = self.archive_health.failure() {
            return Err(PageError::ArchiveFailed {
                site: failure.site,
                detail: failure.error,
            });
        }
        if sequence <= self.archived_through() {
            return Ok(());
        }
        // Persist first: a reopened handle trusts this watermark.
        let path = archive_confirmed_path(&self.path);
        let tmp = {
            let mut os = path.as_os_str().to_os_string();
            os.push(".tmp");
            PathBuf::from(os)
        };
        let persist = || -> std::io::Result<()> {
            crate::test_faults::io_fault("wal_archive.confirm", &path)?;
            let mut file = File::create(&tmp)?;
            file.write_all(sequence.to_string().as_bytes())?;
            if self.fsync {
                file.sync_all()?;
            }
            drop(file);
            std::fs::rename(&tmp, &path)?;
            if self.fsync {
                if let Some(parent) = path.parent().filter(|p| !p.as_os_str().is_empty()) {
                    File::open(parent)?.sync_all()?;
                }
            }
            Ok(())
        };
        if let Err(error) = persist() {
            let _ = std::fs::remove_file(&tmp);
            let failure = self.record_archive_failure("wal_archive.confirm", &path, &error);
            return Err(PageError::ArchiveFailed {
                site: failure.site,
                detail: failure.error,
            });
        }
        self.archived_through.fetch_max(sequence, Ordering::AcqRel);
        Ok(())
    }

    /// The archive directory this handle last archived to.
    pub fn archive_destination(&self) -> Option<PathBuf> {
        self.archive_destination.lock().clone()
    }

    pub fn set_archive_destination(&self, destination: &Path) {
        *self.archive_destination.lock() = Some(destination.to_path_buf());
    }

    /// When this handle last verified its archive's confirmed prefix.
    pub fn archive_verified_at(&self) -> Option<Instant> {
        *self.archive_verified_at.lock()
    }

    pub fn set_archive_verified_now(&self) {
        *self.archive_verified_at.lock() = Some(Instant::now());
    }

    /// The page-log archiver's health for this handle.
    pub fn archive_health(&self) -> &std::sync::Arc<crate::health::ArchiveHealth> {
        &self.archive_health
    }

    /// Record a page-log archiver failure (first one wins).
    pub fn record_archive_failure(
        &self,
        site: &str,
        path: &Path,
        error: &dyn std::fmt::Display,
    ) -> crate::health::WriteFailure {
        self.archive_health.record_failure(
            "page_log",
            site,
            &format!("{}: {error}", path.display()),
        )
    }

    /// Total log bytes: every sealed segment plus the active file.
    pub fn size_bytes(&self) -> u64 {
        self.sealed_bytes
            .load(Ordering::Acquire)
            .saturating_add(self.end_offset.load(Ordering::Acquire))
    }
}

/// Decode records from one WAL file sequentially, feeding `scan` and
/// `expected_lsn` across calls so LSN continuity spans segment files.
/// Returns the byte length of the valid prefix of THIS file and its first LSN.
fn scan_wal_file<F>(
    file: &mut File,
    path: &Path,
    max_body_bytes: usize,
    expected_lsn: &mut Option<Lsn>,
    scan: &mut WalScanReport,
    visit: &mut F,
) -> Result<(u64, Option<Lsn>)>
where
    F: FnMut(WalRecordView<'_>) -> Result<()>,
{
    file.seek(SeekFrom::Start(0))
        .map_err(|error| PageError::io(path, error))?;
    let file_bytes = file
        .metadata()
        .map_err(|error| PageError::io(path, error))?
        .len();
    let mut valid_bytes = 0u64;
    let mut first_lsn = None;
    let mut header = [0_u8; RECORD_HEADER_BYTES];
    let mut body = Vec::new();

    while file_bytes.saturating_sub(valid_bytes) >= RECORD_HEADER_BYTES as u64 {
        file.read_exact(&mut header)
            .map_err(|error| PageError::io(path, error))?;
        if header[0..4] != RECORD_MAGIC || header[13..16] != [0, 0, 0] {
            break;
        }
        let lsn = u64::from_le_bytes(header[4..12].try_into().unwrap());
        let Some(kind) = RecordKind::from_u8(header[12]) else {
            break;
        };
        let body_len = u32::from_le_bytes(header[16..20].try_into().unwrap()) as usize;
        let checksum = u32::from_le_bytes(header[20..24].try_into().unwrap());
        let Some(record_bytes) = RECORD_HEADER_BYTES.checked_add(body_len) else {
            break;
        };
        if body_len < RECORD_FIXED_BODY_BYTES
            || body_len > max_body_bytes
            || record_bytes as u64 > file_bytes.saturating_sub(valid_bytes)
            || lsn == u64::MAX
            || expected_lsn.is_some_and(|expected| lsn != expected)
        {
            break;
        }

        body.resize(body_len, 0);
        file.read_exact(&mut body)
            .map_err(|error| PageError::io(path, error))?;
        let mut hasher = crc32fast::Hasher::new();
        hasher.update(&header[..RECORD_HEADER_BYTES - 4]);
        hasher.update(&body);
        if hasher.finalize() != checksum {
            break;
        }

        visit(WalRecordView {
            lsn,
            kind,
            page_id: u64::from_le_bytes(body[0..8].try_into().unwrap()),
            transaction: u64::from_le_bytes(body[8..16].try_into().unwrap()),
            payload: &mut body[RECORD_FIXED_BODY_BYTES..],
        })?;
        first_lsn.get_or_insert(lsn);
        scan.first_lsn.get_or_insert(lsn);
        scan.records = scan.records.saturating_add(1);
        scan.valid_bytes = scan.valid_bytes.saturating_add(record_bytes as u64);
        scan.peak_record_bytes = scan.peak_record_bytes.max(record_bytes as u64);
        scan.last_lsn = Some(lsn);
        valid_bytes = valid_bytes.saturating_add(record_bytes as u64);
        *expected_lsn = Some(lsn + 1);
    }
    Ok((valid_bytes, first_lsn))
}

/// File holding the highest sealed segment confirmed archived.
pub fn archive_confirmed_path(path: &Path) -> PathBuf {
    let mut os = path.as_os_str().to_os_string();
    os.push("-archive-confirmed");
    PathBuf::from(os)
}

fn read_archive_confirmed(path: &Path) -> u64 {
    std::fs::read_to_string(archive_confirmed_path(path))
        .ok()
        .and_then(|text| text.trim().parse().ok())
        .unwrap_or(0)
}

/// What [`verify_archived_segments`] read back.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct ArchivedChainReport {
    /// Segments verified, ascending by name.
    pub segments: u64,
    pub records: u64,
    pub first_lsn: Option<Lsn>,
    pub last_lsn: Option<Lsn>,
    /// Name of the last verified segment.
    pub through: u64,
}

/// Read back every sealed segment `store.wal.<n>` in an archive directory
/// with `n <= through`: every record must decode with a valid checksum, no
/// segment may end in a partial record, and LSNs must run without a gap
/// from one segment into the next. The segment named `through` must be
/// present (it is the confirmed end). `through == 0` verifies nothing.
pub fn verify_archived_segments(dir: &Path, through: u64) -> Result<ArchivedChainReport> {
    let mut report = ArchivedChainReport::default();
    if through == 0 {
        return Ok(report);
    }
    let mut names = Vec::new();
    for entry in std::fs::read_dir(dir).map_err(|e| PageError::io(dir, e))? {
        let entry = entry.map_err(|e| PageError::io(dir, e))?;
        let name = entry.file_name();
        let Some(sequence) = name
            .to_str()
            .and_then(|name| name.strip_prefix("store.wal."))
            .and_then(|suffix| suffix.parse::<u64>().ok())
        else {
            continue;
        };
        if sequence <= through {
            names.push(sequence);
        }
    }
    names.sort_unstable();
    if names.last() != Some(&through) {
        return Err(PageError::WalCorruption {
            path: dir.join(format!("store.wal.{through}")),
            lsn: through,
            reason: "the confirmed segment is missing from the archive".into(),
        });
    }
    let mut expected_lsn = None;
    let mut scan = WalScanReport::default();
    for sequence in names {
        let path = dir.join(format!("store.wal.{sequence}"));
        let mut file = File::open(&path).map_err(|e| PageError::io(&path, e))?;
        let (valid, first) = scan_wal_file(
            &mut file,
            &path,
            MAX_WAL_RECORD_BYTES - RECORD_HEADER_BYTES,
            &mut expected_lsn,
            &mut scan,
            &mut |_| Ok(()),
        )?;
        let len = file.metadata().map_err(|e| PageError::io(&path, e))?.len();
        if valid != len {
            return Err(PageError::WalCorruption {
                path,
                lsn: scan.last_lsn.unwrap_or(0),
                reason: format!(
                    "archived segment holds {len} bytes but only {valid} decode (bad checksum, \
                     torn record or an LSN gap from the previous segment)"
                ),
            });
        }
        report.first_lsn = report.first_lsn.or(first);
        report.segments += 1;
        report.through = sequence;
    }
    report.records = scan.records;
    report.last_lsn = scan.last_lsn;
    Ok(report)
}

/// File whose presence keeps archive retention on across reopens.
pub fn archive_retention_marker(path: &Path) -> PathBuf {
    let mut os = path.as_os_str().to_os_string();
    os.push("-archive-retention");
    PathBuf::from(os)
}

/// Sealed segments on disk next to `path`, ascending, with their total size.
fn discover_sealed_segments(path: &Path) -> Result<(Vec<u64>, u64)> {
    discover_sealed_segments_limited(path, None)
}

fn discover_sealed_segments_limited(
    path: &Path,
    limits: Option<&ReadOnlyScanLimits>,
) -> Result<(Vec<u64>, u64)> {
    let Some(parent) = path
        .parent()
        .filter(|parent| !parent.as_os_str().is_empty())
    else {
        return Ok((Vec::new(), 0));
    };
    let Some(base_name) = path.file_name().and_then(|name| name.to_str()) else {
        return Ok((Vec::new(), 0));
    };
    let mut sealed = Vec::new();
    let mut total = 0u64;
    for entry in std::fs::read_dir(parent).map_err(|e| PageError::io(parent, e))? {
        if let Some(limits) = limits {
            limits.check((sealed.len() as u64 + 1).saturating_mul(512))?;
        }
        let entry = entry.map_err(|e| PageError::io(parent, e))?;
        let name = entry.file_name();
        let Some(name) = name.to_str() else { continue };
        let Some(suffix) = name
            .strip_prefix(base_name)
            .and_then(|rest| rest.strip_prefix('.'))
        else {
            continue;
        };
        let Ok(sequence) = suffix.parse::<u64>() else {
            continue;
        };
        total = total.saturating_add(
            entry
                .metadata()
                .map_err(|e| PageError::io(entry.path(), e))?
                .len(),
        );
        sealed.push(sequence);
    }
    sealed.sort_unstable();
    Ok((sealed, total))
}

/// Transaction outcomes recorded in the log.
///
/// Read separately from [`recover`] because the *page* state and the
/// *transaction* state are recovered by different owners: the page store replays
/// images, while the MVCC transaction table needs to know which ids committed so
/// a crashed transaction's versions stay invisible. Without this, a restart would
/// have no record that a transaction was unfinished, and visibility would have to
/// guess.
pub fn transaction_outcomes(wal: &Wal) -> Result<Vec<(u64, crate::mvcc::TxStatus)>> {
    let mut outcomes = Vec::new();
    wal.scan_records(
        MAX_WAL_RECORD_BYTES - RECORD_HEADER_BYTES,
        false,
        |record| {
            match record.kind {
                RecordKind::Commit => {
                    outcomes.push((record.transaction, crate::mvcc::TxStatus::Committed))
                }
                RecordKind::Abort => {
                    outcomes.push((record.transaction, crate::mvcc::TxStatus::Aborted))
                }
                _ => {}
            }
            Ok(())
        },
    )?;
    Ok(outcomes)
}

/// How the page-log chain relates to the page file's horizon `H`, decided
/// before recovery changes any file.
enum ResetShape {
    /// The chain is empty, or reaches at least the checkpoint record `H - 1`.
    Normal,
    /// Sealed segments that all predate `H - 1`, next to an EMPTY active file:
    /// exactly what a log reset interrupted between truncating the active file
    /// and deleting the segments leaves (the order `Wal::reset` used before
    /// GAP-2 was fixed). Every record is reflected in the page file. Finish
    /// the reset.
    InterruptedReset,
    /// Such stale sealed segments, then an active file whose first record is
    /// `H`: an interrupted reset as above, after which an older engine kept
    /// committing into the active file. Those commits are real. Drop the stale
    /// segments and replay the active file; continuity-checking the whole
    /// chain would discard it as a torn tail.
    StaleSealedBeforeActive,
    /// Ends before `H - 1` in any other shape: corruption, or a lost log.
    /// Refuse, and leave every file as it is.
    Corrupt(String),
}

/// Replay a log into a page file.
///
/// Two passes, which is what makes "no uncommitted row is exposed" true rather
/// than hoped for:
///
/// 1. scan forward to learn which transactions committed;
/// 2. scan again applying only page images belonging to those transactions.
///
/// A single pass cannot do this: a page image appears *before* the commit
/// record that blesses it, so a one-pass replay would have to apply images
/// speculatively and undo them, which needs before-images the log does not
/// carry.
pub fn recover(wal: &Wal, store: &crate::manager::PageStore) -> Result<RecoveryReport> {
    recover_with_outcomes(wal, store).map(|(report, _)| report)
}

pub(crate) fn recover_with_outcomes(
    wal: &Wal,
    store: &crate::manager::PageStore,
) -> Result<(RecoveryReport, RecoveredOutcomes)> {
    let started = Instant::now();
    let wal_bytes_scanned = wal.size_bytes();
    let max_body_bytes = RECORD_FIXED_BODY_BYTES.saturating_add(store.page_size() as usize);
    let mut outcomes = RecoveredOutcomes::default();
    let mut terminal_outcome_records = 0_u64;
    let mut max_record_transaction = 0_u64;
    let horizon = store.checkpoint_lsn();
    // Before anything is truncated or replayed: is this the remains of an
    // interrupted log reset (GAP-2 in `docs/recovery-semantics.md`)?
    let mut stale_segments_discarded = 0_u64;
    match wal.reset_shape(max_body_bytes, horizon)? {
        ResetShape::Normal => {}
        ResetShape::InterruptedReset => {
            let segments = wal.sealed.lock().len() as u64;
            // Every record is below the horizon and already in the page file.
            // Replay nothing; finish the reset before anything is appended.
            wal.reset()?;
            let free_pages_detached = store.detach_stale_free_list_for_recovery()?;
            wal.redo_lsn.store(horizon, Ordering::Release);
            return Ok((
                RecoveryReport {
                    wal_bytes_scanned,
                    scan_passes: 0,
                    stale_segments_discarded: segments,
                    free_pages_detached,
                    redo_lsn: horizon,
                    duration_nanos: u64::try_from(started.elapsed().as_nanos()).unwrap_or(u64::MAX),
                    ..Default::default()
                },
                RecoveredOutcomes::default(),
            ));
        }
        ResetShape::StaleSealedBeforeActive => {
            stale_segments_discarded = wal.drop_stale_sealed_segments()?;
        }
        ResetShape::Corrupt(reason) => {
            return Err(PageError::WalCorruption {
                path: wal.path().to_path_buf(),
                lsn: horizon,
                reason,
            });
        }
    }
    // Redo point of the last checkpoint record below the horizon: normally
    // the record at `H - 1` that published `H`.
    let mut checkpoint_redo_below_horizon = None;
    let check = |scan: &WalScanReport| check_chain_start(wal.path(), horizon, scan.first_lsn);
    let first = wal.scan_records_checked(max_body_bytes, true, check, |record| {
        // Checkpoint records reuse the transaction field for a redo LSN, so
        // they are excluded; transaction 0 marks structural images. Page
        // images matter here: a crashed transaction that evicted pages left
        // its id only on them, and that id must never be reissued.
        if record.kind != RecordKind::Checkpoint {
            max_record_transaction = max_record_transaction.max(record.transaction);
        }
        match record.kind {
            RecordKind::Commit => {
                if record.transaction == u64::MAX {
                    return Err(PageError::WalCorruption {
                        path: wal.path().to_path_buf(),
                        lsn: record.lsn,
                        reason: "transaction ID cannot advance beyond u64::MAX".to_string(),
                    });
                }
                let inserted = outcomes.push(record.transaction, TxStatus::Committed);
                debug_assert!(inserted);
                terminal_outcome_records = terminal_outcome_records.saturating_add(1);
            }
            RecordKind::Abort => {
                if record.transaction == u64::MAX {
                    return Err(PageError::WalCorruption {
                        path: wal.path().to_path_buf(),
                        lsn: record.lsn,
                        reason: "transaction ID cannot advance beyond u64::MAX".to_string(),
                    });
                }
                let inserted = outcomes.push(record.transaction, TxStatus::Aborted);
                debug_assert!(inserted);
                terminal_outcome_records = terminal_outcome_records.saturating_add(1);
            }
            RecordKind::Checkpoint => {
                if record.lsn < horizon {
                    checkpoint_redo_below_horizon = Some(record.transaction);
                }
            }
            RecordKind::PageImage => {}
        }
        Ok(())
    })?;
    crate::test_faults::crash_point("page_recovery.after_scan");
    let peak_transaction_outcome_bytes = outcomes.allocated_bytes();
    if let Some(xid) = outcomes.normalize() {
        return Err(PageError::WalCorruption {
            path: wal.path().to_path_buf(),
            lsn: first.last_lsn.unwrap_or(0),
            reason: format!("transaction {xid} has contradictory commit and abort records"),
        });
    }
    // The redo point. The page file's checkpoint horizon `H` (superblock
    // `checkpoint_lsn`) is published only once every page dirtied before it
    // is durable, so nothing below `H` ever needs replay. The checkpoint
    // record that published `H` (the last one below it, normally at `H - 1`)
    // names a redo point at or below `H`; records between that point and
    // `H` are replayed, so a checkpoint whose publication was not fenced
    // against appends still recovers exactly.
    //
    // Without such a record, `H` itself is exact. That is the case for a
    // rolled-forward restore whose base was taken after its log was reset
    // (later records in the stream describe the source's page files, not
    // these), and for a log that starts at `H`. The code used to replay those
    // from LSN 0, and a stale chain of records below `H` (GAP-2) over newer
    // pages. `H = 0` (a new store, or one written before horizons existed)
    // replays the whole chain.
    let redo_lsn = checkpoint_redo_below_horizon.map_or(horizon, |redo: Lsn| redo.min(horizon));
    let mut report = RecoveryReport {
        records_scanned: first.records,
        truncated_bytes: first.truncated_bytes,
        wal_bytes_scanned,
        scan_passes: 2,
        peak_record_bytes: first.peak_record_bytes,
        transaction_outcomes: outcomes.len() as u64,
        terminal_outcome_records,
        peak_transaction_outcome_bytes,
        committed_transactions: outcomes.committed_count() as u64,
        max_record_transaction,
        stale_segments_discarded,
        redo_lsn,
        end_lsn: first.last_lsn.unwrap_or(0),
        ..Default::default()
    };

    // Pass 2: apply committed page images at or after the redo point.
    //
    // Replay is idempotent because records are full page images: applying one
    // twice leaves the same bytes. That is what lets recovery restart safely
    // after being interrupted.
    let mut free_list_detached = false;
    let second = wal.scan_records(max_body_bytes, false, |record| {
        if record.kind != RecordKind::PageImage {
            return Ok(());
        }
        if record.lsn < redo_lsn {
            return Ok(());
        }
        // Transaction 0 means "not part of a transaction" — structural writes
        // such as a new root, which are safe to replay unconditionally.
        if record.transaction != 0
            && outcomes.status(record.transaction) != Some(TxStatus::Committed)
        {
            report.uncommitted_skipped = report.uncommitted_skipped.saturating_add(1);
            return Ok(());
        }
        if record.payload.len() != store.page_size() as usize {
            return Err(PageError::ShortRead {
                page_id: record.page_id,
                got: record.payload.len(),
                want: store.page_size() as usize,
            });
        }
        if !free_list_detached {
            report.free_pages_detached = store.detach_free_list_for_recovery()?;
            free_list_detached = true;
        }
        let page_count = record
            .page_id
            .checked_add(1)
            .ok_or_else(|| PageError::WalCorruption {
                path: wal.path().to_path_buf(),
                lsn: record.lsn,
                reason: "page ID cannot be represented as a page count".to_string(),
            })?;
        store.reserve(page_count)?;
        store.write_page(record.page_id, record.payload)?;
        report.pages_replayed = report.pages_replayed.saturating_add(1);
        crate::test_faults::crash_point_with_locked_wal("page_recovery.after_page_replay", wal);
        Ok(())
    })?;
    if second.truncated_bytes != 0
        || second.records != first.records
        || second.last_lsn != first.last_lsn
    {
        return Err(PageError::WalCorruption {
            path: wal.path().to_path_buf(),
            lsn: first.last_lsn.unwrap_or(0),
            reason: "WAL changed between bounded recovery passes".to_string(),
        });
    }
    report.peak_record_bytes = report.peak_record_bytes.max(second.peak_record_bytes);
    if !free_list_detached {
        // Nothing was replayed, but uncommitted work since the last
        // checkpoint may still have allocated the published head.
        report.free_pages_detached = store.detach_stale_free_list_for_recovery()?;
    }

    store.flush()?;
    crate::test_faults::crash_point("page_recovery.after_flush");
    wal.redo_lsn.store(redo_lsn, Ordering::Release);
    report.duration_nanos = u64::try_from(started.elapsed().as_nanos()).unwrap_or(u64::MAX);
    Ok((report, outcomes))
}

/// Refuse a page log whose first record lies above the page file's checkpoint
/// horizon `horizon` (the superblock's `checkpoint_lsn`).
///
/// `Checkpointer::finish_checkpoint` publishes the horizon as the LSN right
/// after its checkpoint record, once every page image below it is in the page
/// file. A record at or above the horizon is appended only after that
/// publication, and `Wal::reset` deletes only records below the horizon of
/// the checkpoint that precedes it. So a non-empty chain always starts at or
/// below the horizon: exactly at it after a reset, below it when the reset did
/// not run (backup pin, unfrozen commits, a crash before the reset) or when
/// archive retention kept sealed segments. A chain that starts above it has
/// lost records the page file does not reflect, and replaying the rest would
/// build pages on a missing prefix. A horizon of 0 (a new store, or one
/// written before horizons existed) proves nothing and is not checked.
fn check_chain_start(path: &Path, horizon: Lsn, first_lsn: Option<Lsn>) -> Result<()> {
    match first_lsn {
        Some(first) if horizon > 0 && first > horizon => Err(PageError::WalCorruption {
            path: path.to_path_buf(),
            lsn: first,
            reason: format!(
                "the page log starts at LSN {first} but the page file's checkpoint horizon is \
                 {horizon}: records {horizon}..{} are missing",
                first - 1
            ),
        }),
        _ => Ok(()),
    }
}

fn unix_time_millis() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|duration| u64::try_from(duration.as_millis()).unwrap_or(u64::MAX))
        .unwrap_or(0)
}

/// Ties the buffer pool, page store, and WAL together so write-ahead ordering
/// cannot be violated by forgetting to call something.
#[derive(Debug)]
pub struct Checkpointer {
    pool: std::sync::Arc<crate::pool::BufferPool>,
    wal: std::sync::Arc<Wal>,
}

impl Checkpointer {
    pub fn new(pool: std::sync::Arc<crate::pool::BufferPool>, wal: std::sync::Arc<Wal>) -> Self {
        Self { pool, wal }
    }

    /// Log a page's after-image, then mark it dirty in the pool.
    ///
    /// The order is the invariant: the log record exists before the page is
    /// eligible for writeback, so no dirty page can reach disk ahead of its log
    /// record.
    pub fn log_and_write(&self, page_id: PageId, transaction: u64, image: &[u8]) -> Result<Lsn> {
        let lsn = self.wal.log_page_image(page_id, transaction, image)?;
        let mut guard = self.pool.get_mut(page_id)?;
        guard.bytes_mut().copy_from_slice(image);
        Ok(lsn)
    }

    /// Flush dirty pages and record a durable redo point.
    ///
    /// Order matters and is the entire content of the guarantee:
    ///
    /// 1. note where the log currently ends — this becomes the redo point;
    /// 2. sync the log, so every page about to be written is already logged;
    /// 3. write dirty pages and fsync the page file;
    /// 4. only now record the checkpoint.
    ///
    /// Doing 4 before 3 would let a crash leave a checkpoint claiming pages are
    /// durable when they are not, and recovery would skip exactly the records
    /// needed to fix them.
    ///
    /// # Fence
    ///
    /// The caller must exclude every page writer (the store's writer gate)
    /// from step 1 until this returns, so every page logged before the
    /// published horizon is flushed. A record appended by another thread
    /// between the checkpoint record and the publication (a page written
    /// back through the barrier by a thread that does not hold the gate) lands below the horizon but
    /// above this checkpoint's redo point, and recovery replays it: the redo
    /// point comes from the checkpoint record, not from the horizon.
    pub fn checkpoint(&self, root_page: PageId) -> Result<CheckpointReport> {
        let redo_lsn = self.wal.next_lsn();
        self.wal.sync()?;
        crate::test_faults::crash_point("checkpoint.after_wal_sync");
        let flushed = self.pool.flush_all()?;
        self.pool.store().flush()?;
        crate::test_faults::crash_point("checkpoint.after_page_flush");
        self.finish_checkpoint(root_page, redo_lsn, flushed, false)
    }

    /// Checkpoint, then discard the now-redundant log prefix.
    ///
    /// This is what bounds the WAL. Without it the log grows without limit and
    /// recovery time grows with total writes rather than with the post-checkpoint
    /// suffix — which is the gate Phase 3 is judged by.
    pub fn checkpoint_and_truncate(&self, root_page: PageId) -> Result<CheckpointReport> {
        let redo_lsn = self.wal.next_lsn();
        self.wal.sync()?;
        crate::test_faults::crash_point("checkpoint.after_wal_sync");
        let flushed = self.pool.flush_all()?;
        self.pool.store().flush()?;
        crate::test_faults::crash_point("checkpoint.after_page_flush");
        self.finish_checkpoint(root_page, redo_lsn, flushed, true)
    }

    /// Publish a checkpoint after a caller has independently proven every dirty
    /// page durable.
    ///
    /// This is the terminal operation used by the bounded checkpoint state
    /// machine. It deliberately does not inspect or flush the buffer pool. The
    /// caller must hold its writer fence and observe zero dirty pages after the
    /// final page-file sync. Keeping publication separate is what allows a large
    /// dirty set to be drained across many governed steps instead of one
    /// unbounded `flush_all` call.
    pub(crate) fn finish_checkpoint(
        &self,
        root_page: PageId,
        redo_lsn: Lsn,
        pages_flushed: u64,
        truncate: bool,
    ) -> Result<CheckpointReport> {
        self.wal.sync()?;
        self.pool.store().flush()?;
        let wal_bytes_before = self.wal.size_bytes();
        let checkpoint_lsn = self.wal.checkpoint(redo_lsn, root_page)?;
        // Persist the new LSN horizon before any reset removes the records
        // that establish it. Otherwise a crash in the reset/publish gap can
        // reopen an empty WAL at an older floor and reuse LSNs or segment
        // names from the discarded generation.
        self.pool
            .store()
            .publish_root(root_page, self.wal.next_lsn())?;
        crate::test_faults::crash_point("checkpoint.after_publish");
        let wal_truncated = if truncate {
            // Safe only under the caller contract above: every page represented
            // by the discarded log is already durable.
            let truncated = self.wal.reset()?;
            crate::test_faults::crash_point("checkpoint.after_wal_reset");
            truncated
        } else {
            false
        };
        Ok(CheckpointReport {
            redo_lsn,
            checkpoint_lsn,
            pages_flushed,
            wal_bytes_before,
            wal_truncated,
        })
    }

    pub fn wal(&self) -> &Wal {
        &self.wal
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CheckpointReport {
    pub redo_lsn: Lsn,
    pub checkpoint_lsn: Lsn,
    pub pages_flushed: u64,
    pub wal_bytes_before: u64,
    pub wal_truncated: bool,
}

// ---------------------------------------------------------------------------
// Read-only log analysis, for `crate::verify_store`.
//
// Nothing below opens a file for writing, truncates, renames or deletes. The
// functions reproduce what `recover_with_outcomes` would decide from the same
// files, so the verifier can examine the post-recovery state of a store
// without running recovery (which writes the page file and truncates the log).

/// How the page-log chain relates to the page file's checkpoint horizon `H`
/// (the superblock's `checkpoint_lsn`). This is the same classification the
/// crash-ordered log-reset fix makes at open (`ResetShape` there), computed
/// from the files alone.
#[derive(Clone, Debug, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(tag = "shape", rename_all = "snake_case")]
pub enum LogResetShape {
    /// The chain is empty, or reaches at least the checkpoint record `H - 1`.
    Normal,
    /// Sealed segments whose records all predate `H - 1`, next to an empty
    /// active file: a log reset interrupted between truncating the active
    /// file and deleting the segments. The page file is newer than every
    /// record. An engine without the reset fix replays these records over
    /// newer pages at the next open.
    InterruptedReset {
        stale_segments: u64,
        stale_last_lsn: Lsn,
        /// Committed page images an engine without the fix would replay.
        stale_images_replayed_by_unfixed_open: u64,
    },
    /// Such stale sealed segments, then an active file that starts exactly at
    /// `H`: an interrupted reset after which an engine without the fix opened
    /// the store (replaying the stale chain over newer pages) and kept
    /// committing. Those later commits are real; an engine without the fix
    /// discards them as a torn tail at its next open.
    StaleSealedBeforeActive {
        stale_segments: u64,
        stale_last_lsn: Lsn,
        active_records: u64,
    },
    /// The chain ends before `H - 1` in any other shape: a lost or damaged
    /// log.
    EndsBeforeHorizon { reason: String },
}

/// Where the newest replayable image of one page lives in the log.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct LoggedImage {
    /// Index into [`ReadOnlyLog::files`].
    pub(crate) file: usize,
    /// Byte offset of the page payload within that file.
    pub(crate) offset: u64,
    pub(crate) lsn: Lsn,
}

/// Read-only view of what recovery would do with the log.
pub(crate) struct ReadOnlyLog {
    /// Sealed segments ascending, then the active file (when it exists).
    pub(crate) files: Vec<(PathBuf, File)>,
    pub(crate) sealed_segments: u64,
    pub(crate) sealed_bytes: u64,
    pub(crate) active_bytes: u64,
    pub(crate) shape: LogResetShape,
    /// Which files recovery would replay: `full_chain`, `active_only` or
    /// `none`.
    pub(crate) replay_scope: &'static str,
    pub(crate) records: u64,
    pub(crate) first_lsn: Option<Lsn>,
    pub(crate) last_lsn: Option<Lsn>,
    pub(crate) torn_tail_bytes: u64,
    pub(crate) checkpoint_records: u64,
    pub(crate) redo_lsn: Lsn,
    /// Terminal outcomes in the replayed scope, ascending by xid.
    pub(crate) outcomes: Vec<(u64, TxStatus)>,
    pub(crate) committed_transactions: u64,
    pub(crate) images_replayed: u64,
    pub(crate) uncommitted_images_skipped: u64,
    /// Newest replayable image per page.
    pub(crate) images: rustc_hash::FxHashMap<PageId, LoggedImage>,
    pub(crate) max_replayed_page: Option<PageId>,
    /// Replay grows the page count one image at a time, and on a monolithic
    /// file each growth is a `set_len` that also TRUNCATES a longer file.
    /// Pages at or above this id that no replayed image covers read as zeros
    /// after a real recovery, whatever the file holds now.
    pub(crate) truncated_from: Option<PageId>,
    /// Why a real open would refuse this log, if it would.
    pub(crate) corruption: Option<String>,
}

impl ReadOnlyLog {
    /// Status of `xid` according to the replayed log, if it holds one.
    pub(crate) fn outcome(&self, xid: u64) -> Option<TxStatus> {
        self.outcomes
            .binary_search_by_key(&xid, |(candidate, _)| *candidate)
            .ok()
            .map(|index| self.outcomes[index].1)
    }

    /// Read one logged page image into `buffer` (exactly one page).
    pub(crate) fn read_image(&self, image: LoggedImage, buffer: &mut [u8]) -> Result<()> {
        let (path, file) = &self.files[image.file];
        let got = crate::pio::read_at(file, buffer, image.offset)
            .map_err(|error| PageError::io(path, error))?;
        if got != buffer.len() {
            return Err(PageError::WalCorruption {
                path: path.clone(),
                lsn: image.lsn,
                reason: "a logged page image is shorter than a page".to_string(),
            });
        }
        Ok(())
    }
}

fn sealed_segment_path(path: &Path, sequence: u64) -> PathBuf {
    let mut os = path.as_os_str().to_os_string();
    os.push(format!(".{sequence}"));
    PathBuf::from(os)
}

/// One record seen by a read-only scan, with its payload offset.
struct ScannedRecord {
    lsn: Lsn,
    kind: RecordKind,
    page_id: PageId,
    transaction: u64,
    payload_offset: u64,
    payload_len: usize,
}

/// Setup scans precede the verifier's page walks; they must obey limits too.
pub(crate) struct ReadOnlyScanLimits {
    pub(crate) max_state_bytes: u64,
    pub(crate) deadline: Option<std::time::Instant>,
    stopped: std::cell::RefCell<Option<String>>,
}

impl ReadOnlyScanLimits {
    pub(crate) fn new(max_state_bytes: u64, deadline: Option<std::time::Instant>) -> Self {
        Self {
            max_state_bytes,
            deadline,
            stopped: Default::default(),
        }
    }

    pub(crate) fn check(&self, estimated_bytes: u64) -> Result<()> {
        let mut stopped = self.stopped.borrow_mut();
        if stopped.is_none() {
            if self
                .deadline
                .is_some_and(|deadline| std::time::Instant::now() >= deadline)
            {
                *stopped = Some("time limit during read-only setup".to_string());
            } else if estimated_bytes > self.max_state_bytes {
                *stopped = Some("memory limit during read-only setup".to_string());
            }
        }
        match stopped.as_ref() {
            Some(reason) => Err(PageError::InvalidMaintenanceLimits {
                reason: format!("read-only verification limit: {reason}"),
            }),
            None => Ok(()),
        }
    }
}

/// Scan one file from its start. `expected` carries LSN continuity across
/// files exactly as `Wal::scan_records` does. Returns the decoded byte count.
fn scan_file_read_only(
    file: &mut File,
    path: &Path,
    max_body_bytes: usize,
    expected: &mut Option<Lsn>,
    scan: &mut WalScanReport,
    visit: &mut dyn FnMut(&ScannedRecord),
    limits: &ReadOnlyScanLimits,
) -> Result<u64> {
    let mut offset = 0_u64;
    let mut adapter = |record: WalRecordView<'_>| -> Result<()> {
        limits.check(0)?;
        let payload_len = record.payload.len();
        visit(&ScannedRecord {
            lsn: record.lsn,
            kind: record.kind,
            page_id: record.page_id,
            transaction: record.transaction,
            payload_offset: offset + (RECORD_HEADER_BYTES + RECORD_FIXED_BODY_BYTES) as u64,
            payload_len,
        });
        limits.check(0)?;
        offset += (RECORD_HEADER_BYTES + RECORD_FIXED_BODY_BYTES + payload_len) as u64;
        Ok(())
    };
    let (valid, _) = scan_wal_file(file, path, max_body_bytes, expected, scan, &mut adapter)?;
    Ok(valid)
}

/// Analyse a store's page log without modifying it. `open` must open a file
/// read-only; the verifier passes its own read-only opener.
pub(crate) fn analyze_log_read_only(
    path: &Path,
    page_size: u32,
    horizon: Lsn,
    page_count: u64,
    monolithic_file_pages: Option<u64>,
    open: &dyn Fn(&Path) -> std::io::Result<File>,
    limits: &ReadOnlyScanLimits,
) -> Result<ReadOnlyLog> {
    limits.check(0)?;
    let max_body_bytes = RECORD_FIXED_BODY_BYTES.saturating_add(page_size as usize);
    let (sealed, sealed_bytes) = discover_sealed_segments_limited(path, Some(limits))?;
    let mut files: Vec<(PathBuf, File)> = Vec::with_capacity(sealed.len() + 1);
    for sequence in &sealed {
        limits.check((files.len() as u64 + 1).saturating_mul(512))?;
        let segment = sealed_segment_path(path, *sequence);
        let file = open(&segment).map_err(|error| PageError::io(&segment, error))?;
        files.push((segment, file));
    }
    let active_index = match open(path) {
        Ok(file) => {
            files.push((path.to_path_buf(), file));
            Some(files.len() - 1)
        }
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => None,
        Err(error) => return Err(PageError::io(path, error)),
    };
    let active_bytes = match active_index {
        Some(index) => files[index]
            .1
            .metadata()
            .map_err(|error| PageError::io(path, error))?
            .len(),
        None => 0,
    };
    let sealed_count = sealed.len();

    // The reset shape, from independent per-file scans (no continuity), as
    // the reset fix computes it before recovery touches anything.
    let mut ignore = |_: &ScannedRecord| {};
    let (active_first, active_last, active_records) = match active_index {
        Some(index) => {
            let (file_path, file) = &mut files[index];
            let mut scan = WalScanReport::default();
            let mut first = None;
            let mut note_first = |record: &ScannedRecord| {
                first.get_or_insert(record.lsn);
            };
            scan_file_read_only(
                file,
                file_path,
                max_body_bytes,
                &mut None,
                &mut scan,
                &mut note_first,
                limits,
            )?;
            (first, scan.last_lsn, scan.records)
        }
        None => (None, None, 0),
    };
    let shape = if horizon == 0 {
        LogResetShape::Normal
    } else if sealed_count == 0 {
        match active_last {
            Some(last) if last.saturating_add(1) < horizon => LogResetShape::EndsBeforeHorizon {
                reason: format!(
                    "the page log ends at LSN {last}, before the checkpoint record {} of the \
                     page file's horizon {horizon}",
                    horizon - 1
                ),
            },
            _ => LogResetShape::Normal,
        }
    } else {
        let (file_path, file) = &mut files[sealed_count - 1];
        let mut scan = WalScanReport::default();
        scan_file_read_only(
            file,
            file_path,
            max_body_bytes,
            &mut None,
            &mut scan,
            &mut ignore,
            limits,
        )?;
        match scan.last_lsn {
            // An undecodable sealed segment is corruption the full scan reports.
            None => LogResetShape::Normal,
            Some(sealed_last) => {
                let chain_last = match (active_first, active_last) {
                    (Some(first), Some(last)) if first == sealed_last + 1 => last,
                    _ => sealed_last,
                };
                if chain_last.saturating_add(1) >= horizon {
                    LogResetShape::Normal
                } else if active_bytes == 0 {
                    LogResetShape::InterruptedReset {
                        stale_segments: sealed_count as u64,
                        stale_last_lsn: sealed_last,
                        stale_images_replayed_by_unfixed_open: 0,
                    }
                } else if active_first == Some(horizon) {
                    LogResetShape::StaleSealedBeforeActive {
                        stale_segments: sealed_count as u64,
                        stale_last_lsn: sealed_last,
                        active_records,
                    }
                } else {
                    LogResetShape::EndsBeforeHorizon {
                        reason: format!(
                            "the sealed page-log segments end at LSN {sealed_last}, before the \
                             checkpoint record {} of the page file's horizon {horizon}, and the \
                             active file ({active_bytes} bytes) does not start at the horizon \
                             (first LSN {active_first:?})",
                            horizon - 1
                        ),
                    }
                }
            }
        }
    };

    let mut log = ReadOnlyLog {
        files,
        sealed_segments: sealed_count as u64,
        sealed_bytes,
        active_bytes,
        shape: shape.clone(),
        replay_scope: "none",
        records: 0,
        first_lsn: None,
        last_lsn: None,
        torn_tail_bytes: 0,
        checkpoint_records: 0,
        redo_lsn: 0,
        outcomes: Vec::new(),
        committed_transactions: 0,
        images_replayed: 0,
        uncommitted_images_skipped: 0,
        images: rustc_hash::FxHashMap::default(),
        max_replayed_page: None,
        truncated_from: None,
        corruption: None,
    };

    // What an engine WITHOUT the reset fix would replay from a stale chain.
    if let LogResetShape::InterruptedReset { .. } = shape {
        let scope: Vec<usize> = (0..sealed_count).collect();
        let mut probe = ScopeScan {
            page_count,
            file_pages: monolithic_file_pages,
            ..ScopeScan::default()
        };
        if replay_scope(
            &mut log,
            &scope,
            active_index,
            max_body_bytes,
            horizon,
            false,
            &mut probe,
            limits,
        )
        .is_ok()
        {
            log.shape = match shape.clone() {
                LogResetShape::InterruptedReset {
                    stale_segments,
                    stale_last_lsn,
                    ..
                } => LogResetShape::InterruptedReset {
                    stale_segments,
                    stale_last_lsn,
                    stale_images_replayed_by_unfixed_open: probe.images_replayed,
                },
                other => other,
            };
        }
    }

    limits.check(0)?;
    let scope: Vec<usize> = match &shape {
        LogResetShape::Normal => {
            log.replay_scope = "full_chain";
            (0..log.files.len()).collect()
        }
        LogResetShape::StaleSealedBeforeActive { .. } => {
            log.replay_scope = "active_only";
            active_index.into_iter().collect()
        }
        LogResetShape::InterruptedReset { .. } | LogResetShape::EndsBeforeHorizon { .. } => {
            Vec::new()
        }
    };
    if !scope.is_empty() {
        let mut result = ScopeScan {
            page_count,
            file_pages: monolithic_file_pages,
            ..ScopeScan::default()
        };
        match replay_scope(
            &mut log,
            &scope,
            active_index,
            max_body_bytes,
            horizon,
            true,
            &mut result,
            limits,
        ) {
            Ok(()) => {
                log.records = result.records;
                log.first_lsn = result.first_lsn;
                log.last_lsn = result.last_lsn;
                log.torn_tail_bytes = result.torn_tail_bytes;
                log.checkpoint_records = result.checkpoint_records;
                log.redo_lsn = result.redo_lsn;
                log.outcomes = result.outcomes;
                log.committed_transactions = result.committed;
                log.images_replayed = result.images_replayed;
                log.uncommitted_images_skipped = result.uncommitted_skipped;
                log.images = result.images;
                log.max_replayed_page = result.max_page;
                log.truncated_from = result.truncated_from;
            }
            Err(reason) => {
                limits.check(0)?;
                log.corruption = Some(reason);
                log.replay_scope = "none";
            }
        }
    }
    Ok(log)
}

#[derive(Default)]
struct ScopeScan {
    records: u64,
    first_lsn: Option<Lsn>,
    last_lsn: Option<Lsn>,
    torn_tail_bytes: u64,
    checkpoint_records: u64,
    redo_lsn: Lsn,
    outcomes: Vec<(u64, TxStatus)>,
    committed: u64,
    images_replayed: u64,
    uncommitted_skipped: u64,
    images: rustc_hash::FxHashMap<PageId, LoggedImage>,
    max_page: Option<PageId>,
    /// Inputs: the superblock page count and, for a monolithic file, its
    /// length in pages. Output: where replay's growth truncates the file.
    page_count: u64,
    file_pages: Option<u64>,
    truncated_from: Option<PageId>,
}

/// Recovery's two passes over `scope` (indices into `log.files`), read-only.
/// Errors are the reasons a real open would refuse the log.
fn replay_scope(
    log: &mut ReadOnlyLog,
    scope: &[usize],
    active_index: Option<usize>,
    max_body_bytes: usize,
    horizon: Lsn,
    build_map: bool,
    out: &mut ScopeScan,
    limits: &ReadOnlyScanLimits,
) -> std::result::Result<(), String> {
    // Pass 1: outcomes and the last checkpoint record's redo point.
    let mut expected = None;
    let mut scan = WalScanReport::default();
    let files_bytes = log.files.len() as u64 * 512;
    let mut outcomes: Vec<(u64, TxStatus)> = Vec::new();
    let mut checkpoint_redo = 0_u64;
    let mut checkpoints = 0_u64;
    let mut first_lsn = None;
    for &index in scope {
        let (path, file) = &mut log.files[index];
        let length = file.metadata().map_err(|error| error.to_string())?.len();
        let mut visit = |record: &ScannedRecord| {
            if limits
                .check(
                    (outcomes.len() as u64 + 1)
                        .saturating_mul(32)
                        .saturating_add(files_bytes),
                )
                .is_err()
            {
                return;
            }
            first_lsn.get_or_insert(record.lsn);
            match record.kind {
                RecordKind::Commit => outcomes.push((record.transaction, TxStatus::Committed)),
                RecordKind::Abort => outcomes.push((record.transaction, TxStatus::Aborted)),
                RecordKind::Checkpoint => {
                    checkpoint_redo = record.transaction;
                    checkpoints += 1;
                }
                RecordKind::PageImage => {}
            }
        };
        let valid = scan_file_read_only(
            file,
            path,
            max_body_bytes,
            &mut expected,
            &mut scan,
            &mut visit,
            limits,
        )
        .map_err(|error| error.to_string())?;
        if Some(index) == active_index {
            out.torn_tail_bytes = length.saturating_sub(valid);
        } else if valid != length {
            return Err(format!(
                "sealed page-log segment {} holds {length} bytes but only {valid} decode; a real \
                 open refuses this log",
                path.display()
            ));
        }
    }
    outcomes.sort_unstable_by_key(|(xid, _)| *xid);
    for pair in outcomes.windows(2) {
        if pair[0].0 == pair[1].0 && pair[0].1 != pair[1].1 {
            return Err(format!(
                "transaction {} has contradictory commit and abort records; a real open refuses \
                 this log",
                pair[0].0
            ));
        }
    }
    outcomes.dedup_by_key(|(xid, _)| *xid);
    let committed = outcomes
        .iter()
        .filter(|(_, status)| *status == TxStatus::Committed)
        .count() as u64;
    // The redo rule of `recover_with_outcomes`: only a redo point the page
    // file's own horizon vouches for is trusted.
    let redo_lsn = if horizon >= checkpoint_redo {
        checkpoint_redo
    } else {
        0
    };

    // Pass 2: committed (or structural) images at or after the redo point.
    let status_of = |xid: u64| {
        outcomes
            .binary_search_by_key(&xid, |(candidate, _)| *candidate)
            .ok()
            .map(|index| outcomes[index].1)
    };
    let mut expected = None;
    let mut second = WalScanReport::default();
    let mut images: rustc_hash::FxHashMap<PageId, LoggedImage> = Default::default();
    let mut replayed = 0_u64;
    let mut skipped = 0_u64;
    let mut max_page: Option<PageId> = None;
    let mut short_image = None;
    let mut count = out.page_count;
    let mut file_pages = out.file_pages;
    let mut truncated_from = None;
    for &index in scope {
        let (path, file) = &mut log.files[index];
        let mut visit = |record: &ScannedRecord| {
            if record.kind != RecordKind::PageImage || record.lsn < redo_lsn {
                return;
            }
            if record.transaction != 0 && status_of(record.transaction) != Some(TxStatus::Committed)
            {
                skipped += 1;
                return;
            }
            if record.payload_len != max_body_bytes - RECORD_FIXED_BODY_BYTES {
                short_image.get_or_insert(record.lsn);
                return;
            }
            replayed += 1;
            max_page = Some(max_page.map_or(record.page_id, |page| page.max(record.page_id)));
            // `PageStore::reserve`, called before each replayed write.
            let needed = record.page_id.saturating_add(1);
            if needed > count {
                if let Some(pages) = file_pages {
                    if pages > needed {
                        truncated_from.get_or_insert(needed);
                    }
                    file_pages = Some(needed);
                }
                count = needed;
            }
            if build_map {
                let state_bytes = (outcomes.len() as u64)
                    .saturating_mul(32)
                    .saturating_add((images.len() as u64 + 1).saturating_mul(128))
                    .saturating_add(files_bytes);
                if limits.check(state_bytes).is_err() {
                    return;
                }
                images.insert(
                    record.page_id,
                    LoggedImage {
                        file: index,
                        offset: record.payload_offset,
                        lsn: record.lsn,
                    },
                );
            }
        };
        scan_file_read_only(
            file,
            path,
            max_body_bytes,
            &mut expected,
            &mut second,
            &mut visit,
            limits,
        )
        .map_err(|error| error.to_string())?;
    }
    if let Some(lsn) = short_image {
        return Err(format!(
            "the committed page image at LSN {lsn} is not one page long; a real open refuses this \
             log"
        ));
    }
    if second.records != scan.records || second.last_lsn != scan.last_lsn {
        return Err("the page log changed between the two read-only passes".to_string());
    }
    out.records = scan.records;
    out.first_lsn = first_lsn;
    out.last_lsn = scan.last_lsn;
    out.checkpoint_records = checkpoints;
    out.redo_lsn = redo_lsn;
    out.committed = committed;
    out.outcomes = outcomes;
    out.images_replayed = replayed;
    out.uncommitted_skipped = skipped;
    out.images = images;
    out.max_page = max_page;
    out.truncated_from = truncated_from;
    Ok(())
}

#[cfg(test)]
mod tests {
    #[test]
    fn synced_commits_never_record_a_deferred_commit() {
        let dir = tempfile::TempDir::new().unwrap();
        let wal = Wal::open(&dir.path().join("store.wal"), false).unwrap();
        for transaction in 1..=5 {
            wal.commit(transaction).unwrap();
        }
        assert_eq!(wal.deferred_commit_lsn(), 0);
        let lsn = wal.commit_unsynced(6).unwrap();
        assert_eq!(wal.deferred_commit_lsn(), lsn);
    }

    use super::*;
    use crate::manager::{PageStore, PageStoreOptions};
    use crate::page::{PageHeader, PageType, PAGE_HEADER_BYTES};
    use crate::pool::{BufferPool, BufferPoolOptions};
    use std::sync::Arc;
    use tempfile::TempDir;

    fn wal(dir: &TempDir) -> Wal {
        Wal::open(dir.path().join("test.wal"), false).unwrap()
    }

    fn store(dir: &TempDir, page_size: u32) -> Arc<PageStore> {
        Arc::new(
            PageStore::open(
                dir.path().join("test.pages"),
                PageStoreOptions::default()
                    .with_page_size(page_size)
                    .with_fsync(false),
            )
            .unwrap(),
        )
    }

    fn page_image(page_id: PageId, page_size: u32, marker: u8) -> Vec<u8> {
        let mut page = vec![0u8; page_size as usize];
        PageHeader::new(page_id, PageType::Heap, page_size).encode(&mut page);
        page[PAGE_HEADER_BYTES] = marker;
        crate::page::finalize(&mut page, 1);
        page
    }

    #[test]
    fn records_round_trip_in_order() {
        let dir = TempDir::new().unwrap();
        let wal = wal(&dir);
        let a = wal.log_page_image(5, 1, b"image-a").unwrap();
        let b = wal.log_page_image(6, 1, b"image-b").unwrap();
        let c = wal.commit(1).unwrap();

        let (records, truncated) = wal.read_all().unwrap();
        assert_eq!(truncated, 0);
        assert_eq!(records.len(), 3);
        assert_eq!(records[0].lsn, a);
        assert_eq!(records[0].page_id, 5);
        assert_eq!(records[0].payload, b"image-a");
        assert_eq!(records[1].lsn, b);
        assert_eq!(records[2].lsn, c);
        assert_eq!(records[2].kind, RecordKind::Commit);
        assert!(a < b && b < c, "LSNs must increase");
    }

    #[test]
    fn terminal_outcome_range_streams_only_requested_decisions() {
        let dir = TempDir::new().unwrap();
        let wal = wal(&dir);
        wal.commit(8).unwrap();
        wal.log_page_image(5, 9, b"ignored page image").unwrap();
        wal.abort(9).unwrap();
        wal.commit(10).unwrap();
        wal.commit(11).unwrap();

        let (outcomes, truncated) = wal.terminal_outcomes_in_range(9, 11).unwrap();
        assert_eq!(truncated, 0);
        assert_eq!(
            outcomes,
            vec![(9, TxStatus::Aborted), (10, TxStatus::Committed)]
        );
    }

    #[test]
    fn sync_batches_latency_and_checkpoint_freshness_are_exact_and_strict() {
        let dir = TempDir::new().unwrap();
        let wal = wal(&dir);
        for page_id in 1..=3 {
            wal.log_page_image(page_id, 1, b"image").unwrap();
        }
        assert_eq!(wal.snapshot().syncs, 0);
        wal.sync().unwrap();

        let first = wal.snapshot();
        assert_eq!(first.syncs, 1);
        assert_eq!(first.sync_failures, 0);
        assert_eq!(first.sync_records_total, 3);
        assert_eq!(first.last_sync_records, 3);
        assert_eq!(first.max_sync_records, 3);
        assert_eq!(first.sync_latency.count, first.syncs);
        assert_eq!(first.sync_latency.cumulative_buckets[8], first.syncs);
        assert!(first.sync_latency.is_consistent());

        wal.sync().unwrap();
        assert_eq!(
            wal.snapshot().syncs,
            first.syncs,
            "an already-durable target synced again"
        );

        wal.checkpoint(wal.next_lsn(), 0).unwrap();
        let checkpointed = wal.snapshot();
        assert_eq!(checkpointed.checkpoints, 1);
        assert!(checkpointed.last_checkpoint_completed_at_millis > 0);
        assert!(checkpointed.checkpoint_age_millis < 10_000);
        assert_eq!(checkpointed.sync_records_total, 4);
        assert_eq!(checkpointed.last_sync_records, 1);
        assert_eq!(checkpointed.max_sync_records, 3);
        assert_eq!(checkpointed.sync_latency.count, checkpointed.syncs);

        let encoded = serde_json::to_value(checkpointed).unwrap();
        assert_eq!(
            serde_json::from_value::<WalSnapshot>(encoded.clone()).unwrap(),
            checkpointed
        );
        let mut forged = encoded;
        forged["sync_latency"]["dynamic_bucket"] = serde_json::json!(1);
        assert!(serde_json::from_value::<WalSnapshot>(forged).is_err());
    }

    #[test]
    fn a_corrupted_record_stops_the_replay_at_that_point() {
        let dir = TempDir::new().unwrap();
        let path = dir.path().join("test.wal");
        {
            let wal = Wal::open(&path, false).unwrap();
            for index in 0..5u64 {
                wal.log_page_image(index, 1, b"payload").unwrap();
            }
            wal.sync().unwrap();
        }

        // Corrupt a byte inside the third record's payload.
        let mut bytes = std::fs::read(&path).unwrap();
        let record_len = RECORD_HEADER_BYTES + 16 + 7;
        let target = record_len * 2 + RECORD_HEADER_BYTES + 16;
        bytes[target] ^= 0xFF;
        std::fs::write(&path, &bytes).unwrap();

        let wal = Wal::open(&path, false).unwrap();
        let (records, truncated) = wal.read_all().unwrap();
        assert_eq!(records.len(), 2, "replay continued past a bad checksum");
        assert!(truncated > 0);
    }

    #[test]
    fn a_torn_tail_is_truncated_rather_than_treated_as_corruption() {
        // A crash almost always lands mid-record, so this is the NORMAL case,
        // not an error: those bytes were never acknowledged to anyone.
        let dir = TempDir::new().unwrap();
        let path = dir.path().join("test.wal");
        {
            let wal = Wal::open(&path, false).unwrap();
            wal.log_page_image(1, 1, b"complete").unwrap();
            wal.commit(1).unwrap();
            wal.log_page_image(2, 2, b"interrupted").unwrap();
            wal.sync().unwrap();
        }

        // Chop the final record in half.
        let len = std::fs::metadata(&path).unwrap().len();
        let file = OpenOptions::new().write(true).open(&path).unwrap();
        file.set_len(len - 10).unwrap();
        drop(file);

        let wal = Wal::open(&path, false).unwrap();
        let truncated = wal.truncate_torn_tail().unwrap();
        assert!(truncated > 0);

        let (records, remaining) = wal.read_all().unwrap();
        assert_eq!(remaining, 0, "torn tail was not removed");
        assert_eq!(records.len(), 2);

        // And the log is appendable again, contiguously.
        wal.log_page_image(3, 3, b"after-recovery").unwrap();
        let (records, _) = wal.read_all().unwrap();
        assert_eq!(records.len(), 3);
    }

    #[test]
    fn recovery_applies_committed_pages_and_skips_uncommitted_ones() {
        let dir = TempDir::new().unwrap();
        let page_size = 512u32;
        let store = store(&dir, page_size);
        let wal = Wal::open(dir.path().join("test.wal"), false).unwrap();
        store.reserve(10).unwrap();

        // Transaction 1 commits; transaction 2 does not.
        wal.log_page_image(1, 1, &page_image(1, page_size, 0xAA))
            .unwrap();
        wal.commit(1).unwrap();
        wal.log_page_image(2, 2, &page_image(2, page_size, 0xBB))
            .unwrap();
        wal.sync().unwrap();

        let report = recover(&wal, &store).unwrap();
        assert_eq!(report.pages_replayed, 1);
        assert_eq!(report.uncommitted_skipped, 1);
        assert_eq!(report.committed_transactions, 1);
        assert_eq!(report.wal_bytes_scanned, wal.size_bytes());
        assert_eq!(report.scan_passes, 2);
        assert_eq!(report.transaction_outcomes, 1);
        assert_eq!(report.terminal_outcome_records, 1);
        assert!(report.peak_transaction_outcome_bytes >= 9);
        assert_eq!(
            report.peak_record_bytes,
            (RECORD_HEADER_BYTES + RECORD_FIXED_BODY_BYTES + page_size as usize) as u64
        );
        assert!(report.peak_record_bytes <= MAX_WAL_RECORD_BYTES as u64);
        assert!(report.duration_nanos > 0);

        let mut page = vec![0u8; page_size as usize];
        store.read_page(1, &mut page).unwrap();
        assert_eq!(page[PAGE_HEADER_BYTES], 0xAA, "committed page not restored");

        // The uncommitted page must NOT be visible.
        assert!(
            store.read_page(2, &mut page).is_err() || page[PAGE_HEADER_BYTES] != 0xBB,
            "an uncommitted page was exposed by recovery"
        );
    }

    #[test]
    fn recovery_streams_a_large_suffix_with_one_page_sized_record_buffer() {
        let dir = TempDir::new().unwrap();
        let page_size = 512_u32;
        let store = store(&dir, page_size);
        let wal = Wal::open(dir.path().join("test.wal"), false).unwrap();
        let image = page_image(1, page_size, 0x5A);
        let records = 20_000_u64;

        // No transaction outcome is recorded, so the second pass validates and
        // skips every image without growing the page file. The WAL itself is
        // more than ten thousand times larger than the retained record buffer.
        for page_id in 1..=records {
            wal.log_page_image(page_id, 99, &image).unwrap();
        }
        wal.sync().unwrap();
        let wal_bytes = wal.size_bytes();
        assert!(wal_bytes > 10 * 1024 * 1024);

        let report = recover(&wal, &store).unwrap();
        assert_eq!(report.records_scanned, records);
        assert_eq!(report.scan_passes, 2);
        assert_eq!(report.uncommitted_skipped, records);
        assert_eq!(report.pages_replayed, 0);
        assert_eq!(report.transaction_outcomes, 0);
        assert_eq!(report.terminal_outcome_records, 0);
        assert_eq!(report.peak_transaction_outcome_bytes, 0);
        assert_eq!(report.wal_bytes_scanned, wal_bytes);
        assert_eq!(
            report.peak_record_bytes,
            (RECORD_HEADER_BYTES + RECORD_FIXED_BODY_BYTES + page_size as usize) as u64
        );
        assert!(wal_bytes > report.peak_record_bytes.saturating_mul(10_000));
    }

    #[test]
    fn recovery_compacts_many_terminal_outcomes() {
        let dir = TempDir::new().unwrap();
        let page_size = 512_u32;
        let store = store(&dir, page_size);
        let wal = Wal::open(dir.path().join("test.wal"), false).unwrap();
        let outcomes = 20_000_u64;

        for xid in (1..=outcomes).rev() {
            wal.abort(xid).unwrap();
        }
        wal.sync().unwrap();

        let report = recover(&wal, &store).unwrap();
        assert_eq!(report.terminal_outcome_records, outcomes);
        assert_eq!(report.transaction_outcomes, outcomes);
        assert_eq!(report.committed_transactions, 0);
        assert!(report.peak_transaction_outcome_bytes >= outcomes.saturating_mul(9));
        assert!(report.peak_transaction_outcome_bytes < outcomes.saturating_mul(20));
    }

    #[test]
    fn abort_after_commit_is_not_appended_and_commit_survives_recovery() {
        let dir = TempDir::new().unwrap();
        let page_size = 512_u32;
        let store = store(&dir, page_size);
        let wal = Wal::open(dir.path().join("test.wal"), false).unwrap();
        wal.commit(7).unwrap();
        // The natural cleanup after a failed commit fsync: the commit record
        // may be on disk anyway, so the abort must not create a contradiction
        // that recovery would refuse to open.
        wal.abort(7).unwrap();
        wal.sync().unwrap();

        let (report, outcomes) = recover_with_outcomes(&wal, &store).unwrap();
        assert_eq!(report.transaction_outcomes, 1);
        assert_eq!(outcomes.status(7), Some(crate::mvcc::TxStatus::Committed));
    }

    #[test]
    fn recovery_rejects_contradictory_terminal_outcomes() {
        let dir = TempDir::new().unwrap();
        let page_size = 512_u32;
        let store = store(&dir, page_size);
        let wal = Wal::open(dir.path().join("test.wal"), false).unwrap();
        wal.commit(7).unwrap();
        // The live abort path refuses to write this contradiction; a
        // corrupted or hand-built log can still contain one, and recovery
        // must keep rejecting it.
        wal.append(RecordKind::Abort, 0, 7, &[]).unwrap();
        wal.sync().unwrap();

        let error = recover(&wal, &store).unwrap_err();
        assert!(matches!(error, PageError::WalCorruption { .. }));
        assert!(error.to_string().contains("contradictory commit and abort"));
    }

    #[test]
    fn oversized_tail_length_is_truncated_before_body_allocation() {
        let dir = TempDir::new().unwrap();
        let page_size = 512_u32;
        let store = store(&dir, page_size);
        let path = dir.path().join("test.wal");
        let wal = Wal::open(&path, false).unwrap();
        wal.log_page_image(1, 1, &page_image(1, page_size, 0xA5))
            .unwrap();
        wal.commit(1).unwrap();
        let valid_bytes = wal.size_bytes();

        let mut forged = Vec::with_capacity(RECORD_HEADER_BYTES);
        forged.extend_from_slice(&RECORD_MAGIC);
        forged.extend_from_slice(&wal.next_lsn().to_le_bytes());
        forged.push(RecordKind::PageImage as u8);
        forged.extend_from_slice(&[0_u8; 3]);
        forged.extend_from_slice(&u32::MAX.to_le_bytes());
        forged.extend_from_slice(&0_u32.to_le_bytes());
        assert_eq!(forged.len(), RECORD_HEADER_BYTES);
        std::fs::OpenOptions::new()
            .append(true)
            .open(&path)
            .unwrap()
            .write_all(&forged)
            .unwrap();
        wal.end_offset
            .store(valid_bytes + forged.len() as u64, Ordering::Release);

        let report = recover(&wal, &store).unwrap();
        assert_eq!(report.truncated_bytes, RECORD_HEADER_BYTES as u64);
        assert_eq!(wal.size_bytes(), valid_bytes);
        assert_eq!(std::fs::metadata(&path).unwrap().len(), valid_bytes);
        assert!(report.peak_record_bytes <= MAX_WAL_RECORD_BYTES as u64);

        // Recovery also restored the append position; no LSN hole is created.
        wal.log_page_image(2, 2, &page_image(2, page_size, 0x5A))
            .unwrap();
        assert_eq!(wal.read_all().unwrap().1, 0);
    }

    #[test]
    fn recovery_rejects_identifiers_that_would_overflow_runtime_state() {
        let dir = TempDir::new().unwrap();
        let page_size = 512_u32;
        let store = store(&dir, page_size);
        let wal = Wal::open(dir.path().join("page-id.wal"), false).unwrap();
        wal.log_page_image(PageId::MAX, 1, &page_image(1, page_size, 0xA5))
            .unwrap();
        wal.commit(1).unwrap();
        let error = recover(&wal, &store).unwrap_err();
        assert!(matches!(error, PageError::WalCorruption { .. }));
        assert!(error.is_corruption());

        let wal = Wal::open(dir.path().join("transaction-id.wal"), false).unwrap();
        wal.commit(u64::MAX).unwrap();
        let error = recover(&wal, &store).unwrap_err();
        assert!(matches!(error, PageError::WalCorruption { .. }));
        assert!(error.is_corruption());
    }

    /// Crash state from recovery evidence: uncommitted work after the last
    /// superblock write took the free-list head (allocation writes the reused
    /// page retyped, straight to the file, while the superblock still names it
    /// as the head) and nothing committed since the last checkpoint, so
    /// recovery replayed no page and kept the published list. The first
    /// allocation after the open then failed with `page N has type 2,
    /// expected 6`.
    fn crash_after_allocating_the_published_free_list_head(
        dir: &TempDir,
        page_size: u32,
        steal: bool,
    ) -> (PageId, PageId) {
        let store = store(dir, page_size);
        let a = store.allocate(PageType::Heap).unwrap();
        let b = store.allocate(PageType::Heap).unwrap();
        store.free(a).unwrap();
        store.free(b).unwrap();
        assert_eq!(store.free_list_head(), b);
        // Publish the free-list head before the later allocation. Dropping
        // PageStore intentionally does not persist allocator metadata.
        store.publish_root(0, 0).unwrap();
        let reused = store.allocate(PageType::Heap).unwrap();
        assert_eq!(reused, b);
        let wal = Wal::open(dir.path().join("test.wal"), false).unwrap();
        if steal {
            // The page also reached the log as a stolen image of a
            // transaction that never commits.
            wal.log_page_image(reused, 7, &page_image(reused, page_size, 1))
                .unwrap();
        }
        (a, b)
    }

    #[test]
    fn recovery_with_nothing_to_replay_detaches_a_free_list_whose_head_was_allocated() {
        for steal in [false, true] {
            let dir = TempDir::new().unwrap();
            let page_size = 512u32;
            let (a, b) =
                crash_after_allocating_the_published_free_list_head(&dir, page_size, steal);

            let store = store(&dir, page_size);
            assert_eq!(
                store.free_list_head(),
                b,
                "the stale head is what was published"
            );
            let wal = Wal::open(dir.path().join("test.wal"), false).unwrap();
            let report = recover(&wal, &store).unwrap();
            assert_eq!(report.pages_replayed, 0);
            assert_eq!(report.free_pages_detached, 2);
            assert_eq!(store.free_list_head(), 0);

            // Allocation no longer walks into the retyped page, and neither
            // listed page is handed out (`b` may hold the crashed work).
            let page = store.allocate(PageType::Heap).unwrap();
            assert!(page != a && page != b, "allocated {page}");
        }
    }

    #[test]
    fn recovery_keeps_a_free_list_whose_head_is_still_free() {
        let dir = TempDir::new().unwrap();
        let page_size = 512u32;
        let b = {
            let store = store(&dir, page_size);
            let a = store.allocate(PageType::Heap).unwrap();
            let b = store.allocate(PageType::Heap).unwrap();
            store.free(a).unwrap();
            store.free(b).unwrap();
            store.publish_root(0, 0).unwrap();
            b
        };
        let store = store(&dir, page_size);
        let wal = Wal::open(dir.path().join("test.wal"), false).unwrap();
        let report = recover(&wal, &store).unwrap();
        assert_eq!(report.free_pages_detached, 0);
        assert_eq!(store.free_list_head(), b);
        assert_eq!(store.allocate(PageType::Heap).unwrap(), b);
    }

    #[test]
    fn recovery_is_idempotent() {
        // Replay must survive being interrupted and restarted, which is only
        // true because records are full page images.
        let dir = TempDir::new().unwrap();
        let page_size = 512u32;
        let store = store(&dir, page_size);
        let wal = Wal::open(dir.path().join("test.wal"), false).unwrap();
        store.reserve(10).unwrap();

        for index in 1..=5u64 {
            wal.log_page_image(index, 1, &page_image(index, page_size, index as u8))
                .unwrap();
        }
        wal.commit(1).unwrap();

        let first = recover(&wal, &store).unwrap();
        let second = recover(&wal, &store).unwrap();
        let third = recover(&wal, &store).unwrap();
        assert_eq!(first.pages_replayed, second.pages_replayed);
        assert_eq!(second.pages_replayed, third.pages_replayed);

        for index in 1..=5u64 {
            let mut page = vec![0u8; page_size as usize];
            store.read_page(index, &mut page).unwrap();
            assert_eq!(page[PAGE_HEADER_BYTES], index as u8);
        }
    }

    #[test]
    fn an_aborted_transactions_pages_are_never_applied() {
        let dir = TempDir::new().unwrap();
        let page_size = 512u32;
        let store = store(&dir, page_size);
        let wal = Wal::open(dir.path().join("test.wal"), false).unwrap();
        store.reserve(10).unwrap();

        wal.log_page_image(1, 7, &page_image(1, page_size, 0x11))
            .unwrap();
        wal.abort(7).unwrap();
        wal.sync().unwrap();

        let report = recover(&wal, &store).unwrap();
        assert_eq!(report.pages_replayed, 0);
        assert_eq!(report.uncommitted_skipped, 1);
    }

    #[test]
    fn a_checkpoint_moves_the_redo_point_forward() {
        let dir = TempDir::new().unwrap();
        let page_size = 512u32;
        let store = store(&dir, page_size);
        let pool = Arc::new(
            BufferPool::new(
                store.clone(),
                BufferPoolOptions::default().with_budget_bytes(32 * 512),
            )
            .unwrap(),
        );
        let wal = Arc::new(Wal::open(dir.path().join("test.wal"), false).unwrap());
        let checkpointer = Checkpointer::new(pool, wal.clone());

        for index in 0..5u64 {
            let page_id = store.allocate(PageType::Heap).unwrap();
            checkpointer
                .log_and_write(page_id, 1, &page_image(page_id, page_size, index as u8))
                .unwrap();
        }
        wal.commit(1).unwrap();

        let report = checkpointer.checkpoint(0).unwrap();
        assert!(report.redo_lsn > 0);
        assert_eq!(wal.redo_lsn(), report.redo_lsn);
        // The checkpoint record itself takes the redo LSN: "everything BEFORE
        // redo_lsn is already durable" is satisfied by the record that declares
        // it, so equality is correct rather than off by one.
        assert!(report.checkpoint_lsn >= report.redo_lsn);
    }

    #[test]
    fn recovery_after_a_checkpoint_only_replays_the_suffix() {
        // The Phase 3 gate: recovery cost tracks the post-checkpoint suffix, not
        // total writes.
        let dir = TempDir::new().unwrap();
        let page_size = 512u32;
        let store = store(&dir, page_size);
        let pool = Arc::new(
            BufferPool::new(
                store.clone(),
                BufferPoolOptions::default().with_budget_bytes(64 * 512),
            )
            .unwrap(),
        );
        let wal = Arc::new(Wal::open(dir.path().join("test.wal"), false).unwrap());
        let checkpointer = Checkpointer::new(pool, wal.clone());

        let mut pages = Vec::new();
        for index in 0..40u64 {
            let page_id = store.allocate(PageType::Heap).unwrap();
            pages.push(page_id);
            checkpointer
                .log_and_write(page_id, 1, &page_image(page_id, page_size, index as u8))
                .unwrap();
        }
        wal.commit(1).unwrap();
        checkpointer.checkpoint(0).unwrap();
        // The redo point is only honored when the page files' own recorded
        // horizon vouches for it (see recover_with_outcomes) — publish it,
        // exactly as PagedStore's checkpoint does.
        store.publish_root(0, wal.next_lsn()).unwrap();

        // A little more work after the checkpoint.
        for index in 0..3u64 {
            let page_id = store.allocate(PageType::Heap).unwrap();
            checkpointer
                .log_and_write(
                    page_id,
                    2,
                    &page_image(page_id, page_size, 0xF0 | index as u8),
                )
                .unwrap();
        }
        wal.commit(2).unwrap();

        let report = recover(&wal, &store).unwrap();
        assert!(
            report.pages_replayed <= 4,
            "recovery replayed {} pages; it should only cover the post-checkpoint \
             suffix, not all 43",
            report.pages_replayed
        );
        assert!(report.redo_lsn > 0);
    }

    #[test]
    fn truncating_after_a_checkpoint_bounds_the_log() {
        let dir = TempDir::new().unwrap();
        let page_size = 512u32;
        let store = store(&dir, page_size);
        let pool = Arc::new(
            BufferPool::new(
                store.clone(),
                BufferPoolOptions::default().with_budget_bytes(64 * 512),
            )
            .unwrap(),
        );
        let wal = Arc::new(Wal::open(dir.path().join("test.wal"), false).unwrap());
        let checkpointer = Checkpointer::new(pool, wal.clone());

        for index in 0..30u64 {
            let page_id = store.allocate(PageType::Heap).unwrap();
            checkpointer
                .log_and_write(page_id, 1, &page_image(page_id, page_size, index as u8))
                .unwrap();
        }
        wal.commit(1).unwrap();
        let before = wal.size_bytes();
        assert!(before > 0);

        checkpointer.checkpoint_and_truncate(0).unwrap();
        assert_eq!(wal.size_bytes(), 0, "log was not bounded by the checkpoint");

        // The data is still there, from the page file rather than the log.
        let mut page = vec![0u8; page_size as usize];
        store.read_page(1, &mut page).unwrap();
    }

    #[test]
    fn group_commit_shares_one_sync_without_weakening_durability() {
        let dir = TempDir::new().unwrap();
        let wal = Arc::new(Wal::open(dir.path().join("test.wal"), false).unwrap());

        let mut handles = Vec::new();
        for transaction in 0..8u64 {
            let wal = wal.clone();
            handles.push(std::thread::spawn(move || {
                wal.log_page_image(transaction, transaction, b"work")
                    .unwrap();
                let lsn = wal.commit(transaction).unwrap();
                // The contract: on return, this commit IS durable.
                assert!(
                    wal.durable_lsn() >= lsn,
                    "commit returned before its own record was durable"
                );
            }));
        }
        for handle in handles {
            handle.join().unwrap();
        }

        let snapshot = wal.snapshot();
        assert_eq!(snapshot.records_appended, 16);
        assert!(snapshot.syncs >= 1);
        assert!(
            snapshot.syncs <= 8,
            "no group commit happened: {} syncs for 8 commits",
            snapshot.syncs
        );
        assert_eq!(snapshot.sync_latency.count, snapshot.syncs);
        assert_eq!(snapshot.sync_records_total, snapshot.records_appended);
        assert!(snapshot.last_sync_records <= snapshot.max_sync_records);
        assert!(snapshot.max_sync_records >= 2);
    }

    #[test]
    fn concurrent_appends_produce_contiguous_lsns() {
        let dir = TempDir::new().unwrap();
        let wal = Arc::new(Wal::open(dir.path().join("test.wal"), false).unwrap());

        let mut handles = Vec::new();
        for transaction in 0..6u64 {
            let wal = wal.clone();
            handles.push(std::thread::spawn(move || {
                for _ in 0..20 {
                    wal.log_page_image(transaction, transaction, b"x").unwrap();
                }
            }));
        }
        for handle in handles {
            handle.join().unwrap();
        }
        wal.sync().unwrap();

        let (records, truncated) = wal.read_all().unwrap();
        assert_eq!(truncated, 0, "concurrent appends interleaved mid-record");
        assert_eq!(records.len(), 120);
        for (index, record) in records.iter().enumerate() {
            assert_eq!(record.lsn, index as u64 + 1, "LSNs are not contiguous");
        }
    }

    #[test]
    fn an_empty_log_recovers_to_nothing() {
        let dir = TempDir::new().unwrap();
        let store = store(&dir, 512);
        let wal = wal(&dir);
        let report = recover(&wal, &store).unwrap();
        assert_eq!(report.records_scanned, 0);
        assert_eq!(report.pages_replayed, 0);
    }

    #[test]
    fn a_log_with_out_of_order_lsns_stops_at_the_discontinuity() {
        // Two log generations concatenated, or a partial overwrite. Replaying
        // across it would apply records whose ordering cannot be trusted.
        let dir = TempDir::new().unwrap();
        let path = dir.path().join("test.wal");
        {
            let wal = Wal::open(&path, false).unwrap();
            wal.log_page_image(1, 1, b"one").unwrap();
            wal.log_page_image(2, 1, b"two").unwrap();
            wal.sync().unwrap();
        }
        let first = std::fs::read(&path).unwrap();
        {
            // A second generation restarting from LSN 1.
            std::fs::remove_file(&path).unwrap();
            let wal = Wal::open(&path, false).unwrap();
            wal.log_page_image(3, 1, b"three").unwrap();
            wal.sync().unwrap();
        }
        let second = std::fs::read(&path).unwrap();
        let mut concatenated = first;
        concatenated.extend_from_slice(&second);
        std::fs::write(&path, &concatenated).unwrap();

        let wal = Wal::open(&path, false).unwrap();
        let (records, truncated) = wal.read_all().unwrap();
        assert_eq!(records.len(), 2, "replay crossed an LSN discontinuity");
        assert!(truncated > 0);
    }

    #[test]
    fn reopen_restores_the_active_segment_identity_before_the_next_rotation() {
        let dir = TempDir::new().unwrap();
        let path = dir.path().join("store.wal");
        let payload = vec![7_u8; 96];
        {
            let wal = Wal::open_with_segments_and_floor(&path, false, 180, 1).unwrap();
            for page_id in 1..=5 {
                wal.log_page_image(page_id, 0, &payload).unwrap();
            }
            wal.sync().unwrap();
            assert!(!wal.sealed_segment_paths().is_empty());
            assert!(wal.end_offset.load(Ordering::Acquire) > 0);
        }

        // A checkpoint floor can be older than the first record in the
        // surviving active file after a crash during checkpoint/reset. Open
        // starts from that floor; recovery must replace it with the active
        // file's observed first LSN before another rotation chooses a name.
        let wal = Wal::open_with_segments_and_floor(&path, false, 180, 1).unwrap();
        wal.truncate_torn_tail().unwrap();
        let active_first = wal.active_first_lsn.load(Ordering::Acquire);
        assert!(active_first > 1);
        wal.log_page_image(6, 0, &payload).unwrap();

        let sealed = wal.sealed.lock().clone();
        let unique = sealed
            .iter()
            .copied()
            .collect::<std::collections::BTreeSet<_>>();
        assert_eq!(
            sealed.len(),
            unique.len(),
            "WAL segment identity was reused"
        );
        wal.reset()
            .expect("checkpoint cleanup must not address one segment twice");
    }
}
