"""Discard only owned guest RAM at source-pinned partition upgrade boundaries."""
import fcntl,hashlib,json,os,pathlib,re,shutil,signal,subprocess,sys,time
root=pathlib.Path('/root/bicdb-durability-s3');shared=root/'vm-reset';source='0adf78abbc53f697e76f889ef52f036e7a1153d6';runtime='5aa92dcecb29b639251acc81a5d60428dfae96f7'
smoke='--smoke' in sys.argv;tag='partition-vm-0adf78ab'+('-smoke' if smoke else '')
out=root/tag;out.mkdir(exist_ok=False)
record={'source':source,'production_equivalent':runtime,'status':'waiting_for_build','started_unix':time.time(),'scope':'Actual disposable KVM guest RAM loss via SIGKILL of exact owned QEMU process; existing pre-I/O fence and Native txlog hooks, plus after independently observed/fsynced upgrade ACK. Original old482 ACK fixtures copied unchanged. Three guest reopens exact old/new full rows+raw schemas and Native indexes. No volatile emulation, no cloud spend, not physical host power loss/RF3/distributed capacity/full application.','cases':[]}
def save():
 p=out/'result.json';p.write_text(json.dumps(record,indent=2)+'\n')
def sha(p):return hashlib.file_digest(pathlib.Path(p).open('rb'),'sha256').hexdigest()
def fsynced_json(p,value):
 with p.open('x') as f:json.dump(value,f);f.write('\n');f.flush();os.fsync(f.fileno())
 fd=os.open(p.parent,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
def wait_unit(unit):
 while subprocess.check_output(['systemctl','show',unit,'-p','ActiveState','--value'],text=True).strip() in ['active','activating','reloading']:time.sleep(3)
def hashes(p):return {str(f.relative_to(p)):{'bytes':f.stat().st_size,'sha256':sha(f)} for f in p.rglob('*') if f.is_file() and not f.is_symlink()}
def copy_disk(a,b):subprocess.run(['cp','--reflink=auto','--sparse=always',str(a),str(b)],check=True)
save();guest=None
try:
 wait_unit('bicdb-partition-generated-vm-probe')
 build=json.loads((root/'report-partition-generated-vm-probe.json').read_text());assert build['source']==source and build['status']=='focused_passed',build
 binary=pathlib.Path(build['binary']);assert sha(binary)==build['binary_sha256']
 wait_unit('bicdb-partition-generated-recovery-5aa92dce')
 controls=json.loads((root/'partition-crash-matrix-5aa92dce/result.json').read_text());assert controls['source']==runtime and controls['status']=='crash_matrix_passed' and len(controls['controls'])==8
 lock=(shared/'final-qualification.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 for proc in pathlib.Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  try:argv=(proc/'cmdline').read_bytes().split(b'\0')
  except (FileNotFoundError,ProcessLookupError,PermissionError):continue
  assert not (argv and b'qemu-system' in pathlib.Path(os.fsdecode(argv[0])).name.encode()),'another VM is active'
 assert pathlib.Path('/dev/kvm').exists()
 q=shared/'qemu';qemu=q/'usr/bin/qemu-system-x86_64';kernel=shared/'vmlinuz';initroot=out/'initroot'
 for d in ['bin','sbin','proc','sys','dev','run','data','tmp','etc']:(initroot/d).mkdir(parents=True,exist_ok=True)
 shutil.copy2('/usr/bin/busybox',initroot/'bin/busybox')
 for n in ['sh','mount','mkdir','sleep','cat','echo','sha256sum']:(initroot/'bin'/n).symlink_to('busybox')
 for executable,target in [(binary,'bin/partition_probe'),(pathlib.Path('/usr/sbin/e2fsck'),'sbin/e2fsck')]:
  shutil.copy2(executable,initroot/target)
  for lib in re.findall(r'(/[^\s()]+)',subprocess.check_output(['ldd',str(executable)],text=True)):
   dest=initroot/lib.lstrip('/');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(lib,dest)
 assert sha(initroot/'bin/partition_probe')==build['binary_sha256']
 init='''#!/bin/sh
export PATH=/bin:/sbin MALLOC_ARENA_MAX=2
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev
mount -t tmpfs tmpfs /run
for arg in $(cat /proc/cmdline); do
 case "$arg" in
  task_action=*) action=${arg#*=};;
  task_mode=*) mode=${arg#*=};;
  task_case=*) testcase=${arg#*=};;
  task_site=*) site=${arg#*=};;
  task_new=*) require_new=${arg#*=};;
 esac
done
sha256sum /bin/partition_probe
/sbin/e2fsck -p /dev/vda
checked=$?
if [ "$checked" -gt 1 ]; then echo PARTITION_VM_FSCK_FAILED_$checked; while true; do sleep 1; done; fi
mount -t ext4 /dev/vda /data || { echo PARTITION_VM_MOUNT_FAILED; while true; do sleep 1; done; }
echo PARTITION_VM_MOUNTED
if [ "$action" = apply ]; then
 if [ "$site" = partition_upgrade.after_ack ]; then export PARTITION_VM_PAUSE_AFTER_ACK=1; else export PARTITION_VM_PAUSE_IO="$site:1"; fi
 /bin/partition_probe "$mode" apply /data/db "$testcase" /data/upgrade-ack.json
 result=$?
 echo PARTITION_VM_APPLY_UNEXPECTED_EXIT_$result
else
 if [ "$require_new" = 1 ]; then export PARTITION_VM_REQUIRE_NEW=1; fi
 /bin/partition_probe "$mode" verify /data/db /data/old.json /data/new.json
 result=$?
 echo PARTITION_VM_VERIFY_DONE_$result
fi
while true; do sleep 1; done
'''
 (initroot/'init').write_text(init);(initroot/'init').chmod(0o755)
 archive=out/'initrd.gz'
 with archive.open('wb') as dest:
  a=subprocess.Popen(['find','.','-print0'],cwd=initroot,stdout=subprocess.PIPE)
  b=subprocess.Popen(['cpio','--null','-o','--format=newc'],cwd=initroot,stdin=a.stdout,stdout=subprocess.PIPE,stderr=subprocess.PIPE);a.stdout.close()
  c=subprocess.Popen(['gzip','-1'],stdin=b.stdout,stdout=dest);b.stdout.close()
  assert c.wait()==0;err=b.communicate()[1];assert b.returncode==0,err;assert a.wait()==0
 record.update(status='running',binary=str(binary),binary_sha256=build['binary_sha256'],guest_sha256=sha(initroot/'bin/partition_probe'),kernel_sha256=sha(kernel),initrd_sha256=sha(archive));save()
 env={**os.environ,'LD_LIBRARY_PATH':str(q/'usr/lib/x86_64-linux-gnu')}
 def boot(disk,log,mode,testcase,site,action,require_new=False):
  assert not log.exists()
  cmd=[str(qemu),'-L',str(q/'usr/share/qemu'),'-name',tag,'-nodefaults','-no-user-config','-machine','q35,accel=kvm','-cpu','host','-m','2048','-smp','1','-display','none','-serial','file:'+str(log),'-monitor','none','-bios',str(q/'usr/share/seabios/bios-256k.bin'),'-kernel',str(kernel),'-initrd',str(archive),'-append',f'console=ttyS0 panic=-1 quiet task_action={action} task_mode={mode} task_case={testcase} task_site={site} task_new={int(require_new)}','-drive',f'file={disk},format=raw,if=virtio,cache=writeback,aio=threads']
  return subprocess.Popen(cmd,env=env,stdout=(out/'qemu.stdout').open('ab'),stderr=(out/'qemu.stderr').open('ab'))
 def observe(proc,log,marker):
  deadline=time.monotonic()+90
  while time.monotonic()<deadline:
   text=log.read_text(errors='replace') if log.exists() else ''
   assert proc.poll() is None,('QEMU exited before witness',proc.returncode,text[-2000:])
   if marker in text:return text
   assert not any(x in text for x in ['PARTITION_VM_FSCK_FAILED','PARTITION_VM_MOUNT_FAILED','PARTITION_VM_APPLY_UNEXPECTED_EXIT','Kernel panic']),text[-4000:]
   time.sleep(.025)
  raise TimeoutError('owned guest did not reach '+marker)
 def kill_owned(proc):
  assert proc.poll() is None
  proc.kill();assert proc.wait(timeout=15)==-signal.SIGKILL
 fixtures_root=root/'partition-old-store-fixtures-482-20261112';fixtures=json.loads((fixtures_root/'result.json').read_text());ledger=[json.loads(x) for x in (fixtures_root/'ack-ledger.jsonl').read_text().splitlines()];assert len(ledger)==14
 chosen=controls['controls']
 if smoke:chosen=[x for x in chosen if x['mode']=='server_paged' and x['case']=='parent_heap']
 for control in chosen:
  mode,testcase=control['mode'],control['case'];original='independent_child_policy' if testcase.startswith('policy_') else testcase
  fixture=next(f for f in fixtures['cases'] if f['mode']==mode and f['name']==original);db=pathlib.Path(fixture['directory'])/'db';assert hashes(db)==fixture['files']
  ack_entries=[x for x in ledger if x['mode']==mode and x['case']==original]
  old_json=root/'partition-crash-matrix-5aa92dce'/control['old_snapshot'];new_json=root/'partition-crash-matrix-5aa92dce'/control['new_snapshot'];old_snap=json.loads(old_json.read_text())
  assert len(ack_entries)==len(old_snap['rows']) and ack_entries
  for a in ack_entries:
   row=next(r for r in old_snap['rows'] if r[0]==a['relation'] and r[1]==str(a['k']));assert row[3]['metadata']['payload']==a['payload'] and row[3]['id']==str(a['k'])
  assert control['native_commit_span']==1,'do not assume hit count if plan spans multiple native commits'
  sites=['sql_partition.format_fence.'+s for s in ['write','sync','rename','dir_sync']]+['transaction_log.write','transaction_log.sync','partition_upgrade.after_ack']
  if smoke:sites=['sql_partition.format_fence.dir_sync','partition_upgrade.after_ack']
  for site in sites:
   name=mode+'-'+testcase+'-'+site.replace('.','_');work=out/name;work.mkdir();stage=work/'stage';stage.mkdir();shutil.copytree(db,stage/'db');shutil.copy2(old_json,stage/'old.json');shutil.copy2(new_json,stage/'new.json')
   disk=work/'working.raw'
   with disk.open('xb') as f:f.truncate(512*1024**2)
   subprocess.run(['mkfs.ext4','-q','-F','-d',str(stage),str(disk)],check=True)
   cut_log=work/'cut.console';guest=boot(disk,cut_log,mode,testcase,site,'apply');text=observe(guest,cut_log,'PARTITION_VM_CUT_READY ')
   assert record['guest_sha256'] in text,'guest binary identity absent'
   ready=[json.loads(line.split('PARTITION_VM_CUT_READY ',1)[1]) for line in text.splitlines() if 'PARTITION_VM_CUT_READY ' in line];assert len(ready)==1 and ready[0]['site']==site
   witnesses=[json.loads(line.split('PARTITION_VM_ACK ',1)[1]) for line in text.splitlines() if 'PARTITION_VM_ACK ' in line]
   expected_ack=site=='partition_upgrade.after_ack';assert len(witnesses)==int(expected_ack)
   if expected_ack:assert witnesses[0]['upgrade_acknowledged'] is True and witnesses[0]['after_native_sequence']-witnesses[0]['before_native_sequence']==1
   witness={'mode':mode,'case':testcase,'site':site,'owned_qemu_pid':guest.pid,'guest_witness':ready[0],'acknowledged':expected_ack,'ack':witnesses[0] if witnesses else None,'observed_unix':time.time()}
   fsynced_json(work/'external-witness.json',witness)
   kill_owned(guest);guest=None
   saved=work/'crashed.raw';copy_disk(disk,saved);saved_hash=sha(saved);verify_disk=work/'verify.raw';copy_disk(saved,verify_disk)
   verify_log=work/'verify.console';guest=boot(verify_disk,verify_log,mode,testcase,site,'verify',expected_ack);verified=observe(guest,verify_log,'PARTITION_VM_VERIFY_DONE_');assert 'PARTITION_VM_VERIFY_DONE_0' in verified,verified[-6000:]
   observations=[json.loads(line.strip()) for line in verified.splitlines() if line.strip().startswith('{')];assert len(observations)==3
   assert [x['reopen'] for x in observations]==[0,1,2]
   assert len({x['state'] for x in observations})==1
   for x in observations:assert x['full_records_and_schemas_equal'] and x['native_indexes_valid']
   if expected_ack:assert all(x['state']=='complete_new' for x in observations)
   kill_owned(guest);guest=None;assert sha(saved)==saved_hash
   item={**witness,'passed':True,'hard_kill_exit':-signal.SIGKILL,'observations':observations,'original_ACKs_linked':len(ack_entries),'saved_image':str(saved),'saved_image_sha256':saved_hash,'saved_image_unchanged_after_verification':True,'old_snapshot_sha256':sha(old_json),'new_snapshot_sha256':sha(new_json)};record['cases'].append(item);save()
   # Keep the untouched cut image, transcripts, independent witness and snapshots.
   disk.unlink();verify_disk.unlink();shutil.rmtree(stage)
  assert hashes(db)==fixture['files']
 expected=2 if smoke else 56;assert len(record['cases'])==expected
 record.update(status='vm_smoke_passed' if smoke else 'vm_matrix_passed',expected_cases=expected,originals_unchanged=True,finished_unix=time.time());save()
except BaseException as error:
 record.update(status='vm_qualification_failed',error=repr(error),finished_unix=time.time());save()
 if guest is not None and guest.poll() is None:guest.kill();guest.wait(timeout=15)
 raise
print(json.dumps({k:v for k,v in record.items() if k!='cases'}))
