import fcntl,json,os,pathlib,re,subprocess,time
root=pathlib.Path('/root/bicdb-durability-s3');host=root/'host-control';receipt=host/'partition-superseded-cc84-elf-cleanup-receipt.json';assert not receipt.exists()
while subprocess.check_output(['systemctl','show','bicdb-partition-ack-main489-broad','-p','ActiveState','--value'],text=True).strip() in ['active','activating','reloading']:time.sleep(3)
record={'status':'checking','started_unix':time.time(),'scope':'Only415candidateELFs named in terminal successful oldcc84task-ownedfullsuite log, superseded by fullsuccessful6c test executables. Never dependencies/probes/currentrunnable/currenttests/other targets. Exclusive tcsource lock; no tc compiler; exactpath/inode/size/mtime/nlink/ELF and allprocessFD/maps checks immediately before each unlink.','removed':[],'skipped':[]}
def save():receipt.write_text(json.dumps(record,indent=2)+'\n')
try:
 lock=(host/'source-build.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX)
 old=json.loads((root/'report-partition-schema-main488-broad.json').read_text());current=json.loads((root/'report-partition-ack-main489-broad.json').read_text());assert old['source']=='cc84f24fa263965d89697f36a96a9112a16d4016' and old['status']=='focused_passed' and current['source']=='6c16e66e742bb575041aebce4086ebf434b9fe64' and current['status']=='focused_passed'
 assert len(current['steps'])==5 and all(s['exit']==0 for s in old['steps']+current['steps'])
 inv=json.loads((host/'partition-superseded-cc84-elf-candidates.json').read_text());assert inv['old_source']==old['source'] and inv['current_source']==current['source']
 pattern=r'\((/root/bicdb-durability-s3/target-tc/debug/deps/[^\s()]+)\)';old_paths=set(re.findall(pattern,(root/'tc-step-partition-schema-main488-broad.log').read_text()));current_paths=set(re.findall(pattern,(root/'tc-step-partition-ack-main489-broad.log').read_text()));candidates={x['path']:x for x in inv['candidates']}
 active=set()
 for proc in pathlib.Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  try:
   a=(proc/'cmdline').read_bytes().split(b'\0')
   if a and pathlib.Path(os.fsdecode(a[0])).name in ['cargo','rustc']:assert str((proc/'cwd').resolve())!='/root/bicdb-durability-s3/repo-tc','tc compiler still active'
   for line in (proc/'maps').read_text().splitlines():
    fields=line.split(maxsplit=5)
    if len(fields)==6 and fields[5] in candidates:active.add(fields[5])
   for fd in (proc/'fd').iterdir():
    try:
     name=os.readlink(fd)
     if name in candidates:active.add(name)
    except (FileNotFoundError,ProcessLookupError,PermissionError):pass
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 record['available_before_bytes']=os.statvfs(root).f_bavail*os.statvfs(root).f_frsize;save()
 for name,x in candidates.items():
  p=pathlib.Path(name)
  if name in current_paths or name in active:record['skipped'].append({'path':name,'reason':'current_or_active'});continue
  assert name in old_paths and p.parent==root/'target-tc/debug/deps' and not p.is_symlink()
  if not p.exists():record['skipped'].append({'path':name,'reason':'already_absent'});continue
  s=p.stat();assert s.st_ino==x['inode'] and s.st_size==x['bytes'] and s.st_mtime_ns==x['mtime_ns'] and s.st_nlink==1 and s.st_blocks*512==x['allocated'];assert p.open('rb').read(4)==b'\x7fELF'
  p.unlink();record['removed'].append(x)
 record.update(status='completed',finished_unix=time.time(),reclaimed_allocated_bytes=sum(x['allocated'] for x in record['removed']),available_after_bytes=os.statvfs(root).f_bavail*os.statvfs(root).f_frsize)
 record['remaining_target_bytes']={name:int(subprocess.check_output(['du','-sb',str(root/name)],text=True).split()[0]) for name in ['target-tc','target-metadata-describe']};save()
except BaseException as error:record.update(status='cleanup_failed',error=repr(error),finished_unix=time.time());save();raise
print(json.dumps({k:v for k,v in record.items() if k not in ['removed','skipped']}))
