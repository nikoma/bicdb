import hashlib,json,pathlib,time,sys
root=pathlib.Path('/root/bicdb-durability-s3');folder=root/'partition-vm-0adf78ab';out=root/'report-partition-vm-0adf78ab-independent.json';source='0adf78abbc53f697e76f889ef52f036e7a1153d6';runtime='5aa92dcecb29b639251acc81a5d60428dfae96f7'
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def messages(text,marker):return [json.loads(line.split(marker,1)[1]) for line in text.splitlines() if marker in line]
record={'source':source,'production_equivalent':runtime,'status':'verification_failed','recorded_unix':time.time(),'scope':'Independent56-case coverage/no duplicates/exactguestbinary identity/preservedrawcutSHA/fullold482manifest+14ACKs/serialreadyandexternalACKwitness/3stableguestopens/fullrecord-schema-indexchecks. ExistingpreIOhooks explicitlynotpostfsync claims. ActualguestRAMloss; notphysicalhostpowercut/HA/scaleout/fullapplication.'}
try:
 r=json.loads((folder/'result.json').read_text());assert r['source']==source and r['production_equivalent']==runtime and r['status']=='vm_matrix_passed' and r['expected_cases']==56 and len(r['cases'])==56 and r['originals_unchanged'] is True
 build=json.loads((root/'report-partition-generated-vm-probe.json').read_text());assert build['source']==source and build['status']=='focused_passed';assert r['binary_sha256']==r['guest_sha256']==build['binary_sha256']==sha(pathlib.Path(build['binary']))
 assert sha(folder/'initroot/bin/partition_probe')==r['guest_sha256'] and sha(folder/'initrd.gz')==r['initrd_sha256'] and sha(root/'vm-reset/vmlinuz')==r['kernel_sha256']
 old=root/'partition-old-store-fixtures-482-20261112';fixtures=json.loads((old/'result.json').read_text());ledger=[json.loads(x) for x in (old/'ack-ledger.jsonl').read_text().splitlines()];assert len(ledger)==14
 for f in fixtures['cases']:
  db=pathlib.Path(f['directory'])/'db';actual={str(p.relative_to(db)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in db.rglob('*') if p.is_file() and not p.is_symlink()};assert actual==f['files']
 modes=['embedded_memory','server_paged'];cases=['parent_heap','bad_child_bound','policy_keep_stored','policy_preserve_historical'];sites=['sql_partition.format_fence.'+s for s in ['write','sync','rename','dir_sync']]+['transaction_log.write','transaction_log.sync','partition_upgrade.after_ack'];expected={(m,c,s) for m in modes for c in cases for s in sites};seen=set();acknowledged=0;states={}
 controls=json.loads((root/'partition-crash-matrix-5aa92dce/result.json').read_text());assert controls['source']==runtime and controls['status']=='crash_matrix_passed'
 for c in r['cases']:
  key=(c['mode'],c['case'],c['site']);assert key in expected and key not in seen;seen.add(key);assert c['passed'] is True and c['hard_kill_exit']==-9 and c['saved_image_unchanged_after_verification'] is True
  raw=pathlib.Path(c['saved_image']);assert raw.parent.parent==folder and raw.name=='crashed.raw' and sha(raw)==c['saved_image_sha256']
  with raw.open('rb') as f:f.seek(1080);assert f.read(2)==b'\x53\xef'
  work=raw.parent;witness=json.loads((work/'external-witness.json').read_text());cut=(work/'cut.console').read_text();verified=(work/'verify.console').read_text();assert r['guest_sha256'] in cut and r['guest_sha256'] in verified
  assert 'PARTITION_VM_APPLY_UNEXPECTED_EXIT' not in cut and 'PARTITION_VM_VERIFY_DONE_0' in verified
  ready=messages(cut,'PARTITION_VM_CUT_READY ');assert len(ready)==1 and ready[0]==c['guest_witness']==witness['guest_witness']=={'site':c['site']}
  for field in ['mode','case','site','owned_qemu_pid','acknowledged','ack']:assert c[field]==witness[field]
  acks=messages(cut,'PARTITION_VM_ACK ');expected_ack=c['site']=='partition_upgrade.after_ack';assert c['acknowledged']==expected_ack and len(acks)==int(expected_ack)
  if expected_ack:assert acks[0]==c['ack'] and c['ack']['upgrade_acknowledged'] is True;acknowledged+=1
  observations=[json.loads(line.strip()) for line in verified.splitlines() if line.strip().startswith('{')];assert observations==c['observations'] and len(observations)==3 and [x['reopen'] for x in observations]==[0,1,2] and len({x['state'] for x in observations})==1
  for x in observations:assert x['full_records_and_schemas_equal'] is True and x['native_indexes_valid'] is True
  state=observations[0]['state'];assert state in ['complete_old','complete_new'];states[state]=states.get(state,0)+1
  if expected_ack:assert state=='complete_new'
  control=next(x for x in controls['controls'] if x['mode']==c['mode'] and x['case']==c['case']);control_folder=root/'partition-crash-matrix-5aa92dce';assert sha(control_folder/control['old_snapshot'])==c['old_snapshot_sha256'] and sha(control_folder/control['new_snapshot'])==c['new_snapshot_sha256']
  original='independent_child_policy' if c['case'].startswith('policy_') else c['case'];entries=[a for a in ledger if a['mode']==c['mode'] and a['case']==original];oldsnap=json.loads((control_folder/control['old_snapshot']).read_text());assert len(entries)==c['original_ACKs_linked']==len(oldsnap['rows']) and entries
  for a in entries:
   row=next(x for x in oldsnap['rows'] if x[0]==a['relation'] and x[1]==str(a['k']));assert row[3]['metadata']['payload']==a['payload'] and row[3]['id']==str(a['k'])
 assert seen==expected and acknowledged==8
 record.update(status='verified_passed',cases=56,acknowledged_cases=8,stable_states=states,unique_original_ACKs=14,originals_unchanged=True,result_sha256=sha(folder/'result.json'),binary_sha256=r['binary_sha256'])
except BaseException as error:record['error']=repr(error)
assert not out.exists();out.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));sys.exit(0 if record['status']=='verified_passed' else 1)
